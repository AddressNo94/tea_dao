/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import { 
  LayoutDashboard, 
  Users, 
  TrendingUp, 
  FileText, 
  Settings, 
  HelpCircle, 
  Search, 
  Filter, 
  Download, 
  ArrowUpRight, 
  AlertCircle, 
  ChevronRight,
  ChevronDown,
  PieChart as PieChartIcon,
  ShieldAlert,
  Wallet,
  BarChart3,
  Bell,
  X,
  Trash2,
  Pencil,
  Save,
  Plus,
  Coins,
  ShoppingBag,
  ArrowDownLeft,
  History,
  Bot,
  Sparkles,
  Globe,
  RefreshCw,
  Sun,
  Moon,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Toaster, toast } from 'react-hot-toast';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  Filler,
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';
import {
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line as RechartsLine,
  XAxis as RechartsXAxis,
  YAxis as RechartsYAxis,
  CartesianGrid as RechartsCartesianGrid,
  Tooltip as RechartsTooltip,
} from 'recharts';
import { collection, onSnapshot, addDoc, serverTimestamp, query, orderBy, doc, updateDoc, deleteDoc, setDoc, getDoc } from 'firebase/firestore';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from './lib/firebase';
import { requestNotificationPermission, onForegroundMessage } from './lib/notifications';
import BuySalesView from './components/BuySalesView';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  Filler
);

// --- Types ---
interface Investment {
  id: string;
  name: string;
  amount: number;
  sector: string;
  return: string;
  status: 'Active' | 'Review' | 'Flagged' | 'Blocked';
}

interface Alert {
  id: string;
  title: string;
  type: 'danger' | 'warning';
  time: string;
}

interface Investor {
  id: string;
  name: string;
  totalCapital: number;
  projects: number;
  status: 'Active' | 'Inactive' | 'Pending';
  lastActivity: string;
  equity: string;
}

interface InvestmentRecord {
  id: string;
  projectName: string;
  projectId?: string;
  investorId: string;
  investorName: string;
  amount: number;
  sector: string;
  description: string;
  createdAt: any;
}

interface TopUpRecord {
  id: string;
  amount: number;
  date: string;
  description?: string;
  createdAt: any;
}

interface Expense {
  id: string;
  amount: number;
  description: string;
  category: string;
  projectId?: string;
  projectName?: string;
  createdAt: any;
}

interface Profit {
  id: string;
  amount: number;
  description: string;
  projectId: string;
  projectName: string;
  createdAt: any;
}

interface Project {
  id: string;
  name: string;
  sector: string;
  totalFunding: number;
  investorCount: number;
  status: 'Planning' | 'Active' | 'Completed' | 'On Hold';
  createdAt: any;
}

interface BuySaleRecord {
  id: string;
  itemName: string;
  type: 'Buy' | 'Sale' | 'Initial';
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  projectId?: string;
  projectName?: string;
  partnerName?: string;
  date: string;
  createdAt: any;
}

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active = false, onClick }: { icon: any, label: string, active?: boolean, onClick?: () => void }) => (
  <motion.button
    whileHover={{ x: 4 }}
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
      active 
        ? 'bg-white/10 text-white shadow-lg' 
        : 'text-white/60 hover:text-white hover:bg-white/5'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium">{label}</span>
  </motion.button>
);

const MetricCard = ({ title, value, badge, badgeColor, icon: Icon, onClick, isDark = false }: { title: string, value: any, badge: string, badgeColor: string, icon: any, onClick?: () => void, isDark?: boolean }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    onClick={onClick}
    className={`${isDark ? 'bg-gray-805 border-gray-700 text-white shadow-xl shadow-black/10' : 'bg-white border-gray-100 text-gray-900 shadow-[0_4px_20px_rgba(0,0,0,0.03)]'} p-6 rounded-2xl border flex flex-col gap-4 relative overflow-hidden group ${onClick ? 'cursor-pointer hover:border-corporate-navy hover:shadow-[0_4px_20px_rgba(11,37,69,0.08)] transition-all' : ''}`}
  >
    <div className="flex justify-between items-start">
      <div className={`p-2.5 rounded-lg text-corporate-navy group-hover:scale-110 transition-transform ${isDark ? 'bg-gray-750 text-corporate-blue' : 'bg-gray-50'}`}>
        <Icon size={22} />
      </div>
      <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${badgeColor}`}>
        {badge}
      </span>
    </div>
    <div>
      <p className={`text-sm font-medium ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{title}</p>
      <h3 className="text-2xl font-bold tracking-tight mt-1">{value}</h3>
    </div>
  </motion.div>
);

const formatDateShort = (ts: any) => {
  if (!ts) return '—';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' });
};

const formatFullJoinedDate = (ts: any) => {
  if (!ts) return '—';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) {
    const parsed = Date.parse(ts);
    if (isNaN(parsed)) return '—';
    return new Date(parsed).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  }
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
};

const getInvestmentDate = (ts: any) => {
  if (!ts) return null;
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return null;
  return d;
};

const getRecordMonthStr = (ts: any) => {
  if (!ts) return '';
  const d = ts?.toDate ? ts.toDate() : new Date(ts);
  if (isNaN(d.getTime())) return '';
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
};

const StatusBadge = ({ status }: { status: string }) => {
  const styles: Record<string, string> = {
    Active: 'bg-green-100 text-green-700',
    Review: 'bg-blue-100 text-blue-700',
    Flagged: 'bg-amber-100 text-amber-700',
    Blocked: 'bg-red-100 text-red-700',
    Inactive: 'bg-gray-100 text-gray-700',
    Pending: 'bg-purple-100 text-purple-700',
  };
  
  return (
    <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-md ${styles[status] || 'bg-gray-100 text-gray-700'}`}>
      {status}
    </span>
  );
};

const translations: Record<string, Record<string, string>> = {
  English: {
    overview: "Overview",
    investors: "Investors",
    projects: "Projects",
    buySales: "Buy & Sales",
    expenses: "Profit & Expenses",
    profitAnalytics: "Profit Analytics",
    settings: "Settings",
    aiChatBot: "AI Chat bot"
  },
  Bangla: {
    overview: "ওভারভিউ",
    investors: "বিনিয়োগকারীগণ",
    projects: "প্রজেক্টসমূহ",
    buySales: "ক্রয় ও বিক্রয়",
    expenses: "লাভ ও ক্ষতি",
    profitAnalytics: "লাভ বিশ্লেষণ",
    settings: "সেটিংস",
    aiChatBot: "এআই চ্যাট বট"
  }
};

export default function App() {
  const [currency, setCurrency] = useState<'BDT' | 'USD' | 'EUR'>(() => {
    return (localStorage.getItem('capitalhub_currency') as any) || 'BDT';
  });
  const [language, setLanguage] = useState<'English' | 'Bangla'>(() => {
    return (localStorage.getItem('capitalhub_language') as any) || 'English';
  });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    return (localStorage.getItem('capitalhub_theme') as any) || 'light';
  });

  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>(() => {
    return [
      { role: 'assistant', content: "Hello! I am your CapitalHub AI Advisor. Ask me anything about your investors, cash reserves, project yields, and allocations!" }
    ];
  });
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  useEffect(() => {
    localStorage.setItem('capitalhub_currency', currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem('capitalhub_language', language);
    setChatMessages(prev => {
      if (prev.length === 1 && prev[0].role === 'assistant') {
        return [
          { 
            role: 'assistant', 
            content: language === 'English' 
              ? "Hello! I am your CapitalHub AI Advisor. Ask me anything about your investors, cash reserves, project yields, and allocations!" 
              : "হ্যালো! আমি আপনার ক্যাপিটালহাব এআই আর্থিক পরামর্শক। বিনিয়োগকারী, নগদ তহবিল, বা প্রজেক্ট বন্টন নিয়ে যেকোনো আর্থিক তথ্য জানতে প্রশ্ন করুন!" 
          }
        ];
      }
      return prev;
    });
  }, [language]);

  useEffect(() => {
    localStorage.setItem('capitalhub_theme', theme);
  }, [theme]);

  // Conversion rates relative to BDT:
  // 1 USD = 117.5 BDT
  // 1 EUR = 126.8 BDT
  const formatVal = React.useCallback((amount: number | string | undefined | null) => {
    if (amount === undefined || amount === null) return '—';
    const num = typeof amount === 'string' ? parseFloat(amount) || 0 : amount;
    if (currency === 'USD') {
      const converted = num / 117.5;
      return `$${converted.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
    }
    if (currency === 'EUR') {
      const converted = num / 126.8;
      return `€${converted.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
    }
    return `৳${Math.round(num).toLocaleString()}`;
  }, [currency]);

  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab ] = useState('Overview');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [showQuickPrompts, setShowQuickPrompts] = useState(true);

  const [currentUser, setCurrentUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [userRole, setUserRole] = useState<'Accountant' | 'Investor'>('Investor');
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isNotifDropdownOpen, setIsNotifDropdownOpen] = useState(false);
  const [lastKnownNotifId, setLastKnownNotifId] = useState<string | null>(null);

  // Real-time Authentication and Profile Role syncing
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        const userDocRef = doc(db, 'users', user.uid);
        try {
          const docSnap = await getDoc(userDocRef);
          if (docSnap.exists()) {
            const data = docSnap.data();
            setUserRole(data.role || 'Investor');
          } else {
            const emailVal = user.email || (user.isAnonymous ? `${user.uid.slice(0, 8)}@capitalhub.demo` : 'user@capitalhub.com');
            const defaultRole = (emailVal.trim().toLowerCase() === 'mdm813312@gmail.com') ? 'Accountant' : 'Investor';
            
            await setDoc(userDocRef, {
              email: emailVal,
              displayName: user.displayName || 'Capital Partner',
              role: defaultRole,
              createdAt: serverTimestamp()
            });
            setUserRole(defaultRole);
          }
          // Request FCM permissions and cache/save Registration Token
          requestNotificationPermission(user.uid).catch((err) => {
            console.error("Failed to register FCM token:", err);
          });
        } catch (error) {
          console.error("Failed to sync user profile and role from Firestore:", error);
          const emailVal = user.email || '';
          const defaultRole = (emailVal.trim().toLowerCase() === 'mdm813312@gmail.com') ? 'Accountant' : 'Investor';
          setUserRole(defaultRole);
        }
      } else {
        setCurrentUser(null);
        setUserRole('Investor');
      }
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Handle Foreground FCM/Push Notifications with elegant custom toasts
  useEffect(() => {
    if (!currentUser) return;
    const unsubscribe = onForegroundMessage((payload) => {
      console.log("FCM Foreground message received in active app:", payload);
      const title = payload.notification?.title || (language === 'English' ? "New Alert" : "নতুন সতর্কতা");
      const body = payload.notification?.body || "";
      toast.success(
        payload.notification ? `${title}: ${body}` : (language === 'English' ? "Notification received!" : "নতুন নোটিফিকেশন পাওয়া গেছে!")
      );
    });
    return () => unsubscribe();
  }, [currentUser, language]);

  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      setAuthLoading(true);
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      toast.success(language === 'English' ? `Welcome, ${user.displayName || 'User'}!` : `স্বাগতম, ${user.displayName || 'ইউজার'}!`);
    } catch (error) {
      toast.error("Authentication failed: " + (error as Error).message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailDirectAccess = async (enteredEmail: string) => {
    if (!enteredEmail || !enteredEmail.includes('@')) {
      toast.error(language === 'English' ? 'Please enter a valid email address.' : 'অনুগ্রহ করে একটি সঠিক ইমেইল আইডি দিন।');
      return;
    }
    try {
      setAuthLoading(true);
      const email = enteredEmail.trim().toLowerCase();
      const defaultPassword = 'CapitalHubPassword2026!';
      let user;
      try {
        const result = await signInWithEmailAndPassword(auth, email, defaultPassword);
        user = result.user;
      } catch (signInErr: any) {
        // If user is not found, or credential is missing/invalid, trigger register (create user)
        if (
          signInErr.code === 'auth/user-not-found' || 
          signInErr.code === 'auth/invalid-login-credentials' || 
          signInErr.code === 'auth/invalid-credential' ||
          signInErr.message?.includes('user-not-found') ||
          signInErr.message?.includes('INVALID_LOGIN_CREDENTIALS')
        ) {
          const result = await createUserWithEmailAndPassword(auth, email, defaultPassword);
          user = result.user;
        } else {
          throw signInErr;
        }
      }
      
      const defaultRole = (email === 'mdm813312@gmail.com') ? 'Accountant' : 'Investor';
      const userDocRef = doc(db, 'users', user.uid);
      await setDoc(userDocRef, {
        email: email,
        displayName: email.split('@')[0],
        role: defaultRole,
        createdAt: serverTimestamp()
      });
      setUserRole(defaultRole);
      toast.success(language === 'English' ? 'Direct Authentication Successful!' : 'অথেনটিকেশন সফল হয়েছে!');
    } catch (error) {
      toast.error('Direct access failed: ' + (error as Error).message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      setAuthLoading(true);
      await signOut(auth);
      toast.success(language === 'English' ? 'Successfully Signed Out.' : 'সফলভাবে সাইন আউট করা হয়েছে।');
    } catch (error) {
      toast.error('Sign out failed: ' + (error as Error).message);
    } finally {
      setAuthLoading(false);
    }
  };

  useEffect(() => {
    if (!currentUser) {
      setNotifications([]);
      return;
    }
    const q = query(collection(db, 'notifications'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: any[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        list.push({ id: docSnap.id, ...data });
      });
      setNotifications(list);
    }, (err) => {
      console.error("Failed to subscribe notifications:", err);
    });
    return () => unsubscribe();
  }, [currentUser]);

  const isFirstLoad = React.useRef(true);

  useEffect(() => {
    if (notifications.length > 0) {
      if (isFirstLoad.current) {
        isFirstLoad.current = false;
        setLastKnownNotifId(notifications[0].id);
        return;
      }
      const newest = notifications[0];
      if (newest && newest.id !== lastKnownNotifId) {
        setLastKnownNotifId(newest.id);
        if (!isNotifDropdownOpen) {
          setUnreadCount(prev => prev + 1);
        }
        const title = language === 'English' ? 'Activity Alert 🔔' : 'নতুন বিজ্ঞপ্তি 🔔';
        const msg = language === 'English' ? newest.messageEn : newest.messageBn;
        
        toast(
          (t) => (
            <div className="flex items-start gap-2.5">
              <span className="text-xl">🔔</span>
              <div>
                <p className="font-bold text-xs text-corporate-navy">{title}</p>
                <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">{msg}</p>
              </div>
            </div>
          ),
          {
            duration: 5000,
            position: 'top-right',
            style: {
              borderRadius: '16px',
              background: theme === 'dark' ? '#1f2937' : '#ffffff',
              color: theme === 'dark' ? '#ffffff' : '#1f2937',
              border: theme === 'dark' ? '1px solid #374151' : '1px solid #f3f4f6',
              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
            }
          }
        );
      }
    }
  }, [notifications, language, theme, lastKnownNotifId, isNotifDropdownOpen]);

  // Reset unread count when dropdown is opened
  useEffect(() => {
    if (isNotifDropdownOpen) {
      setUnreadCount(0);
    }
  }, [isNotifDropdownOpen]);

  const addSystemNotification = async (messageEn: string, messageBn: string, type: string) => {
    try {
      await addDoc(collection(db, 'notifications'), {
        messageEn,
        messageBn,
        type,
        timestamp: serverTimestamp(),
        actor: 'Accountant'
      });
    } catch (e) {
      console.error("Error creating system notification:", e);
    }
  };

  const getHeaderTitle = React.useCallback(() => {
    if (activeTab === 'Overview') return language === 'English' ? 'Strategic Dashboard' : 'কৌশলগত ড্যাশবোর্ড';
    if (activeTab === 'Investors') return language === 'English' ? 'Investors Management' : 'বিনিয়োগকারী ব্যবস্থাপনা';
    if (activeTab === 'Projects') return language === 'English' ? 'Projects Management' : 'প্রজেক্ট ব্যবস্থাপনা';
    if (activeTab === 'BuySales') return language === 'English' ? 'Buy & Sales Ledger' : 'ক্রয় ও বিক্রয় খাতা';
    if (activeTab === 'Expenses') return language === 'English' ? 'Profit & Expenses Ledger' : 'লাভ ও খরচের খাতা';
    if (activeTab === 'Profit Analytics') return language === 'English' ? 'Profit Analytics' : 'লাভ বিশ্লেষণ';
    if (activeTab === 'Settings') return language === 'English' ? 'Application Settings' : 'অ্যাপ সেটিংস';
    if (activeTab === 'AIChatBot') return language === 'English' ? 'AI Financial Advisor' : 'এআই আর্থিক পরামর্শক';
    return activeTab;
  }, [activeTab, language]);

  const getHeaderSub = React.useCallback(() => {
    if (activeTab === 'Overview') return '';
    if (activeTab === 'Investors') return language === 'English' ? 'Monitor and manage capital partners' : 'মূলধন অংশীদারদের পর্যবেক্ষণ ও পরিচালনা করুন';
    if (activeTab === 'Projects') return language === 'English' ? 'Manage and track funding for specific business initiatives' : 'নির্দিষ্ট ব্যবসায়িক উদ্যোগের জন্য তহবিল পরিচালনা ও ট্র্যাক করুন';
    if (activeTab === 'BuySales') return language === 'English' ? 'Track dynamic buy & sales logs for business products' : 'পণ্য ক্রয় ও বিক্রয়ের হিসাব পর্যবেক্ষণ করুন';
    if (activeTab === 'Expenses') return language === 'English' ? 'Manage detailed revenue and operating cost logs' : 'বিস্তারিত রাজস্ব এবং অপারেটিং খরচ পরিচালনা করুন';
    if (activeTab === 'Profit Analytics') return language === 'English' ? 'Analyze profit trends and ROI distribution' : 'লাভের প্রবণতা এবং আরওআই (ROI) বন্টন বিশ্লেষণ করুন';
    if (activeTab === 'Settings') return '';
    if (activeTab === 'AIChatBot') return '';
    return '';
  }, [activeTab, language]);
  const [showOnlyWithUnusedCapital, setShowOnlyWithUnusedCapital] = useState(false);
  const [projectFilter, setProjectFilter] = useState('all');
  const [reportMonthFilter, setReportMonthFilter] = useState('all');
  const [customProfitPool, setCustomProfitPool] = useState<string>('');
  const [investors, setInvestors] = useState<Investor[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedInvestor, setSelectedInvestor] = useState<Investor | null>(null);
  const activeInvestor = useMemo(() => {
    if (!selectedInvestor) return null;
    return investors.find(i => i.id === selectedInvestor.id) || selectedInvestor;
  }, [investors, selectedInvestor]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [investments, setInvestments] = useState<InvestmentRecord[]>([]);
  const [allInvestments, setAllInvestments] = useState<InvestmentRecord[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [profits, setProfits] = useState<Profit[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isInvestmentModalOpen, setIsInvestmentModalOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isProfitModalOpen, setIsProfitModalOpen] = useState(false);
  const [isTopUpModalOpen, setIsTopUpModalOpen] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState<number>(0);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [partnerToRemove, setPartnerToRemove] = useState<{ investorId: string; investorName: string; projectId: string } | null>(null);
  const [analyticsSelectedProjectId, setAnalyticsSelectedProjectId] = useState<string>('all');

  const [isDashboardInvestmentModalOpen, setIsDashboardInvestmentModalOpen] = useState(false);
  const [dashboardModalTab, setDashboardModalTab] = useState<'new_investor' | 'top_up'>('new_investor');
  const [dashboardTopUpInvId, setDashboardTopUpInvId] = useState('');
  const [dashboardTopUpAmount, setDashboardTopUpAmount] = useState<number>(0);
  const [dashboardTopUpDate, setDashboardTopUpDate] = useState(() => new Date().toLocaleDateString('sv-SE'));
  const [dashboardTopUpDesc, setDashboardTopUpDesc] = useState('Capital Top Up');
  
  const [newInvestor, setNewInvestor] = useState({
    name: '',
    totalCapital: 0,
    projects: 0,
    equity: '',
    status: 'Active' as const,
    date: new Date().toLocaleDateString('sv-SE')
  });

  const [newInvestment, setNewInvestment] = useState({
    projectName: '',
    projectId: '',
    amount: 0,
    sector: 'Fun House',
    description: '',
    date: new Date().toLocaleDateString('sv-SE')
  });

  const [topUpDate, setTopUpDate] = useState<string>(new Date().toLocaleDateString('sv-SE'));
  const [topUpDescription, setTopUpDescription] = useState<string>('Capital Top Up');
  const [topUps, setTopUps] = useState<TopUpRecord[]>([]);

  const [newExpense, setNewExpense] = useState({
    amount: 0,
    description: '',
    category: 'Operational',
    projectId: '',
    projectName: '',
    date: new Date().toISOString().split('T')[0]
  });

  const [newProfit, setNewProfit] = useState({
    amount: 0,
    description: '',
    projectId: '',
    projectName: '',
    date: new Date().toISOString().split('T')[0]
  });

  const [newProject, setNewProject] = useState({
    name: '',
    sector: 'Fun House',
    status: 'Active' as const
  });

  const [buySales, setBuySales] = useState<BuySaleRecord[]>([]);
  const [isBuySaleModalOpen, setIsBuySaleModalOpen] = useState(false);
  const [editingBuySale, setEditingBuySale] = useState<BuySaleRecord | null>(null);
  const [newBuySale, setNewBuySale] = useState({
    itemName: '',
    type: 'Buy' as 'Buy' | 'Sale' | 'Initial',
    quantity: 1,
    unitPrice: 0,
    projectId: '',
    partnerName: '',
    date: new Date().toISOString().split('T')[0]
  });

  // Reset search term when switching tabs
  useEffect(() => {
    setSearchTerm('');
    if (activeTab !== 'Investors') {
      setShowOnlyWithUnusedCapital(false);
    }
  }, [activeTab]);

  // Sync with Firestore
  useEffect(() => {
    if (!currentUser) {
      setInvestors([]);
      return;
    }
    const q = query(collection(db, 'investors'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Investor[];
      setInvestors(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'investors');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Sync Projects
  useEffect(() => {
    if (!currentUser) {
      setProjects([]);
      return;
    }
    const q = query(collection(db, 'projects'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Project[];
      setProjects(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'projects');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Sync ALL investments for Dashboard
  useEffect(() => {
    if (!currentUser) {
      setAllInvestments([]);
      return;
    }
    const q = query(collection(db, 'investments'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as InvestmentRecord[];
      setAllInvestments(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'investments');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Sync Expenses
  useEffect(() => {
    if (!currentUser) {
      setExpenses([]);
      return;
    }
    const q = query(collection(db, 'expenses'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Expense[];
      setExpenses(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'expenses');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Sync Profits
  useEffect(() => {
    if (!currentUser) {
      setProfits([]);
      return;
    }
    const q = query(collection(db, 'profits'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Profit[];
      setProfits(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'profits');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Sync Buy & Sales
  useEffect(() => {
    if (!currentUser) {
      setBuySales([]);
      return;
    }
    const q = query(collection(db, 'buy_sales'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as BuySaleRecord[];
      setBuySales(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'buy_sales');
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Sync investments when user selects an investor
  useEffect(() => {
    if (!selectedInvestor) {
      setInvestments([]);
      return;
    }

    const q = query(
      collection(db, 'investors', selectedInvestor.id, 'investments'), 
      orderBy('createdAt', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as InvestmentRecord[];
      setInvestments(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `investors/${selectedInvestor.id}/investments`);
    });

    return () => unsubscribe();
  }, [selectedInvestor]);

  // Sync top-ups when user is viewing an investor profile
  useEffect(() => {
    if (!selectedInvestor) {
      setTopUps([]);
      return;
    }

    const q = query(
      collection(db, 'investors', selectedInvestor.id, 'topups'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as TopUpRecord[];
      setTopUps(list);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `investors/${selectedInvestor.id}/topups`);
    });

    return () => unsubscribe();
  }, [selectedInvestor]);

  const filteredInvestors = useMemo(() => {
    let list = investors.filter(inv => 
      inv.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    if (showOnlyWithUnusedCapital) {
      list = list.filter(inv => {
        const investorInvestments = allInvestments.filter(invItem => invItem.investorId === inv.id);
        const totalAllocated = investorInvestments.reduce((sum, invItem) => sum + (invItem.amount || 0), 0);
        const unusedCapital = Math.max((inv.totalCapital || 0) - totalAllocated, 0);
        return unusedCapital > 0;
      });
    }
    return list;
  }, [searchTerm, investors, showOnlyWithUnusedCapital, allInvestments]);

  const filteredExpenses = useMemo(() => {
    const list = projectFilter === 'all' 
      ? expenses 
      : expenses.filter(e => e.projectId === projectFilter);

    const mappedBuySalesAsExpenses = buySales
      .filter(record => record.type === 'Buy' && (projectFilter === 'all' || record.projectId === projectFilter))
      .map(record => ({
        id: record.id,
        description: `Purchase: ${record.itemName} (${record.quantity} units${record.partnerName ? ` from ${record.partnerName}` : ''})`,
        category: 'Inventory Buy',
        projectId: record.projectId || '',
        projectName: record.projectName || '',
        amount: record.totalAmount || 0,
        createdAt: record.createdAt || (record.date ? new Date(record.date) : new Date()),
        isFromBuySales: true
      }));

    let combinedExpenses = [...list, ...mappedBuySalesAsExpenses];

    combinedExpenses.sort((a, b) => {
      const getMs = (item: any) => {
        if (!item) return 0;
        const rawDate = item.createdAt;
        if (!rawDate) return 0;
        const d = rawDate.toDate ? rawDate.toDate() : new Date(rawDate);
        return isNaN(d.getTime()) ? 0 : d.getTime();
      };
      return getMs(b) - getMs(a);
    });
      
    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      combinedExpenses = combinedExpenses.filter(e => 
        (e.description || '').toLowerCase().includes(s) || 
        (e.category || '').toLowerCase().includes(s) || 
        (e.projectName || '').toLowerCase().includes(s)
      );
    }
    return combinedExpenses;
  }, [expenses, buySales, projectFilter, searchTerm]);

  const filteredProfits = useMemo(() => {
    const list = projectFilter === 'all' 
      ? profits 
      : profits.filter(p => p.projectId === projectFilter);

    const mappedBuySalesAsProfits = buySales
      .filter(record => record.type === 'Sale' && (projectFilter === 'all' || record.projectId === projectFilter))
      .map(record => ({
        id: record.id,
        projectName: record.projectName || '',
        description: `Sale: ${record.itemName} (${record.quantity} units${record.partnerName ? ` to ${record.partnerName}` : ''})`,
        amount: record.totalAmount || 0,
        createdAt: record.createdAt || (record.date ? new Date(record.date) : new Date()),
        isFromBuySales: true
      }));

    let combinedProfits = [...list, ...mappedBuySalesAsProfits];

    combinedProfits.sort((a, b) => {
      const getMs = (item: any) => {
        if (!item) return 0;
        const rawDate = item.createdAt;
        if (!rawDate) return 0;
        const d = rawDate.toDate ? rawDate.toDate() : new Date(rawDate);
        return isNaN(d.getTime()) ? 0 : d.getTime();
      };
      return getMs(b) - getMs(a);
    });
      
    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      combinedProfits = combinedProfits.filter(p => 
        (p.description || '').toLowerCase().includes(s) || 
        (p.projectName || '').toLowerCase().includes(s)
      );
    }
    return combinedProfits;
  }, [profits, buySales, projectFilter, searchTerm]);

  const stats = useMemo(() => {
    const filteredInv = projectFilter === 'all' 
      ? allInvestments.filter(inv => investors.some(i => i.id === inv.investorId))
      : allInvestments.filter(inv => inv.projectId === projectFilter && investors.some(i => i.id === inv.investorId));
    
    const filteredExp = projectFilter === 'all'
      ? expenses
      : expenses.filter(exp => exp.projectId === projectFilter); 

    const filteredProfit = projectFilter === 'all'
      ? profits
      : profits.filter(p => p.projectId === projectFilter);

    const filteredBuySalesBues = buySales
      .filter(record => record.type === 'Buy' && (projectFilter === 'all' || record.projectId === projectFilter));
    const filteredBuySalesSales = buySales
      .filter(record => record.type === 'Sale' && (projectFilter === 'all' || record.projectId === projectFilter));

    // For 'all' view, display total capital raised globally as the sum of all investor capitals.
    // For a specific project, display the total capital allocated to that specific project.
    const totalCapital = projectFilter === 'all'
      ? investors.reduce((sum, inv) => sum + (inv.totalCapital || 0), 0)
      : filteredInv.reduce((sum, inv) => sum + (inv.amount || 0), 0);

    const baseExpenses = filteredExp.reduce((sum, exp) => sum + (exp.amount || 0), 0);
    const buySalesExpenses = filteredBuySalesBues.reduce((sum, item) => sum + (item.totalAmount || 0), 0);
    const totalExpenses = baseExpenses + buySalesExpenses;

    const baseProfits = filteredProfit.reduce((sum, p) => sum + (p.amount || 0), 0);
    const buySalesProfits = filteredBuySalesSales.reduce((sum, item) => sum + (item.totalAmount || 0), 0);
    const totalProfits = baseProfits + buySalesProfits;
    
    // Reserve / uninvested capital is computed globally across the entire firm:
    // Net total capital raised from all partners MINUS total capital allocated to projects.
    const systemTotalCapital = investors.reduce((sum, inv) => sum + (inv.totalCapital || 0), 0);
    const systemTotalAllocated = allInvestments
      .filter(inv => investors.some(i => i.id === inv.investorId))
      .reduce((sum, inv) => sum + (inv.amount || 0), 0);
    const unallocatedCapital = Math.max(systemTotalCapital - systemTotalAllocated, 0);

    // Available cash (reserve cash + project funds)
    const availableCash = (totalCapital + totalProfits) - totalExpenses;
    const activeProjects = projects.filter(p => p.status === 'Active').length;

    // Calculate "Net Monthly Profit Inflow" (using BOTH profits table and buySales table)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const monthlyInflowFromBase = filteredProfit
      .filter(p => {
        const d = p.createdAt?.toDate ? p.createdAt.toDate() : new Date(p.createdAt);
        return d > thirtyDaysAgo;
      })
      .reduce((sum, p) => sum + (p.amount || 0), 0);

    const monthlyInflowFromBuySales = filteredBuySalesSales
      .filter(item => {
        const d = item.createdAt?.toDate ? item.createdAt.toDate() : (item.date ? new Date(item.date) : new Date());
        return d > thirtyDaysAgo;
      })
      .reduce((sum, item) => sum + (item.totalAmount || 0), 0);

    const monthlyInflow = monthlyInflowFromBase + monthlyInflowFromBuySales;

    return {
      totalCapital,
      totalExpenses,
      totalProfits,
      availableCash,
      activeProjects,
      investorCount: investors.length,
      monthlyInflow,
      unallocatedCapital,
      avgROI: investors.length > 0 ? (activeProjects / investors.length).toFixed(1) : '0.0'
    };
  }, [investors, expenses, profits, projects, allInvestments, buySales, projectFilter]);

  const topPartners = useMemo(() => {
    return [...investors].sort((a, b) => b.totalCapital - a.totalCapital);
  }, [investors]);

  const filteredInvestorsForSummary = useMemo(() => {
    let list = [];
    if (projectFilter === 'all') {
      list = investors.map(inv => {
        const equityText = inv.equity || "0%";
        const equityVal = parseFloat(inv.equity) || 0;
        const payoutVal = Math.floor((stats.monthlyInflow * equityVal) / 100);
        return {
          id: inv.id,
          name: inv.name,
          capitalInjected: inv.totalCapital,
          shareText: equityText,
          payout: payoutVal,
          lastActivity: inv.lastActivity || '—',
          status: inv.status,
          createdAt: inv.createdAt,
          date: inv.date,
        };
      });
    } else {
      // Find all investments for this project
      const projectInvs = allInvestments.filter(inv => inv.projectId === projectFilter);
      
      // Group by investor
      const investorCaps: Record<string, number> = {};
      projectInvs.forEach(inv => {
        if (inv.investorId) {
          investorCaps[inv.investorId] = (investorCaps[inv.investorId] || 0) + (inv.amount || 0);
        }
      });

      // Calculate total funding for this specific project based on actual investments
      const totalFunding = Object.values(investorCaps).reduce((sum, amt) => sum + amt, 0);

      list = investors
        .filter(inv => investorCaps[inv.id] > 0)
        .map(inv => {
          const cap = investorCaps[inv.id];
          const pct = totalFunding > 0 ? (cap / totalFunding) * 100 : 0;
          const payoutVal = Math.floor((stats.monthlyInflow * pct) / 100);
          return {
            id: inv.id,
            name: inv.name,
            capitalInjected: cap,
            shareText: `${pct.toFixed(1)}%`,
            payout: payoutVal,
            lastActivity: inv.lastActivity || '—',
            status: inv.status,
            createdAt: inv.createdAt,
            date: inv.date,
          };
        });
    }

    if (searchTerm) {
      const s = searchTerm.toLowerCase();
      list = list.filter(inv => inv.name.toLowerCase().includes(s));
    }
    return list;
  }, [investors, projects, allInvestments, projectFilter, stats.monthlyInflow, searchTerm]);

  const selectedInvestorStats = useMemo(() => {
    if (!activeInvestor) return null;
    const equity = parseFloat(activeInvestor.equity) || 0;
    const totalCompanyProfits = profits.reduce((sum, p) => sum + (p.amount || 0), 0);
    const estimatedProfitShare = (equity / 100) * totalCompanyProfits;
    return {
      estimatedProfitShare,
      netWorth: activeInvestor.totalCapital + estimatedProfitShare
    };
  }, [activeInvestor, profits]);

  const activeInvestorUnallocated = useMemo(() => {
    if (!activeInvestor) return 0;
    const activeInvestorInvs = allInvestments.filter(inv => inv.investorId === activeInvestor.id);
    const totalAllocated = activeInvestorInvs.reduce((sum, inv) => sum + (inv.amount || 0), 0);
    return Math.max((activeInvestor.totalCapital || 0) - totalAllocated, 0);
  }, [activeInvestor, allInvestments]);

  const projectInvestors = useMemo(() => {
    if (!selectedProject) return [];
    
    const investorSummary: Record<string, { investorId: string; investorName: string; amount: number; count: number }> = {};
    
    allInvestments
      .filter(inv => inv.projectId === selectedProject.id)
      .forEach(inv => {
        if (!investorSummary[inv.investorId]) {
          investorSummary[inv.investorId] = {
            investorId: inv.investorId,
            investorName: inv.investorName,
            amount: 0,
            count: 0
          };
        }
        investorSummary[inv.investorId].amount += inv.amount;
        investorSummary[inv.investorId].count += 1;
      });
    
    return Object.values(investorSummary).sort((a, b) => b.amount - a.amount);
  }, [selectedProject, allInvestments]);

  const projectsWithStats = useMemo(() => {
    return projects.map(project => {
      const pInvestments = allInvestments.filter(inv => inv.projectId === project.id && investors.some(i => i.id === inv.investorId));
      const pExpenses = expenses.filter(exp => exp.projectId === project.id);
      const pProfits = profits.filter(prof => prof.projectId === project.id);
      
      const pBuySales = buySales.filter(bs => bs.projectId === project.id);
      const pBuyCost = pBuySales.filter(bs => bs.type === 'Buy').reduce((sum, bs) => sum + (bs.totalAmount || 0), 0);
      const pSaleRevenue = pBuySales.filter(bs => bs.type === 'Sale').reduce((sum, bs) => sum + (bs.totalAmount || 0), 0);

      const totalFunding = pInvestments.reduce((sum, inv) => sum + inv.amount, 0);
      const totalCost = pExpenses.reduce((sum, exp) => sum + exp.amount, 0) + pBuyCost;
      const totalProfit = pProfits.reduce((sum, prof) => sum + prof.amount, 0) + pSaleRevenue;
      const uniqueInvestors = new Set(pInvestments.map(inv => inv.investorId));
      return {
        ...project,
        totalFunding,
        totalCost,
        totalProfit,
        investorCount: uniqueInvestors.size
      };
    });
  }, [projects, allInvestments, investors, expenses, profits, buySales]);

  const selectedProjectWithStats = useMemo(() => {
    if (!selectedProject) return null;
    return projectsWithStats.find(p => p.id === selectedProject.id) || selectedProject;
  }, [selectedProject, projectsWithStats]);

  const projectsProfitabilityData = useMemo(() => {
    return projects.map(project => {
      // 1. Get all raw records for this project
      let pInvestments = allInvestments.filter(inv => inv.projectId === project.id && investors.some(i => i.id === inv.investorId));
      let pExpenses = expenses.filter(exp => exp.projectId === project.id);
      let pProfits = profits.filter(prof => prof.projectId === project.id);
      let pBuySales = buySales.filter(record => record.projectId === project.id);

      // Save overall totals
      const overallFunding = pInvestments.reduce((sum, inv) => sum + (inv.amount || 0), 0);

      // 2. Apply month filter if one is selected
      if (reportMonthFilter !== 'all') {
        pInvestments = pInvestments.filter(inv => getRecordMonthStr(inv.createdAt) === reportMonthFilter);
        pExpenses = pExpenses.filter(exp => getRecordMonthStr(exp.createdAt) === reportMonthFilter);
        pProfits = pProfits.filter(prof => getRecordMonthStr(prof.createdAt) === reportMonthFilter);
        pBuySales = pBuySales.filter(record => {
          if (record.date) {
            return record.date.substring(0, 7) === reportMonthFilter;
          }
          return getRecordMonthStr(record.createdAt) === reportMonthFilter;
        });
      }

      const pBuyCost = pBuySales.filter(bs => bs.type === 'Buy').reduce((sum, bs) => sum + (bs.totalAmount || 0), 0);
      const pSaleRevenue = pBuySales.filter(bs => bs.type === 'Sale').reduce((sum, bs) => sum + (bs.totalAmount || 0), 0);

      const periodFunding = pInvestments.reduce((sum, inv) => sum + (inv.amount || 0), 0);
      const periodExpenses = pExpenses.reduce((sum, exp) => sum + (exp.amount || 0), 0) + pBuyCost;
      const periodRevenue = pProfits.reduce((sum, prof) => sum + (prof.amount || 0), 0) + pSaleRevenue;
      const periodNetProfit = periodRevenue - periodExpenses;

      // Net ROI: net profit / total investment. 
      // If we are filtering by month and there is no funding injected in this particular month, 
      // we fall back to the overall cumulative funding allocated to the project to give a realistic ROI.
      const divisorFunding = periodFunding > 0 ? periodFunding : (overallFunding > 0 ? overallFunding : 1);
      const netROI = overallFunding > 0 ? (periodNetProfit / divisorFunding) * 100 : 0;

      return {
        ...project,
        periodFunding,
        periodExpenses,
        periodRevenue,
        periodNetProfit,
        overallFunding,
        netROI
      };
    });
  }, [projects, allInvestments, expenses, profits, buySales, reportMonthFilter]);

  const filteredReportData = useMemo(() => {
    if (projectFilter === 'all') {
      return projectsProfitabilityData;
    }
    return projectsProfitabilityData.filter(p => p.id === projectFilter);
  }, [projectsProfitabilityData, projectFilter]);

  const reportTotals = useMemo(() => {
    let totalInflow = 0;
    let totalRevenue = 0;
    let totalExpenses = 0;

    filteredReportData.forEach(p => {
      totalInflow += p.periodFunding;
      totalRevenue += p.periodRevenue;
      totalExpenses += p.periodExpenses;
    });

    const netProfit = totalRevenue - totalExpenses;
    
    // Fallback: If no inflow in period, use cumulative overall funding of the projects
    let totalOverallFunding = 0;
    filteredReportData.forEach(p => {
      totalOverallFunding += p.overallFunding;
    });

    const divisor = totalInflow > 0 ? totalInflow : (totalOverallFunding > 0 ? totalOverallFunding : 1);
    const averageROI = totalOverallFunding > 0 ? (netProfit / divisor) * 100 : 0;

    return {
      totalInflow,
      totalRevenue,
      totalExpenses,
      netProfit,
      averageROI
    };
  }, [filteredReportData]);

  const projectPartnerProfitAllocation = useMemo(() => {
    return projects.map(project => {
      const pInvs = allInvestments.filter(inv => inv.projectId === project.id && investors.some(i => i.id === inv.investorId));
      const totalFunding = pInvs.reduce((sum, inv) => sum + (inv.amount || 0), 0);
      
      const pExpenses = expenses.filter(exp => exp.projectId === project.id);
      const pProfits = profits.filter(prof => prof.projectId === project.id);
      const pBuySales = buySales.filter(bs => bs.projectId === project.id);
      
      const pBuyCost = pBuySales.filter(bs => bs.type === 'Buy').reduce((sum, bs) => sum + (bs.totalAmount || 0), 0);
      const pSaleRevenue = pBuySales.filter(bs => bs.type === 'Sale').reduce((sum, bs) => sum + (bs.totalAmount || 0), 0);
      
      const totalCost = pExpenses.reduce((sum, exp) => sum + (exp.amount || 0), 0) + pBuyCost;
      const totalProfitVal = pProfits.reduce((sum, prof) => sum + (prof.amount || 0), 0) + pSaleRevenue;
      const netProfit = totalProfitVal - totalCost;

      const partnersMap: Record<string, { investorId: string; investorName: string; contribution: number }> = {};
      pInvs.forEach(inv => {
        if (!partnersMap[inv.investorId]) {
          partnersMap[inv.investorId] = {
            investorId: inv.investorId,
            investorName: inv.investorName,
            contribution: 0
          };
        }
        partnersMap[inv.investorId].contribution += (inv.amount || 0);
      });

      const partners = Object.values(partnersMap).map(p => {
        const fundingShare = totalFunding > 0 ? (p.contribution / totalFunding) : 0;
        const profitShare = fundingShare * netProfit;
        return {
          ...p,
          fundingSharePercent: fundingShare * 100,
          profitShare
        };
      }).sort((a, b) => b.contribution - a.contribution);

      return {
        projectId: project.id,
        projectName: project.name,
        projectSector: project.sector,
        projectStatus: project.status,
        totalFunding,
        totalCost,
        totalProfitVal,
        netProfit,
        partners
      };
    });
  }, [projects, allInvestments, investors, expenses, profits, buySales]);

  const activeInvestorProfitBreakdown = useMemo(() => {
    if (!activeInvestor) return [];
    const equityPct = parseFloat(activeInvestor.equity) || 0;
    
    return projectPartnerProfitAllocation
      .map(proj => {
        const partnerRecord = proj.partners.find(p => p.investorId === activeInvestor.id);
        if (!partnerRecord) return null;
        
        // Use registered global equity of the partner for calculating apportioned profit
        const profitShare = (equityPct / 100) * proj.netProfit;
        
        return {
          projectId: proj.projectId,
          projectName: proj.projectName,
          projectSector: proj.projectSector,
          projectStatus: proj.projectStatus,
          totalFunding: proj.totalFunding,
          projectNetProfit: proj.netProfit,
          investorContribution: partnerRecord.contribution,
          fundingSharePercent: partnerRecord.fundingSharePercent,
          equityPercent: equityPct,
          profitShare
        };
      })
      .filter((rec): rec is NonNullable<typeof rec> => rec !== null);
  }, [activeInvestor, projectPartnerProfitAllocation]);

  const activeInvestorVentureProfitShareSum = useMemo(() => {
    return activeInvestorProfitBreakdown.reduce((sum, b) => sum + b.profitShare, 0);
  }, [activeInvestorProfitBreakdown]);

  const last6MonthsData = useMemo(() => {
    const monthsList: { key: string; label: string }[] = [];
    const now = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const key = `${year}-${month}`;
      const label = d.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
      monthsList.push({ key, label });
    }

    return monthsList.map(({ key, label }) => {
      // Filter base profits
      const mProfits = profits.filter(p => getRecordMonthStr(p.createdAt) === key);
      const profitVal = mProfits.reduce((sum, p) => sum + (p.amount || 0), 0);

      // Filter buySales (type === 'Sale')
      const mSales = buySales.filter(bs => {
        if (bs.type !== 'Sale') return false;
        if (bs.date) {
          return bs.date.substring(0, 7) === key;
        }
        return getRecordMonthStr(bs.createdAt) === key;
      });
      const salesVal = mSales.reduce((sum, s) => sum + (s.totalAmount || 0), 0);

      const totalRevenue = profitVal + salesVal;

      // Filter base expenses
      const mExpenses = expenses.filter(e => getRecordMonthStr(e.createdAt) === key);
      const expensesVal = mExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);

      // Filter buySales (type === 'Buy')
      const mBuys = buySales.filter(bs => {
        if (bs.type !== 'Buy') return false;
        if (bs.date) {
          return bs.date.substring(0, 7) === key;
        }
        return getRecordMonthStr(bs.createdAt) === key;
      });
      const buysVal = mBuys.reduce((sum, b) => sum + (b.totalAmount || 0), 0);

      const totalLoss = expensesVal + buysVal;
      const netMargin = totalRevenue - totalLoss;

      return {
        month: label,
        Margin: netMargin,
        Revenues: totalRevenue,
        Expenses: totalLoss
      };
    });
  }, [profits, expenses, buySales]);

  const productProfitabilityStats = useMemo(() => {
    const productMap: { 
      [key: string]: { 
        buyQuantity: number; 
        buyTotalAmount: number; 
        sellQuantity: number; 
        sellTotalAmount: number;
        initialQuantity: number;
      } 
    } = {};

    buySales.forEach(record => {
      const name = record.itemName?.trim();
      if (!name) return;

      if (!productMap[name]) {
        productMap[name] = { buyQuantity: 0, buyTotalAmount: 0, sellQuantity: 0, sellTotalAmount: 0, initialQuantity: 0 };
      }

      if (record.type === 'Buy') {
        productMap[name].buyQuantity += Number(record.quantity || 0);
        productMap[name].buyTotalAmount += Number(record.totalAmount || (Number(record.quantity) * Number(record.unitPrice)) || 0);
      } else if (record.type === 'Sale') {
        productMap[name].sellQuantity += Number(record.quantity || 0);
        productMap[name].sellTotalAmount += Number(record.totalAmount || (Number(record.quantity) * Number(record.unitPrice)) || 0);
      } else if (record.type === 'Initial') {
        productMap[name].initialQuantity += Number(record.quantity || 0);
      }
    });

    return Object.entries(productMap).map(([name, data]) => {
      // Average Cost calculation
      const avgUnitCost = data.buyQuantity > 0 ? (data.buyTotalAmount / data.buyQuantity) : 0;
      
      // Cost of Goods Sold (COGS) is units sold * average procurement cost
      const cogs = data.sellQuantity * avgUnitCost;
      
      // Revenue is total amount received from sales
      const revenue = data.sellTotalAmount;
      
      // Net Profit from trade
      const profit = revenue - cogs;
      
      // Margin percentage
      const marginPercentage = revenue > 0 ? (profit / revenue) * 100 : 0;

      return {
        name,
        avgUnitCost,
        totalSold: data.sellQuantity,
        totalBought: data.buyQuantity,
        buyTotalAmount: data.buyTotalAmount,
        totalInitial: data.initialQuantity,
        cogs,
        revenue,
        profit,
        marginPercentage
      };
    }).filter(item => item.totalBought > 0 || item.totalSold > 0 || item.totalInitial > 0);
  }, [buySales]);

  const handleSendChatMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const userMsg = chatInput.trim();
    setChatMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setChatInput('');
    setIsChatLoading(true);

    const systemContext = {
      overallCapitalHubStats: {
        totalCapitalRaised: stats.totalCapital,
        uninvestedCapital: stats.unallocatedCapital,
        totalProjectExpenses: stats.totalExpenses,
        totalEarnedProfits: stats.totalProfits,
        netCashMargin: stats.totalProfits - stats.totalExpenses,
        projectsCount: projects.length,
        activeProjectsCount: projects.filter(p => p.status === 'Active').length,
        investorsCount: investors.length
      },
      investors: investors.map(i => ({
        id: i.id,
        name: i.name,
        totalCapital: i.totalCapital,
        equity: i.equity,
        status: i.status
      })),
      projects: projects.map(p => ({
        id: p.id,
        name: p.name,
        sector: p.sector,
        status: p.status
      })),
      recentTransactionsOverview: {
        allRecentBuySales: buySales.slice(0, 5).map(bs => ({
          type: bs.type,
          projectName: bs.projectName,
          productName: bs.itemName,
          totalAmount: bs.totalAmount,
          date: bs.date
        })),
        allRecentProfits: profits.slice(0, 5).map(p => ({
          projectName: p.projectName,
          amount: p.amount,
          description: p.description,
          date: p.date
        })),
        allRecentExpenses: expenses.slice(0, 5).map(ex => ({
          projectName: ex.projectName,
          amount: ex.amount,
          category: ex.category,
          description: ex.description,
          date: ex.date
        }))
      },
      currentCurrencyPreference: currency,
      currentLanguagePreference: language
    };

    try {
      const savedHistory = [...chatMessages, { role: 'user' as const, content: userMsg }];
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: userMsg,
          history: savedHistory,
          contextData: systemContext
        })
      });

      if (!res.ok) {
        throw new Error(language === 'English' ? "Failed to get response from AI." : "এআই থেকে উত্তর পেতে ব্যর্থ হয়েছে।");
      }

      const data = await res.json();
      setChatMessages(prev => [...prev, { role: 'assistant', content: data.text }]);
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || (language === 'English' ? "Connection unstable. Please check your network." : "সংযোগ ব্যর্থ হয়েছে। অনুগ্রহ করে নেটওয়ার্ক চেক করুন।"));
      setChatMessages(prev => [...prev, { role: 'assistant', content: language === 'English' ? "My system is experiencing a temporary fluctuation. Please double check that process.env.GEMINI_API_KEY is properly set in your Secrets panel inside Google AI Studio!" : "আমার সিস্টেমে সাময়িক ত্রুটি দেখা দিয়েছে। অনুগ্রহ করে নিশ্চিত হোন যে গুগল এআই স্টুডিওতে GEMINI_API_KEY সঠিকভাবে সেট করা হয়েছে!" }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleAddInvestor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      const joinDate = new Date(newInvestor.date);
      const investorRef = await addDoc(collection(db, 'investors'), {
        name: newInvestor.name,
        totalCapital: newInvestor.totalCapital,
        projects: newInvestor.projects,
        equity: newInvestor.equity,
        status: newInvestor.status,
        date: newInvestor.date,
        lastActivity: 'Joined',
        createdAt: joinDate
      });

      if (newInvestor.totalCapital > 0) {
        await addDoc(collection(db, 'investors', investorRef.id, 'topups'), {
          amount: newInvestor.totalCapital,
          date: newInvestor.date,
          description: 'Initial Capital Injection',
          createdAt: joinDate
        });
      }

      await addSystemNotification(
        `New partner registered: ${newInvestor.name} with ৳${newInvestor.totalCapital.toLocaleString()} initial capital.`,
        `নতুন অংশীদার নিবন্ধিত: ${newInvestor.name}, প্রাথমিক মূলধন: ৳${newInvestor.totalCapital.toLocaleString()}`,
        'investor'
      );

      setIsModalOpen(false);
      setIsDashboardInvestmentModalOpen(false);
      setNewInvestor({ 
        name: '', 
        totalCapital: 0, 
        projects: 0, 
        equity: '', 
        status: 'Active',
        date: new Date().toLocaleDateString('sv-SE')
      });
      toast.success('Investor added successfully');
    } catch (error) {
      toast.error('Failed to add investor');
      handleFirestoreError(error, OperationType.CREATE, 'investors');
    }
  };

  const handleDashboardTopUpClick = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    if (!dashboardTopUpInvId) {
      toast.error('Please select an investor to top up');
      return;
    }
    try {
      const targetInvestor = investors.find(inv => inv.id === dashboardTopUpInvId);
      if (!targetInvestor) {
        toast.error('Investor not found');
        return;
      }
      const targetDate = new Date(dashboardTopUpDate);
      
      // 1. Log top up custom transaction in subcollection
      await addDoc(collection(db, 'investors', dashboardTopUpInvId, 'topups'), {
        amount: dashboardTopUpAmount,
        date: dashboardTopUpDate,
        description: dashboardTopUpDesc || 'Capital Top Up',
        createdAt: targetDate
      });

      // 2. Add to totalCapital on main partner doc
      const investorRef = doc(db, 'investors', dashboardTopUpInvId);
      const updatedTotalCapitalValue = (targetInvestor.totalCapital || 0) + dashboardTopUpAmount;
      
      await updateDoc(investorRef, {
        totalCapital: updatedTotalCapitalValue,
        lastActivity: 'Capital Topped Up'
      });

      await addSystemNotification(
        `Capital Top Up: Added ৳${dashboardTopUpAmount.toLocaleString()} to ${targetInvestor.name}'s balance.`,
        `মূলধন বৃদ্ধি: ${targetInvestor.name}-এর ব্যালেন্সে ৳${dashboardTopUpAmount.toLocaleString()} যোগ করা হয়েছে।`,
        'investment'
      );

      setIsDashboardInvestmentModalOpen(false);
      setDashboardTopUpAmount(0);
      setDashboardTopUpDesc('Capital Top Up');
      setDashboardTopUpDate(new Date().toLocaleDateString('sv-SE'));
      setDashboardTopUpInvId('');
      toast.success('Capital topped up successfully');
    } catch (error) {
      toast.error('Failed to top up capital');
      handleFirestoreError(error, OperationType.UPDATE, `investors/${dashboardTopUpInvId}`);
    }
  };

  const handleTopUpCapital = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    if (!activeInvestor) return;
    try {
      const targetDate = new Date(topUpDate);
      
      // 1. Log top up custom transaction in subcollection
      await addDoc(collection(db, 'investors', activeInvestor.id, 'topups'), {
        amount: topUpAmount,
        date: topUpDate,
        description: topUpDescription || 'Capital Top Up',
        createdAt: targetDate
      });

      // 2. Add to totalCapital on main partner doc
      const investorRef = doc(db, 'investors', activeInvestor.id);
      const updatedTotalCapitalValue = (activeInvestor.totalCapital || 0) + topUpAmount;
      
      await updateDoc(investorRef, {
        totalCapital: updatedTotalCapitalValue,
        lastActivity: 'Capital Topped Up'
      });

      await addSystemNotification(
        `Capital Top Up: Added ৳${topUpAmount.toLocaleString()} to ${activeInvestor.name}'s balance.`,
        `মূলধন বৃদ্ধি: ${activeInvestor.name}-এর ব্যালেন্সে ৳${topUpAmount.toLocaleString()} যোগ করা হয়েছে।`,
        'investment'
      );

      setSelectedInvestor({
        ...activeInvestor,
        totalCapital: updatedTotalCapitalValue
      });

      setIsTopUpModalOpen(false);
      setTopUpAmount(0);
      setTopUpDescription('Capital Top Up');
      setTopUpDate(new Date().toLocaleDateString('sv-SE'));
      toast.success('Capital topped up successfully');
    } catch (error) {
      toast.error('Failed to top up capital');
      handleFirestoreError(error, OperationType.UPDATE, `investors/${activeInvestor.id}`);
    }
  };

  const handleDeleteTopUp = async (topUpId: string, amount: number) => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    if (!activeInvestor) return;
    try {
      const investorRef = doc(db, 'investors', activeInvestor.id);
      const topUpRef = doc(db, 'investors', activeInvestor.id, 'topups', topUpId);
      
      await deleteDoc(topUpRef);
      
      const newTotalCapitalValue = Math.max((activeInvestor.totalCapital || 0) - amount, 0);
      
      await updateDoc(investorRef, {
        totalCapital: newTotalCapitalValue,
        lastActivity: 'Capital Removed'
      });

      await addSystemNotification(
        `Capital Record Removed: Deducted ৳${amount.toLocaleString()} from ${activeInvestor.name}'s balance.`,
        `মূলধনের রেকর্ড অপসারিত: ${activeInvestor.name}-এর ব্যালেন্স থেকে ৳${amount.toLocaleString()} কমানো হয়েছে।`,
        'investment'
      );

      setSelectedInvestor({
        ...activeInvestor,
        totalCapital: newTotalCapitalValue
      });

      toast.success('Capital injection record deleted successfully');
    } catch (error) {
      toast.error('Failed to delete capital injection record');
      handleFirestoreError(error, OperationType.DELETE, `investors/${activeInvestor.id}/topups/${topUpId}`);
    }
  };

  const handleAddInvestment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    if (!activeInvestor) return;

    if (newInvestment.amount > activeInvestorUnallocated) {
      toast.error(`Insufficient Balance! This partner only has ৳${activeInvestorUnallocated.toLocaleString()} of unused, uninvested capital.`);
      return;
    }

    try {
      // Find the project to get its ID if it exists, or use name
      let projectId = newInvestment.projectId;
      let projectName = newInvestment.projectName;
      let sector = newInvestment.sector;

      if (projectId) {
        const proj = projects.find(p => p.id === projectId);
        if (proj) {
          projectName = proj.name;
          sector = proj.sector;
        }
      }

      // Generate a single ID for both records
      const investmentRef = doc(collection(db, 'investors', activeInvestor.id, 'investments'));
      const investmentId = investmentRef.id;

      const payload = {
        amount: newInvestment.amount,
        projectName,
        projectId: projectId || null,
        sector,
        description: newInvestment.description || (projectId ? `Investment in ${projectName}` : 'General Investment'),
        createdAt: new Date(newInvestment.date)
      };

      // 1. Add to investor subcollection
      await setDoc(investmentRef, payload);

      // 2. Add to global investments collection with SAME ID
      await setDoc(doc(db, 'investments', investmentId), {
        ...payload,
        investorId: activeInvestor.id,
        investorName: activeInvestor.name,
      });

      // 3. Update investor totals (Keep totalCapital constant, only update projects count and last activity)
      const investorRef = doc(db, 'investors', activeInvestor.id);
      
      // Check if this project (either by ID or manual name) is new for this investor
      const isNewProjectForInvestor = !investments.some(inv => 
        (projectId && inv.projectId === projectId) || 
        (!projectId && inv.projectName.toLowerCase() === projectName.toLowerCase())
      );
      
      const updatedProjectsCount = isNewProjectForInvestor 
        ? (activeInvestor.projects || 0) + 1 
        : (activeInvestor.projects || 0);

      await updateDoc(investorRef, {
        projects: updatedProjectsCount,
        lastActivity: 'Just now'
      });

      // 4. Update project totals if projectId exists
      if (projectId) {
        const projectRef = doc(db, 'projects', projectId);
        const proj = projects.find(p => p.id === projectId);
        if (proj) {
          // Check if this investor has already invested in this project
          const isNewInvestorForProject = !allInvestments.some(inv => 
            inv.projectId === projectId && inv.investorId === activeInvestor.id
          );
          
          await updateDoc(projectRef, {
            totalFunding: (proj.totalFunding || 0) + newInvestment.amount,
            investorCount: isNewInvestorForProject 
              ? (proj.investorCount || 0) + 1 
              : (proj.investorCount || 0)
          });
        }
      }

      // Local state update
      setSelectedInvestor({
        ...activeInvestor,
        projects: updatedProjectsCount
      });

      await addSystemNotification(
        `Asset Allocation: ৳${newInvestment.amount.toLocaleString()} allocated to "${projectName}" on behalf of ${activeInvestor.name}.`,
        `অ্যাসেট বন্টন: ${activeInvestor.name}-এর পক্ষে "${projectName}" প্রজেক্টে ৳${newInvestment.amount.toLocaleString()} বরাদ্দ করা হয়েছে।`,
        'investment'
      );

      setIsInvestmentModalOpen(false);
      setNewInvestment({ 
        projectName: '', 
        projectId: '', 
        amount: 0, 
        sector: 'Farming', 
        description: '',
        date: new Date().toLocaleDateString('sv-SE')
      });
      toast.success('Asset allocation recorded successfully');
    } catch (error) {
      toast.error('Failed to record investment');
      handleFirestoreError(error, OperationType.CREATE, 'investments');
    }
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      const proj = projects.find(p => p.id === newExpense.projectId);
      await addDoc(collection(db, 'expenses'), {
        ...newExpense,
        amount: Number(newExpense.amount),
        projectName: proj?.name || '',
        createdAt: serverTimestamp()
      });

      await addSystemNotification(
        `Expense Logged: ৳${Number(newExpense.amount).toLocaleString()} for "${proj?.name || ''}" (${newExpense.category}).`,
        `খরচ নথিভুক্ত: "${proj?.name || ''}" প্রজেক্টের জন্য ৳${Number(newExpense.amount).toLocaleString()} খরচ (${newExpense.category}) যুক্ত করা হয়েছে।`,
        'expense'
      );

      setIsExpenseModalOpen(false);
      setNewExpense({ amount: 0, description: '', category: 'Operational', projectId: '', projectName: '', date: new Date().toISOString().split('T')[0] });
      toast.success('Expense recorded successfully');
    } catch (error) {
      toast.error('Failed to record expense');
      handleFirestoreError(error, OperationType.CREATE, 'expenses');
    }
  };

  const handleAddProfit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      const proj = projects.find(p => p.id === newProfit.projectId);
      await addDoc(collection(db, 'profits'), {
        ...newProfit,
        amount: Number(newProfit.amount),
        projectName: proj?.name || '',
        createdAt: serverTimestamp()
      });

      await addSystemNotification(
        `Profit Logged: ৳${Number(newProfit.amount).toLocaleString()} derived from "${proj?.name || ''}".`,
        `লাভ নথিভুক্ত: "${proj?.name || ''}" প্রজেক্ট থেকে ৳${Number(newProfit.amount).toLocaleString()} লাভ অর্জিত হয়েছে।`,
        'profit'
      );

      setIsProfitModalOpen(false);
      setNewProfit({ amount: 0, description: '', projectId: '', projectName: '', date: new Date().toISOString().split('T')[0] });
      toast.success('Profit recorded successfully');
    } catch (error) {
      toast.error('Failed to record profit');
      handleFirestoreError(error, OperationType.CREATE, 'profits');
    }
  };

  const handleCloseBuySaleModal = () => {
    setIsBuySaleModalOpen(false);
    setEditingBuySale(null);
    setNewBuySale({
      itemName: '',
      type: 'Buy',
      quantity: 1,
      unitPrice: 0,
      projectId: '',
      partnerName: '',
      date: new Date().toISOString().split('T')[0]
    });
  };

  const handleStartEditBuySale = (record: BuySaleRecord) => {
    setEditingBuySale(record);
    setNewBuySale({
      itemName: record.itemName,
      type: record.type,
      quantity: record.quantity,
      unitPrice: record.unitPrice || 0,
      projectId: record.projectId || '',
      partnerName: record.partnerName || '',
      date: record.date || new Date().toISOString().split('T')[0]
    });
    setIsBuySaleModalOpen(true);
  };

  const handleAddBuySale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      const proj = projects.find(p => p.id === newBuySale.projectId);
      const isInitial = newBuySale.type === 'Initial';
      const unitPrice = isInitial ? 0 : Number(newBuySale.unitPrice);
      const totalAmount = isInitial ? 0 : Number(newBuySale.quantity) * Number(newBuySale.unitPrice);
      
      if (editingBuySale) {
        await updateDoc(doc(db, 'buy_sales', editingBuySale.id), {
          itemName: newBuySale.itemName,
          type: newBuySale.type,
          quantity: Number(newBuySale.quantity),
          unitPrice: unitPrice,
          totalAmount,
          projectId: newBuySale.projectId || '',
          projectName: proj?.name || '',
          partnerName: newBuySale.partnerName || '',
          date: newBuySale.date
        });
        await addSystemNotification(
          `Ledger Updated: "${newBuySale.itemName}" ledger entry updated.`,
          `লেজার পরিমার্জিত: "${newBuySale.itemName}" লেজার রেকর্ড পরিবর্তন করা হয়েছে।`,
          'ledger'
        );
        toast.success('Record updated successfully');
      } else {
        await addDoc(collection(db, 'buy_sales'), {
          itemName: newBuySale.itemName,
          type: newBuySale.type,
          quantity: Number(newBuySale.quantity),
          unitPrice: unitPrice,
          totalAmount,
          projectId: newBuySale.projectId || '',
          projectName: proj?.name || '',
          partnerName: newBuySale.partnerName || '',
          date: newBuySale.date,
          createdAt: serverTimestamp()
        });
        await addSystemNotification(
          `New Ledger Entry: Added "${newBuySale.itemName}" (${newBuySale.type}) in ledger list.`,
          `নতুন লেজার এন্ট্রি: "${newBuySale.itemName}" (${newBuySale.type}) লেজারে যুক্ত করা হয়েছে।`,
          'ledger'
        );
        toast.success('Buy/Sale record added successfully');
      }
      
      setIsBuySaleModalOpen(false);
      setEditingBuySale(null);
      setNewBuySale({
        itemName: '',
        type: 'Buy',
        quantity: 1,
        unitPrice: 0,
        projectId: '',
        partnerName: '',
        date: new Date().toISOString().split('T')[0]
      });
    } catch (error) {
      toast.error(editingBuySale ? 'Failed to update record' : 'Failed to add Buy/Sale record');
      handleFirestoreError(error, editingBuySale ? OperationType.UPDATE : OperationType.CREATE, 'buy_sales');
    }
  };

  const handleDeleteBuySale = async (id: string) => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      await deleteDoc(doc(db, 'buy_sales', id));
      await addSystemNotification(
        `Ledger Record Deleted: Removed transaction with ID ${id}.`,
        `লেজার এন্ট্রি অপসারিত: আইডি ${id}-এর রেকর্ড মুছে ফেলা হয়েছে।`,
        'ledger'
      );
      toast.success('Record deleted successfully');
    } catch (error) {
      toast.error('Failed to delete record');
      handleFirestoreError(error, OperationType.DELETE, `buy_sales/${id}`);
    }
  };

  const handleDeleteProject = async (e: React.MouseEvent, project: Project) => {
    e.stopPropagation();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      await deleteDoc(doc(db, 'projects', project.id));
      await addSystemNotification(
        `Project Removed: "${project.name}" has been deleted from system.`,
        `প্রজেক্ট অপসারিত: সিস্টেম থেকে "${project.name}" মুছে ফেলা হয়েছে।`,
        'project'
      );
      if (selectedProject?.id === project.id) {
        setSelectedProject(null);
      }
      toast.success('Project deleted successfully');
    } catch (error) {
      toast.error('Failed to delete project');
      handleFirestoreError(error, OperationType.DELETE, `projects/${project.id}`);
    }
  };

  const handleAddProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      if (editingProject) {
        await updateDoc(doc(db, 'projects', editingProject.id), {
          name: newProject.name,
          sector: newProject.sector,
          status: newProject.status
        });
        await addSystemNotification(
          `Project Updated: "${newProject.name}" has been modified.`,
          `প্রজেক্ট পরিমার্জিত: "${newProject.name}" পরিবর্তন করা হয়েছে।`,
          'project'
        );
        toast.success('Project updated successfully');
      } else {
        await addDoc(collection(db, 'projects'), {
          ...newProject,
          totalFunding: 0,
          investorCount: 0,
          createdAt: serverTimestamp()
        });
        await addSystemNotification(
          `New Project Created: "${newProject.name}" in category ${newProject.sector}.`,
          `নতুন প্রজেক্ট তৈরি: ${newProject.sector} ক্যাটাগরিতে "${newProject.name}" তৈরি করা হয়েছে।`,
          'project'
        );
        toast.success('Project created successfully');
      }
      setIsProjectModalOpen(false);
      setEditingProject(null);
      setNewProject({ name: '', sector: 'Fun House', status: 'Active' });
    } catch (error) {
      toast.error('Failed to save project');
      handleFirestoreError(error, OperationType.CREATE, 'projects');
    }
  };

  const openEditProject = (project: Project) => {
    setEditingProject(project);
    setNewProject({
      name: project.name,
      sector: project.sector,
      status: project.status
    });
    setIsProjectModalOpen(true);
  };

  const handleDeleteInvestor = async (investorId: string, name: string) => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      // Find all investments of this investor to decrease totalFunding and investorCount of projects they invested in
      const investorInvs = allInvestments.filter(inv => inv.investorId === investorId);
      
      // Group by projectId to update projects
      const projectChanges: Record<string, number> = {};
      investorInvs.forEach(inv => {
        if (inv.projectId) {
          projectChanges[inv.projectId] = (projectChanges[inv.projectId] || 0) + (inv.amount || 0);
        }
      });

      // Update project totals in Firestore
      for (const [projectId, subAmount] of Object.entries(projectChanges)) {
        const projectRef = doc(db, 'projects', projectId);
        const proj = projects.find(p => p.id === projectId);
        if (proj) {
          await updateDoc(projectRef, {
            totalFunding: Math.max((proj.totalFunding || 0) - subAmount, 0),
            investorCount: Math.max((proj.investorCount || 0) - 1, 0)
          });
        }
      }

      // Delete global investments of this investor from Firestore
      for (const inv of investorInvs) {
        await deleteDoc(doc(db, 'investments', inv.id));
      }

      // Delete the investor document
      await deleteDoc(doc(db, 'investors', investorId));

      await addSystemNotification(
        `Investor Removed: ${name} and associated accounts have been deleted.`,
        `বিনিয়োগকারী অপসারিত: ${name} এবং তার সমস্ত অ্যাকাউন্ট মুছে ফেলা হয়েছে।`,
        'investor'
      );

      if (selectedInvestor?.id === investorId) {
        setSelectedInvestor(null);
      }
      toast.success('Investor and their allocations removed successfully');
    } catch (error) {
      toast.error('Failed to remove investor');
      handleFirestoreError(error, OperationType.DELETE, `investors/${investorId}`);
    }
  };

  const handleDeleteInvestment = async (investmentId: string) => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    if (!activeInvestor) return;
    try {
      const targetInv = investments.find(inv => inv.id === investmentId);
      const subAmount = targetInv?.amount || 0;

      // Delete from investor subcollection
      await deleteDoc(doc(db, 'investors', activeInvestor.id, 'investments', investmentId));
      
      // Also delete from global collection (ID matches)
      await deleteDoc(doc(db, 'investments', investmentId));

      const remainingInv = investments.filter(inv => inv.id !== investmentId);
      const remainingProjects = new Set(
        remainingInv
          .filter(inv => inv.projectId || inv.projectName)
          .map(inv => inv.projectId || inv.projectName.toLowerCase())
      );

      // Update the investor projects count and lastActivity only
      const investorRef = doc(db, 'investors', activeInvestor.id);
      await updateDoc(investorRef, {
        projects: remainingProjects.size,
        lastActivity: 'Just now'
      });

      // Update project totals if projectId exists
      if (targetInv && targetInv.projectId) {
        const projectRef = doc(db, 'projects', targetInv.projectId);
        const proj = projects.find(p => p.id === targetInv.projectId);
        if (proj) {
          const isRemainingInvestorForProject = remainingInv.some(inv => 
            inv.projectId === targetInv.projectId && inv.investorId === activeInvestor.id
          );
          await updateDoc(projectRef, {
            totalFunding: Math.max((proj.totalFunding || 0) - subAmount, 0),
            investorCount: isRemainingInvestorForProject 
              ? (proj.investorCount || 0)
              : Math.max((proj.investorCount || 0) - 1, 0)
          });
        }
      }

      await addSystemNotification(
        `Allocation Deleted: Removed ৳${subAmount.toLocaleString()} allocation from ${activeInvestor.name}.`,
        `অ্যালোকেশন অপসারিত: ${activeInvestor.name}-এর ব্যালেন্স থেকে ৳${subAmount.toLocaleString()}-এর অ্যালোকেশন মুছে ফেলা হয়েছে।`,
        'investment'
      );

      // Local state update
      setSelectedInvestor({
        ...activeInvestor,
         projects: remainingProjects.size
      });

      toast.success('Asset allocation entry deleted');
    } catch (error) {
      toast.error('Failed to delete investment');
      handleFirestoreError(error, OperationType.DELETE, `investors/${activeInvestor.id}/investments/${investmentId}`);
    }
  };

  const handleConfirmRemovePartner = async () => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    if (!partnerToRemove) return;
    const { investorId, investorName, projectId } = partnerToRemove;
    try {
      // Find investments matching this investor under this project
      const targetInvs = allInvestments.filter(inv => inv.investorId === investorId && inv.projectId === projectId);
      const subAmount = targetInvs.reduce((sum, inv) => sum + (inv.amount || 0), 0);

      // Delete each investment
      for (const targetInv of targetInvs) {
        // Delete from subcollection if investor exists in system
        const existsInSys = investors.some(i => i.id === investorId);
        if (existsInSys) {
          await deleteDoc(doc(db, 'investors', investorId, 'investments', targetInv.id));
        }
        // Delete from global collection
        await deleteDoc(doc(db, 'investments', targetInv.id));
      }

      // If active investor in system, update their project count
      const activePartner = investors.find(i => i.id === investorId);
      if (activePartner) {
        await updateDoc(doc(db, 'investors', investorId), {
          projects: Math.max((activePartner.projects || 0) - 1, 0),
          lastActivity: 'Capital Allocation Removed'
        });
      }

      // Update project totals
      const projectRef = doc(db, 'projects', projectId);
      const proj = projects.find(p => p.id === projectId);
      if (proj) {
        await updateDoc(projectRef, {
          totalFunding: Math.max((proj.totalFunding || 0) - subAmount, 0),
          investorCount: Math.max((proj.investorCount || 0) - 1, 0)
        });
      }

      await addSystemNotification(
        `Partner Allocations Severed: Removed ${investorName} from project.`,
        `অংশীদারিত্ব বাতিল: প্রজেক্ট থেকে ${investorName}-এর অ্যালোকেশন সরানো হয়েছে।`,
        'project'
      );

      toast.success(`Removed ${investorName}'s allocations from this project`);
    } catch (error) {
      toast.error("Failed to remove partner allocations");
      handleFirestoreError(error, OperationType.DELETE, `projects/${projectId}/partners/${investorId}`);
    } finally {
      setPartnerToRemove(null);
    }
  };

  const handleDeleteExpense = async (expenseId: string) => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      const isBuySale = buySales.some(r => r.id === expenseId);
      if (isBuySale) {
        await deleteDoc(doc(db, 'buy_sales', expenseId));
        toast.success('Inventory purchase record deleted');
      } else {
        await deleteDoc(doc(db, 'expenses', expenseId));
        toast.success('Expense record deleted');
      }
      await addSystemNotification(
        `Financial Record Deleted: Removed expense entry.`,
        `আর্থিক বিবরণ অপসারিত: খরচের বিবরণী মুছে ফেলা হয়েছে।`,
        'expense'
      );
    } catch (error) {
      toast.error('Failed to delete expense');
      handleFirestoreError(error, OperationType.DELETE, `expenses/${expenseId}`);
    }
  };

  const handleDeleteProfit = async (profitId: string) => {
    if (userRole !== 'Accountant') {
      toast.error(language === 'English' ? 'Access Denied: Only Accountants are authorized to edit data.' : 'অনুমতি নেই: শুধুমাত্র অ্যাকাউন্ট্যান্ট তথ্য কাস্টমাইজ করতে পারেন।');
      return;
    }
    try {
      const isBuySale = buySales.some(r => r.id === profitId);
      if (isBuySale) {
        await deleteDoc(doc(db, 'buy_sales', profitId));
        toast.success('Inventory sale record deleted');
      } else {
        await deleteDoc(doc(db, 'profits', profitId));
        toast.success('Profit record deleted');
      }
      await addSystemNotification(
        `Financial Record Deleted: Removed profit entry.`,
        `আর্থিক বিবরণ অপসারিত: লাভের বিবরণী মুছে ফেলা হয়েছে।`,
        'profit'
      );
    } catch (error) {
      toast.error('Failed to delete profit');
      handleFirestoreError(error, OperationType.DELETE, `profits/${profitId}`);
    }
  };

  const handleDownloadExpensesCSV = () => {
    if (filteredExpenses.length === 0) {
      toast.error('No expenses to download');
      return;
    }

    const headers = ['ID', 'Description', 'Category', 'Project Name', 'Amount (BDT)', 'Date'];
    const rows = filteredExpenses.map(expense => {
      const dateStr = expense.createdAt ? formatDateShort(expense.createdAt) : '—';
      return [
        expense.id,
        `"${(expense.description || '').replace(/"/g, '""')}"`,
        `"${(expense.category || '').replace(/"/g, '""')}"`,
        `"${(expense.projectName || '—').replace(/"/g, '""')}"`,
        expense.amount,
        `"${dateStr}"`
      ];
    });

    const csvContent = "\ufeff" + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.style.visibility = 'hidden';
    link.setAttribute('href', url);
    link.setAttribute('download', `expense_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Expense ledger downloaded successfully');
  };

  const handleDownloadProfitsCSV = () => {
    if (filteredProfits.length === 0) {
      toast.error('No profits to download');
      return;
    }

    const headers = ['ID', 'Project Name', 'Description', 'Amount (BDT)', 'Date'];
    const rows = filteredProfits.map(profit => {
      const dateStr = profit.createdAt ? formatDateShort(profit.createdAt) : '—';
      return [
        profit.id,
        `"${(profit.projectName || '—').replace(/"/g, '""')}"`,
        `"${(profit.description || '').replace(/"/g, '""')}"`,
        profit.amount,
        `"${dateStr}"`
      ];
    });

    const csvContent = "\ufeff" + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.style.visibility = 'hidden';
    link.setAttribute('href', url);
    link.setAttribute('download', `profit_ledger_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Profit ledger downloaded successfully');
  };

  const handleDownloadProfitabilityCSV = () => {
    if (projectsProfitabilityData.length === 0) {
      toast.error('No project profitability report data to download');
      return;
    }

    const headers = ['Project Name', 'Sector', 'Capital Inflow (BDT)', 'Revenue (BDT)', 'Expenses (BDT)', 'Net Profit (BDT)', 'Net ROI (%)'];
    const rows = projectsProfitabilityData.map(proj => {
      return [
        `"${(proj.name || '—').replace(/"/g, '""')}"`,
        `"${(proj.sector || '—').replace(/"/g, '""')}"`,
        proj.periodFunding,
        proj.periodRevenue,
        proj.periodExpenses,
        proj.periodNetProfit,
        proj.netROI.toFixed(1)
      ];
    });

    const csvContent = "\ufeff" + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `monthly_profitability_report_${reportMonthFilter}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Monthly profitability report CSV downloaded successfully');
  };

  const handleDownloadInvestorPDF = () => {
    if (!activeInvestor) {
      toast.error('No active investor selected');
      return;
    }

    try {
      const doc = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
      });

      // --- COLOR PALETTE ---
      const navy = [30, 60, 114];
      const darkSlate = [40, 44, 52];
      const green = [16, 185, 129];
      const gray = [100, 116, 139];
      const bgGray = [241, 245, 249];

      // --- METRICS ---
      const totalCapital = activeInvestor.totalCapital || 0;
      const profitShare = selectedInvestorStats?.estimatedProfitShare || 0;
      const netWorth = selectedInvestorStats?.netWorth || 0;
      const uninvested = activeInvestorUnallocated || 0;
      const allocated = Math.max(totalCapital - uninvested, 0);

      const pageHeight = 297;
      let y = 15;

      // --- HEADER DESIGN ---
      // Primary Colored Accent Bar
      doc.setFillColor(30, 60, 114); // Navy
      doc.rect(15, y, 180, 8, 'F');
      y += 8 + 6;

      // Title & Subtitle Group
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(22);
      doc.setTextColor(30, 60, 114);
      doc.text("PARTNER PORTFOLIO SUMMARY", 15, y);
      y += 7;

      doc.setFont("Helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(100, 116, 139);
      doc.text(`CONFIDENTIAL INVESTMENT REPORT FOR ${activeInvestor.name.toUpperCase()}`, 15, y);
      y += 5;

      // Horizontal separator line
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.5);
      doc.line(15, y, 195, y);
      y += 8;

      // --- PARTNER INFORMATION CARD ---
      doc.setFontSize(11);
      doc.setFont("Helvetica", "bold");
      doc.setTextColor(40, 44, 52);
      doc.text("Partner Profile Metadata", 15, y);
      y += 5;

      // Info Table-like Layout
      doc.setFillColor(248, 250, 252);
      doc.rect(15, y, 180, 24, 'F');
      
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text("Full Name:", 20, y + 6);
      doc.text("Onboarding Status:", 20, y + 12);
      doc.text("Associated Projects:", 20, y + 18);

      doc.setFont("Helvetica", "bold");
      doc.setTextColor(40, 44, 52);
      doc.text(activeInvestor.name, 55, y + 6);
      
      const statusText = activeInvestor.status || 'Active';
      doc.setTextColor(statusText === 'Active' ? 16 : 100, statusText === 'Active' ? 185 : 116, statusText === 'Active' ? 129 : 139);
      doc.text(statusText.toUpperCase(), 55, y + 12);
      
      doc.setTextColor(40, 44, 52);
      doc.text(`${activeInvestor.projects || 0} Ventures`, 55, y + 18);

      doc.setFont("Helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text("Equity stake:", 115, y + 6);
      doc.text("Report Date:", 115, y + 12);
      doc.text("Confidentiality:", 115, y + 18);

      doc.setFont("Helvetica", "bold");
      doc.setTextColor(30, 60, 114);
      doc.text(activeInvestor.equity || "0%", 145, y + 6);
      doc.setTextColor(40, 44, 52);
      doc.text(new Date().toLocaleDateString('en-GB'), 145, y + 12);
      doc.setTextColor(239, 68, 68);
      doc.text("SECURE / RESTRICTED", 145, y + 18);

      y += 24 + 10;

      // --- FINANCIAL HIGHLIGHTS ---
      doc.setFontSize(11);
      doc.setFont("Helvetica", "bold");
      doc.setTextColor(40, 44, 52);
      doc.text("Capital Contribution & Wealth Summary", 15, y);
      y += 5;

      // Draw 3 Metric Columns
      const colW = 56;
      const colG = 6;
      
      // Card 1: Total Capital Contributions
      doc.setFillColor(241, 245, 249);
      doc.rect(15, y, colW, 20, 'F');
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text("TOTAL CONTRIBUTED", 19, y + 6);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(30, 60, 114);
      doc.text(`BDT ${totalCapital.toLocaleString()}`, 19, y + 14);

      // Card 2: Asset Allocation Details
      doc.setFillColor(241, 245, 249);
      doc.rect(15 + colW + colG, y, colW, 20, 'F');
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text("ALLOCATED ASSETS", 15 + colW + colG + 4, y + 6);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(79, 70, 229); // Indigo
      doc.text(`BDT ${allocated.toLocaleString()}`, 15 + colW + colG + 4, y + 14);

      // Card 3: Free Unallocated Reserves
      doc.setFillColor(241, 245, 249);
      doc.rect(15 + (colW + colG)*2, y, colW, 20, 'F');
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text("RETAINED CASH", 15 + (colW + colG)*2 + 4, y + 6);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(100, 116, 139);
      doc.text(`BDT ${uninvested.toLocaleString()}`, 15 + (colW + colG)*2 + 4, y + 14);

      y += 20 + colG;

      // Draw 2 wide profit/wealth cards
      const halfColW = 87;
      
      // Card 4: Estimated Profit Share Target
      doc.setFillColor(236, 253, 245); // Light mint
      doc.rect(15, y, halfColW, 20, 'F');
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(5, 150, 105);
      doc.text("PROJECTED NET PROFIT YIELD (YTD)", 19, y + 6);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(16, 185, 129); // Green
      doc.text(`+BDT ${profitShare.toLocaleString()}`, 19, y + 14);

      // Card 5: Estimated Portfolio Net Worth
      doc.setFillColor(239, 246, 255); // Light sky
      doc.rect(15 + halfColW + colG, y, halfColW, 20, 'F');
      doc.setFont("Helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(29, 78, 216);
      doc.text("ESTIMATED PORTFOLIO NET WORTH", 15 + halfColW + colG + 4, y + 6);
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(30, 60, 114);
      doc.text(`BDT ${netWorth.toLocaleString()}`, 15 + halfColW + colG + 4, y + 14);

      y += 20 + 12;

      // --- SECTION 1: ASSET DEPLOYMENT (TABLE) ---
      doc.setFontSize(11);
      doc.setFont("Helvetica", "bold");
      doc.setTextColor(40, 44, 52);
      doc.text("Asset Deployment Ledger", 15, y);
      y += 5;

      // Table Header Row
      doc.setFillColor(30, 60, 114);
      doc.rect(15, y, 180, 8, 'F');
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(255, 255, 255);
      doc.text("Project / Asset", 18, y + 5.5);
      doc.text("Sector", 68, y + 5.5);
      doc.text("Date Allocated", 110, y + 5.5);
      doc.text("Capital Injected", 155, y + 5.5);
      y += 8;

      // Table Data
      if (investments.length === 0) {
        doc.setFont("Helvetica", "italic");
        doc.setFontSize(9);
        doc.setTextColor(148, 163, 184);
        doc.rect(15, y, 180, 10);
        doc.text("No active capital allocations recorded for this partner.", 20, y + 6.5);
        y += 10 + 10;
      } else {
        doc.setFont("Helvetica", "normal");
        doc.setFontSize(8.5);
        doc.setTextColor(64, 64, 64);
        
        investments.forEach((rec, idx) => {
          // Alt background colors
          if (idx % 2 === 0) {
            doc.setFillColor(248, 250, 252);
            doc.rect(15, y, 180, 9, 'F');
          }
          doc.setDrawColor(241, 245, 249);
          doc.line(15, y+9, 195, y+9);

          doc.setFont("Helvetica", "bold");
          doc.setTextColor(40, 44, 52);
          doc.text(rec.projectName || '—', 18, y + 6);
          
          doc.setFont("Helvetica", "normal");
          doc.setTextColor(100, 116, 139);
          doc.text(rec.sector || '—', 68, y + 6);
          doc.text(rec.createdAt ? formatDateShort(rec.createdAt) : '—', 110, y + 6);
          
          doc.setFont("Helvetica", "bold");
          doc.setTextColor(30, 60, 114);
          doc.text(`BDT ${rec.amount.toLocaleString()}`, 155, y + 6);
          
          y += 9;
        });
        y += 8;
      }

      // Check if page overflow will happen for Section 2 (needs approximately 55mm space)
      if (y > pageHeight - 55) {
        doc.addPage();
        y = 20;
      }

      // --- SECTION 2: TOP-UP HISTORY (TABLE) ---
      doc.setFontSize(11);
      doc.setFont("Helvetica", "bold");
      doc.setTextColor(40, 44, 52);
      doc.text("Capital Contribution & Cash Inbound History", 15, y);
      y += 5;

      // Table Header Row
      doc.setFillColor(30, 60, 114);
      doc.rect(15, y, 180, 8, 'F');
      doc.setFont("Helvetica", "bold");
      doc.setFontSize(8.5);
      doc.setTextColor(255, 255, 255);
      doc.text("Transaction Description", 18, y + 5.5);
      doc.text("Date Recorded", 100, y + 5.5);
      doc.text("Injected Amount", 155, y + 5.5);
      y += 8;

      // Table Data
      if (topUps.length === 0) {
        doc.setFont("Helvetica", "italic");
        doc.setFontSize(9);
        doc.setTextColor(148, 163, 184);
        doc.rect(15, y, 180, 10);
        doc.text("No capital injection activity recorded.", 20, y + 6.5);
        y += 10;
      } else {
        doc.setFont("Helvetica", "normal");
        doc.setFontSize(8.5);
        doc.setTextColor(64, 64, 64);

        topUps.forEach((rec, idx) => {
          if (idx % 2 === 0) {
            doc.setFillColor(248, 250, 252);
            doc.rect(15, y, 180, 9, 'F');
          }
          doc.setDrawColor(241, 245, 249);
          doc.line(15, y+9, 195, y+9);

          doc.setFont("Helvetica", "normal");
          doc.setTextColor(40, 44, 52);
          doc.text(rec.description || 'Capital Top Up', 18, y + 6);
          doc.setTextColor(100, 116, 139);
          doc.text(formatDateShort(rec.createdAt || rec.date), 100, y + 6);
          
          doc.setFont("Helvetica", "bold");
          doc.setTextColor(16, 185, 129); // Green tint for cash infusion
          doc.text(`+BDT ${rec.amount.toLocaleString()}`, 155, y + 6);

          y += 9;
        });
      }

      y = Math.min(y + 12, pageHeight - 30);

      // --- DISCLOSURE BANNER / FOOTER ---
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.5);
      doc.line(15, y, 195, y);
      y += 6;

      doc.setFont("Helvetica", "italic");
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text("This security report is generated in real-time under permission protocols. The figures represent estimates governed", 15, y);
      y += 3.5;
      doc.text("by initial equity ratios and current project cash flow distributions as recorded in the active ledger indices.", 15, y);

      // Save document
      doc.save(`partner_summary_${activeInvestor.name.toLowerCase().replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`);
      toast.success('Summary PDF Report downloaded successfully!');
    } catch (err) {
      console.error(err);
      toast.error('Failed to generate PDF report.');
    }
  };

  // --- Chart Configurations ---
  const lineChartData = useMemo(() => {
    const months = ['Apr 2026', 'May 2026', 'Jun 2026', 'Jul 2026', 'Aug 2026', 'Sep 2026', 'Oct 2026', 'Nov 2026'];
    
    // Determine which projects we want to render lines for
    const activeProjectsList = projectFilter === 'all' 
      ? projects 
      : projects.filter(p => p.id === projectFilter);

    // If there are no projects, return empty labels/datasets
    if (activeProjectsList.length === 0) {
      return {
        labels: months,
        datasets: []
      };
    }

    const colors = [
      '#1e3c72', // Corporate Navy
      '#10b981', // Emerald
      '#f59e0b', // Amber
      '#ec4899', // Pink
      '#8b5cf6', // Indigo/Violet
      '#3b82f6', // Bright Blue
    ];

    const datasets = activeProjectsList.map((proj, idx) => {
      const dataByMonth = new Array(8).fill(0);
      let preAprilInflow = 0;

      // Filter investments for this specific project
      const projInvs = allInvestments.filter(inv => inv.projectId === proj.id);

      projInvs.forEach(inv => {
        const d = getInvestmentDate(inv.createdAt);
        if (!d) return;

        // Compare date to April 1st, 2026
        const aprilFirst = new Date('2026-04-01T00:00:00Z');
        if (d < aprilFirst) {
          preAprilInflow += inv.amount || 0;
        } else {
          // Identify month index in 2026 starting April (which is month 3)
          const yr = d.getFullYear();
          const mo = d.getMonth(); // 0 is Jan, 3 is Apr
          const monthIndex = (yr - 2026) * 12 + mo - 3;
          if (monthIndex >= 0 && monthIndex < 8) {
            dataByMonth[monthIndex] += inv.amount || 0;
          } else if (monthIndex >= 8) {
            // Put extra into the last month (Nov 2026)
            dataByMonth[7] += inv.amount || 0;
          }
        }
      });

      // Cumulative calculation starting from pre-April inflow
      let cumulative = preAprilInflow;
      const cumulativeData = dataByMonth.map(val => {
        cumulative += val;
        return cumulative;
      });

      const color = colors[idx % colors.length];

      return {
        label: proj.name,
        data: cumulativeData,
        fill: false,
        borderColor: color,
        borderWidth: 3,
        tension: 0.3,
        pointRadius: 4,
        pointBackgroundColor: color,
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointHoverRadius: 6,
      };
    });

    return {
      labels: months,
      datasets
    };
  }, [allInvestments, projects, projectFilter]);

  const investmentDistributionChartData = useMemo(() => {
    const groupMap: Record<string, number> = {};
    const activeProjectIds = new Set(projects.map(p => p.id));
    const activeInvestments = allInvestments.filter(i => activeProjectIds.has(i.projectId));

    const filteredInv = projectFilter === 'all'
      ? activeInvestments
      : activeInvestments.filter(i => i.projectId === projectFilter);

    if (projectFilter === 'all' || !projectFilter) {
      // Group by project name
      filteredInv.forEach(inv => {
        const name = inv.projectName || 'Unassigned';
        groupMap[name] = (groupMap[name] || 0) + (inv.amount || 0);
      });
    } else {
      // Group by investor name for the specific project
      filteredInv.forEach(inv => {
        const name = inv.investorName || 'Unknown Partner';
        groupMap[name] = (groupMap[name] || 0) + (inv.amount || 0);
      });
    }

    const labels = Object.keys(groupMap).length > 0 ? Object.keys(groupMap) : ['No Investment'];
    const data = Object.values(groupMap).length > 0 ? Object.values(groupMap) : [0];

    const colors = [
      '#1e3c72',
      '#2a5298',
      '#10b981',
      '#3b82f6',
      '#60a5fa',
      '#93c5fd',
      '#bfdbfe'
    ];

    return {
      labels,
      datasets: [
        {
          data,
          backgroundColor: colors.slice(0, Math.max(labels.length, 1)),
          borderWidth: 0,
          hoverOffset: 12,
        },
      ],
    };
  }, [allInvestments, projects, projectFilter]);

  const expensesChartData = useMemo(() => {
    const groupMap: Record<string, number> = {};
    const filteredExps = projectFilter === 'all'
      ? expenses
      : expenses.filter(e => e.projectId === projectFilter);

    if (projectFilter === 'all' || !projectFilter) {
      // Group by project name
      filteredExps.forEach(exp => {
        const name = exp.projectName || 'Unassigned';
        groupMap[name] = (groupMap[name] || 0) + (exp.amount || 0);
      });
    } else {
      // Group by category for the specific project
      filteredExps.forEach(exp => {
        const cat = exp.category || 'Other';
        groupMap[cat] = (groupMap[cat] || 0) + (exp.amount || 0);
      });
    }

    const labels = Object.keys(groupMap).length > 0 ? Object.keys(groupMap) : ['No Expenses'];
    const data = Object.values(groupMap).length > 0 ? Object.values(groupMap) : [0];

    const colors = [
      '#ef4444', // Red-500
      '#f97316', // Orange-500
      '#f59e0b', // Amber-500
      '#ec4899', // Pink-500
      '#8b5cf6', // Violet-500
      '#e11d48', // Rose-600
    ];

    return {
      labels,
      datasets: [
        {
          data,
          backgroundColor: colors.slice(0, Math.max(labels.length, 1)),
          borderWidth: 0,
          hoverOffset: 12,
        },
      ],
    };
  }, [expenses, projectFilter]);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1E293B',
        padding: 12,
        titleFont: { size: 14 },
        bodyFont: { size: 13 },
        cornerRadius: 8,
      },
    },
    scales: {
      y: {
        display: false,
        grid: { display: false },
      },
      x: {
        grid: { display: false },
        ticks: { 
          color: '#94a3b8', 
          font: { size: 11, weight: '500' as const } 
        },
      },
    },
  };

  const donutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '70%',
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1E293B',
        padding: 12,
        titleFont: { size: 14 },
        bodyFont: { size: 13 },
        cornerRadius: 8,
      },
    }
  };

  const topInvShare = useMemo(() => {
    const data = investmentDistributionChartData.datasets[0].data;
    const labels = investmentDistributionChartData.labels;
    if (!data || data.length === 0 || data[0] === 0) return { pct: '0%', label: 'No Data' };
    const total = data.reduce((sum, val) => sum + val, 0);
    if (total === 0) return { pct: '0%', label: 'No Data' };
    
    let maxVal = 0;
    let maxIdx = 0;
    data.forEach((val, i) => {
      if (val > maxVal) {
        maxVal = val;
        maxIdx = i;
      }
    });
    const pct = ((maxVal / total) * 100).toFixed(0);
    return { pct: `${pct}%`, label: labels[maxIdx] || 'Project' };
  }, [investmentDistributionChartData]);

  if (authLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-corporate-navy border-t-transparent"></div>
          <p className="text-sm font-medium text-gray-500 animate-pulse">
            {language === 'English' ? 'Verifying Credentials...' : 'ক্রিডেনশিয়াল যাচাই করা হচ্ছে...'}
          </p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="flex min-h-screen bg-gray-50 flex-col justify-center py-12 sm:px-6 lg:px-8">
        <Toaster position="top-right" />
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center">
            <div className="bg-gradient-to-r from-corporate-navy to-corporate-blue p-3.5 rounded-2xl shadow-xl">
              <TrendingUp className="text-white" size={32} />
            </div>
          </div>
          <h2 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-950">
            {language === 'English' ? 'Welcome to CapitalHub' : 'ক্যাপিটালহাব-এ স্বাগতম'}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            {language === 'English' ? 'Sought-after Investment Ledger & Management Suite' : 'বিনিয়োগ লেজার এবং ম্যানেজমেন্ট স্যুইট'}
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
          <div className="bg-white py-8 px-6 shadow-xl rounded-2xl border border-gray-100 sm:px-10">
            {/* Direct Email Access Block */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  {language === 'English' ? 'Email Address' : 'ইমেইল এড্রেস'}
                </label>
                <div className="mt-1">
                  <input
                    id="email-input"
                    name="email"
                    type="email"
                    required
                    placeholder="partner@capitalhub.com"
                    defaultValue="mdm813312@gmail.com"
                    className="block w-full rounded-xl border border-gray-300 py-2.5 px-3.5 shadow-sm focus:border-corporate-navy focus:outline-none focus:ring-1 focus:ring-corporate-navy sm:text-sm"
                  />
                </div>
                <p className="text-xs text-amber-600 mt-1.5 font-medium leading-relaxed">
                  {language === 'English' ? '💡 Tip: Enter "mdm813312@gmail.com" to log in as default Accountant.' : '💡 পরামর্শ: "mdm813312@gmail.com" দিয়ে লগ-ইন করলে অ্যাকাউন্ট্যান্ট মোড সক্রিয় হবে।'}
                </p>
              </div>

              <div>
                <button
                  onClick={() => {
                    const el = document.getElementById('email-input') as HTMLInputElement;
                    handleEmailDirectAccess(el?.value || '');
                  }}
                  className="flex w-full justify-center rounded-xl bg-corporate-navy py-2.5 px-4 text-sm font-semibold text-white shadow-md hover:bg-opacity-95 focus:outline-none transition-all duration-200"
                >
                  {language === 'English' ? 'Instant Secure Login' : 'ইনস্ট্যান্ট সিকিউর লগইন'}
                </button>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="bg-white px-3 text-gray-500 font-medium">
                    {language === 'English' ? 'Or Continue With' : 'অথবা অন্য উপায়ে'}
                  </span>
                </div>
              </div>

              <div>
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  className="flex w-full items-center justify-center gap-3 rounded-xl border border-gray-300 bg-white py-2.5 px-4 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none transition-all duration-200"
                >
                  <svg className="h-5 w-5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v3.91h6.58c-.28 1.48-1.11 2.73-2.36 3.58v2.98h3.81c2.23-2.05 3.51-5.07 3.51-8.4z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.97-1.08 7.96-2.91l-3.81-2.98c-1.06.71-2.42 1.13-4.15 1.13-3.2 0-5.91-2.16-6.87-5.07H1.32v3.08C3.33 21.88 7.39 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.13 14.17c-.24-.71-.38-1.48-.38-2.27 0-.79.14-1.56.38-2.27V6.55H1.32C.48 8.23 0 10.06 0 12s.48 3.77 1.32 5.45l3.81-3.28z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.44-3.44C17.96 1.19 15.24 0 12 0 7.39 0 3.33 2.12 1.32 5.45l3.81 3.08c.96-2.91 3.67-5.07 6.87-5.07"
                    />
                  </svg>
                  <span className="font-semibold text-gray-800">
                    {language === 'English' ? 'Sign in with Google' : 'গুগল দিয়ে সাইন ইন করুন'}
                  </span>
                </button>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-100">
              <div className="rounded-xl bg-slate-50 p-3 text-xs text-gray-600 leading-relaxed font-normal">
                {language === 'English' ? (
                  <p>
                    🔒 <strong>Enterprise-Grade Security Hook:</strong> Permissions are evaluated strictly client-side & server-side using secure Firestore rules and metadata triggers.
                  </p>
                ) : (
                  <p>
                    🔒 <strong>এন্টারপ্রাইজ সিকিউরিটি প্রোটোকল:</strong> ফায়ারস্টোর সিকিউরিটি নিয়মনীতি অনুযায়ী ক্লায়েন্ট এবং সার্ভার উভয় পাশেই স্বয়ংক্রিয়ভাবে সুরক্ষাবলয় নিশ্চিত করা হয়েছে।
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-page-bg overflow-hidden font-sans">
      <Toaster position="top-right" />
      {/* --- Sidebar --- */}
      <aside className="w-64 bg-gradient-to-b from-corporate-navy to-corporate-blue p-6 flex flex-col hidden lg:flex">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="bg-white/20 p-2 rounded-lg backdrop-blur-md">
            <TrendingUp className="text-white" size={24} />
          </div>
          <h1 className="text-white font-bold text-xl tracking-tight uppercase">CapitalHub</h1>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarItem icon={LayoutDashboard} label={language === 'English' ? 'Overview' : 'ওভারভিউ'} active={activeTab === 'Overview'} onClick={() => setActiveTab('Overview')} />
          <SidebarItem icon={Users} label={language === 'English' ? 'Investors' : 'বিনিয়োগকারীগণ'} active={activeTab === 'Investors'} onClick={() => { setActiveTab('Investors'); setSelectedInvestor(null); }} />
          <SidebarItem icon={BarChart3} label={language === 'English' ? 'Projects' : 'প্রজেক্টসমূহ'} active={activeTab === 'Projects'} onClick={() => { setActiveTab('Projects'); setSelectedProject(null); }} />
          <SidebarItem icon={ShoppingBag} label={language === 'English' ? 'Buy & Sales' : 'ক্রয় ও বিক্রয়'} active={activeTab === 'BuySales'} onClick={() => setActiveTab('BuySales')} />
          <SidebarItem icon={FileText} label={language === 'English' ? 'Profit & Expenses' : 'লাভ ও ক্ষতি'} active={activeTab === 'Expenses'} onClick={() => setActiveTab('Expenses')} />
          <SidebarItem icon={TrendingUp} label={language === 'English' ? 'Profit Analytics' : 'লাভ বিশ্লেষণ'} active={activeTab === 'Profit Analytics'} onClick={() => setActiveTab('Profit Analytics')} />
        </nav>

        <div className="mt-auto space-y-2 border-t border-white/10 pt-6">
          <SidebarItem icon={Settings} label={language === 'English' ? 'Settings' : 'সেটিংস'} active={activeTab === 'Settings'} onClick={() => setActiveTab('Settings')} />
          <SidebarItem icon={Bot} label={language === 'English' ? 'AI Chat bot' : 'এআই চ্যাট বট'} active={isChatOpen} onClick={() => setIsChatOpen(!isChatOpen)} />
          
          <div className="bg-white/10 p-3 rounded-xl border border-white/5 space-y-2.5 mt-2">
            <div className="flex flex-col">
              <span className="text-white text-xs font-semibold truncate">
                {currentUser?.displayName || currentUser?.email || 'User'}
              </span>
              <span className="text-white/60 text-[10px] font-mono tracking-wider mt-0.5">
                {userRole === 'Accountant' ? '💼 ACCOUNTANT (ADMIN)' : '📈 INVESTOR (READONLY)'}
              </span>
            </div>
            <button
              onClick={handleSignOut}
              className="w-full text-left flex items-center gap-2 text-red-200 hover:text-white text-xs font-semibold py-1.5 transition-all"
            >
              <LogOut size={14} /> {language === 'English' ? 'Sign Out' : 'সাইন আউট'}
            </button>
          </div>
        </div>
      </aside>

      {/* --- Main Content --- */}
      <main className="flex-1 overflow-y-auto p-4 lg:p-8 pb-24 lg:pb-8">
        {/* Header */}
        <header className={`flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4 p-6 rounded-2xl shadow-sm border transition-colors duration-300 ${theme === 'dark' ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-100'}`}>
          <div>
            <h2 className={`text-2xl font-bold transition-colors duration-300 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {getHeaderTitle()}
            </h2>
            <p className={`text-sm mt-1 transition-colors duration-300 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {getHeaderSub()}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {(activeTab === 'Overview' || activeTab === 'Expenses' || activeTab === 'Profit Analytics' || activeTab === 'BuySales') && (
              <div className="flex items-center gap-3">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap">Project Filter:</label>
                <select 
                  value={projectFilter}
                  onChange={(e) => setProjectFilter(e.target.value)}
                  className="bg-gray-50 border border-gray-200 text-gray-700 py-2 px-4 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-corporate-navy/20"
                >
                  <option value="all">All Projects</option>
                  {projects.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
            )}
            {activeTab === 'Investors' && (
              <button 
                onClick={() => setIsModalOpen(true)}
                className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-corporate-navy text-white rounded-xl text-sm font-bold shadow-lg shadow-corporate-navy/20 hover:bg-corporate-blue transition-all"
              >
                + Add New Investor
              </button>
            )}
            {activeTab === 'Projects' && (
              <button 
                onClick={() => setIsProjectModalOpen(true)}
                className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-corporate-navy text-white rounded-xl text-sm font-bold shadow-lg shadow-corporate-navy/20 hover:bg-corporate-blue transition-all"
              >
                + Create New Project
              </button>
            )}
            {activeTab === 'BuySales' && (
              <button 
                onClick={() => {
                  setEditingBuySale(null);
                  setNewBuySale({
                    itemName: '',
                    type: 'Buy',
                    quantity: 1,
                    unitPrice: 0,
                    projectId: '',
                    partnerName: '',
                    date: new Date().toISOString().split('T')[0]
                  });
                  setIsBuySaleModalOpen(true);
                }}
                className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-corporate-navy text-white rounded-xl text-sm font-bold shadow-lg shadow-corporate-navy/20 hover:bg-corporate-blue transition-all"
              >
                + Record Buy/Sale
              </button>
            )}
            {activeTab === 'Expenses' && (
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setIsProfitModalOpen(true)}
                  className="hidden md:flex items-center gap-2 px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all"
                >
                  + Record Profit
                </button>
                <button 
                  onClick={() => setIsExpenseModalOpen(true)}
                  className="hidden md:flex items-center gap-2 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-red-600/20 hover:bg-red-700 transition-all"
                >
                  + Record Expense
                </button>
              </div>
            )}
            {(activeTab === 'Investors' || activeTab === 'BuySales') && (
              <div className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-corporate-navy" size={18} />
                <input 
                  type="text" 
                  placeholder={
                    activeTab === 'Investors' 
                      ? "Search investors..." 
                      : "Search products or partners..."
                  }
                  className="bg-white border border-gray-200 rounded-xl pl-10 pr-4 py-2 text-sm w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-corporate-navy/20 focus:border-corporate-navy transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            )}
          </div>
        </header>

        {activeTab === 'Overview' ? (
          <>
            {/* Metrics Row */}
            <div className="flex flex-wrap gap-3 mb-8">
              <button 
                onClick={() => {
                  setDashboardModalTab('new_investor');
                  setIsDashboardInvestmentModalOpen(true);
                }}
                className="bg-corporate-navy hover:bg-corporate-blue text-white font-bold py-3 px-6 rounded-xl shadow-lg shadow-corporate-navy/20 transition cursor-pointer text-sm flex items-center gap-1.5"
              >
                + Add Investment / Partner
              </button>
              <button 
                onClick={() => setIsExpenseModalOpen(true)} 
                className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg shadow-red-600/20 transition cursor-pointer text-sm"
              >
                + Record Expense
              </button>
              <button 
                onClick={() => setIsProfitModalOpen(true)} 
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg shadow-emerald-600/20 transition cursor-pointer text-sm"
              >
                + Record Profit
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
              <MetricCard 
                title={language === 'English' ? "Total Capital Raised" : "মোট সংগৃহীত মূলধন"}
                value={formatVal(stats.totalCapital)} 
                badge={language === 'English' ? "Cumulative" : "সঞ্চিত"} 
                badgeColor="bg-blue-100 text-blue-700"
                icon={Wallet}
                isDark={theme === 'dark'}
              />
              <MetricCard 
                title={language === 'English' ? "Uninvested Capital" : "অব্যবহৃত মূলধন"}
                value={formatVal(stats.unallocatedCapital)} 
                badge={language === 'English' ? "Reserve" : "রিজার্ভ"} 
                badgeColor="bg-indigo-100 text-indigo-700"
                icon={Coins}
                isDark={theme === 'dark'}
                onClick={() => {
                  if (stats.unallocatedCapital > 0) {
                    setSelectedInvestor(null);
                    setShowOnlyWithUnusedCapital(true);
                    setActiveTab('Investors');
                  }
                }}
              />
              <MetricCard 
                title={language === 'English' ? "Total Project Expenses" : "মোট প্রকল্প ব্যয়"}
                value={formatVal(stats.totalExpenses)} 
                badge={language === 'English' ? "Multi-phase" : "বহু-ধাপ"} 
                badgeColor="bg-red-100 text-red-700"
                icon={ShieldAlert}
                isDark={theme === 'dark'}
              />
              <MetricCard 
                title={language === 'English' ? "Total Earned Profits" : "মোট অর্জিত লাভ"}
                value={formatVal(stats.totalProfits)} 
                badge={language === 'English' ? "Revenue" : "রাজস্ব"} 
                badgeColor="bg-emerald-100 text-emerald-700"
                icon={TrendingUp}
                isDark={theme === 'dark'}
              />
              <MetricCard 
                title={language === 'English' ? "Available Balance" : "উপলব্ধ ব্যালেন্স"}
                value={formatVal(stats.availableCash)} 
                badge={language === 'English' ? "Liquidity" : "তারল্য"} 
                badgeColor="bg-amber-100 text-amber-700"
                icon={Users}
                isDark={theme === 'dark'}
              />
            </div>

            {/* Analytics Section */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
              {/* Distribution Chart */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="lg:col-span-3 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"
              >
                <h4 className="text-sm font-bold text-gray-900 mb-6 flex items-center gap-2 text-wrap">
                   <PieChartIcon size={16} className="text-corporate-navy" />
                   Investment Distribution
                </h4>
                <div className="h-48 relative">
                  <Doughnut data={investmentDistributionChartData} options={donutOptions as any} />
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-xl font-bold text-gray-800">{topInvShare.pct}</span>
                    <span className="text-[9px] text-gray-400 font-bold uppercase tracking-widest text-center px-2 truncate max-w-full">{topInvShare.label}</span>
                  </div>
                </div>
                <div className="mt-6 flex flex-wrap gap-4 justify-center max-h-20 overflow-y-auto pr-1">
                  {investmentDistributionChartData.labels.map((label, i) => (
                    <div key={label} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: investmentDistributionChartData.datasets[0].backgroundColor[i] }}></div>
                      <span className="text-xs text-gray-500 font-medium">{label}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Trend and Sector distribution */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="lg:col-span-6 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm"
              >
                <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
                  <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <TrendingUp size={16} className="text-corporate-navy" />
                    Capital Inflow Trend (From April 2026)
                  </h4>
                  <div className="flex flex-wrap gap-2 max-w-xs justify-end">
                    {lineChartData.datasets.map((ds: any, idx: number) => (
                      <span key={ds.label || idx} className="flex items-center gap-1 text-[9px] font-bold text-gray-500 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded-md">
                        <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: ds.borderColor }}></div>
                        <span className="truncate max-w-[70px]">{ds.label}</span>
                      </span>
                    ))}
                  </div>
                </div>
                <div className="h-64">
                  <Line data={lineChartData} options={chartOptions as any} />
                </div>
              </motion.div>

              {/* Live Expenses PieChart */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="lg:col-span-3 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <h4 className="text-sm font-bold text-gray-950 mb-6 flex items-center gap-2 text-wrap">
                   <PieChartIcon size={16} className="text-red-500" />
                   Live Expenses Distribution
                </h4>
                <div className="h-48 relative">
                  <Doughnut data={expensesChartData} options={donutOptions as any} />
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Total Expenses</span>
                    <span className="text-sm font-extrabold text-red-600">৳{stats.totalExpenses.toLocaleString()}</span>
                  </div>
                </div>
                <div className="mt-6 flex flex-col gap-2 max-h-24 overflow-y-auto pr-1">
                  {expensesChartData.labels.map((label, i) => {
                    const value = expensesChartData.datasets[0].data[i] || 0;
                    const totalVal = expensesChartData.datasets[0].data.reduce((sum, v) => sum + v, 0) || 1;
                    const percent = ((value / totalVal) * 100).toFixed(0);
                    return (
                      <div key={label} className="flex justify-between items-center">
                        <div className="flex items-center gap-2 max-w-[60%]">
                          <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: expensesChartData.datasets[0].backgroundColor[i] }}></div>
                          <span className="text-[10px] text-gray-500 font-bold uppercase truncate">{label}</span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-[10px] font-bold text-gray-900">৳{value.toLocaleString()}</span>
                          <span className="text-[9px] text-red-500 font-semibold shrink-0">({percent}%)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            </div>

            {/* Bottom Data Section (Two Columns) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-8">
              {/* Left Column: Investors & Share Summary */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="lg:col-span-7 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                  <div className="flex items-center gap-2">
                    <Users className="text-corporate-navy" size={18} />
                    <h4 className="text-sm font-bold text-gray-900">Investor Share Summary</h4>
                  </div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Cumulative Profiles</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-gray-50">
                        <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Investor</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capital Injected</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Profit Share (%)</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Payout</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Join Date</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {filteredInvestorsForSummary.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-sm text-gray-400 font-medium">
                            No active investments recorded for this project yet.
                          </td>
                        </tr>
                      ) : (
                        filteredInvestorsForSummary.map((investor) => (
                          <tr key={investor.id} className="hover:bg-gray-50/50 transition-colors">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-corporate-navy text-white flex items-center justify-center text-[10px] font-bold">
                                  {investor.name.charAt(0)}
                                </div>
                                <span className="text-sm font-bold text-gray-900">{investor.name}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm font-bold text-gray-900 uppercase">৳{investor.capitalInjected.toLocaleString()}</td>
                            <td className="px-6 py-4">
                              <div className="flex flex-col gap-1">
                                <span className="text-sm font-bold text-corporate-navy">{investor.shareText}</span>
                                <div className="w-20 h-1 bg-gray-100 rounded-full overflow-hidden">
                                  <div className="h-full bg-corporate-navy" style={{ width: investor.shareText }}></div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm font-bold text-emerald-600">
                               ৳{investor.payout.toLocaleString()}
                            </td>
                            <td className="px-6 py-4 text-[11px] font-semibold text-gray-500 whitespace-nowrap">
                              {formatFullJoinedDate(investor.createdAt || investor.date)}
                            </td>
                            <td className="px-6 py-4">
                              <StatusBadge status={investor.status} />
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </motion.div>

              {/* Right Column: Detailed Transaction Log */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="lg:col-span-5 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
              >
                <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                  <div className="flex items-center gap-2">
                    <FileText className="text-corporate-navy" size={18} />
                    <h4 className="text-sm font-bold text-gray-900">Recent Transactions Log</h4>
                  </div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Real-time Feed</span>
                </div>
                <div className="p-6">
                  <div className="space-y-6">
                    {[
                      ...allInvestments
                        .filter(item => investors.some(i => i.id === item.investorId))
                        .map(item => ({ ...item, logType: 'investment' as const })),
                      ...expenses.map(item => ({ ...item, logType: 'expense' as const })),
                      ...profits.map(item => ({ ...item, logType: 'profit' as const })),
                      ...buySales.map(item => ({
                        ...item,
                        logType: (item.type === 'Buy' ? 'buy' : 'sale') as any,
                        amount: item.totalAmount || 0,
                        description: `${item.type === 'Buy' ? 'Purchase' : 'Sale'}: ${item.itemName} (${item.quantity} units${item.partnerName ? ` from/to ${item.partnerName}` : ''})`
                      }))
                    ]
                      .filter(log => projectFilter === 'all' || ('projectId' in log && log.projectId === projectFilter))
                      .filter(log => {
                        if (!searchTerm) return true;
                        const s = searchTerm.toLowerCase();
                        const desc = (log.description || '').toLowerCase();
                        const invName = (log.investorName || '').toLowerCase();
                        const projName = (log.projectName || '').toLowerCase();
                        const cat = (log.category || '').toLowerCase();
                        const partner = (log.partnerName || '').toLowerCase();
                        const item = (log.itemName || '').toLowerCase();
                        return desc.includes(s) || invName.includes(s) || projName.includes(s) || cat.includes(s) || partner.includes(s) || item.includes(s);
                      })
                      .sort((a, b) => {
                        const getMs = (item: any) => {
                          if (!item) return 0;
                          const rawDate = item.createdAt;
                          if (!rawDate) return 0;
                          const d = rawDate.toDate ? rawDate.toDate() : new Date(rawDate);
                          return isNaN(d.getTime()) ? 0 : d.getTime();
                        };
                        return getMs(b) - getMs(a);
                      })
                      .slice(0, 20)
                      .map((log: any, i, arr) => {
                        const isInvestment = log.logType === 'investment';
                        const isProfit = log.logType === 'profit';
                        const isExpense = log.logType === 'expense';
                        const isBuy = log.logType === 'buy';
                        const isSale = log.logType === 'sale';

                        let color = 'bg-blue-50 text-blue-600';
                        let Icon = ArrowUpRight;
                        let amountPrefix = '+৳';

                        if (isProfit) {
                          color = 'bg-emerald-50 text-emerald-600';
                          amountPrefix = 'Profit: +৳';
                        } else if (isExpense) {
                          color = 'bg-red-50 text-red-600';
                          Icon = ArrowUpRight;
                          amountPrefix = 'Expense: -৳';
                        } else if (isBuy) {
                          color = 'bg-amber-50 text-amber-700';
                          Icon = ArrowUpRight;
                          amountPrefix = 'Purchase: -৳';
                        } else if (isSale) {
                          color = 'bg-emerald-50 text-emerald-600';
                          Icon = ArrowUpRight;
                          amountPrefix = 'Sale: +৳';
                        }

                        return (
                          <div key={log.id || i} className="flex gap-4 relative">
                            {i !== arr.length - 1 && <div className="absolute left-4 top-8 w-px h-10 bg-gray-100"></div>}
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm ${color}`}>
                              <Icon size={14} className={(isExpense || isBuy) ? 'rotate-180' : ''} />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start">
                                <p className="text-xs font-bold text-gray-900">
                                  {isInvestment ? `${log.investorName} - ${log.description}` : 
                                   isProfit ? `${log.projectName || 'Project'} - ${log.description}` : 
                                   isExpense ? `${log.projectName || 'Project'} - ${log.description}` : 
                                   isBuy ? `${log.projectName || 'Project'} - ${log.description}` : 
                                   isSale ? `${log.projectName || 'Project'} - ${log.description}` : log.description}
                                </p>
                                <span className={`text-xs font-bold ${color.split(' ')[1]}`}>
                                  {amountPrefix}{(log.amount || 0).toLocaleString()}
                                </span>
                              </div>
                              <p className="text-[10px] text-gray-400 mt-1 uppercase font-bold tracking-widest">
                                {formatDateShort(log.createdAt || log.date)}
                              </p>
                            </div>
                          </div>
                      )})}
                  </div>
                  {allInvestments.length === 0 && expenses.length === 0 && profits.length === 0 && buySales.length === 0 && (
                    <div className="text-center py-10">
                      <p className="text-xs text-gray-400 font-medium">No activity recorded yet.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            </div>
          </>
        ) : activeTab === 'Investors' && !selectedInvestor ? (
          <div className="space-y-6">
            {showOnlyWithUnusedCapital && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-indigo-50 border border-indigo-100 rounded-2xl p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
                    <Coins size={20} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-gray-900">Uninvested Capital Filter Active</h4>
                    <p className="text-xs text-gray-500 mt-0.5">Showing partners who have positive remaining unused capital reserves.</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowOnlyWithUnusedCapital(false)} 
                  className="px-4 py-2 bg-white hover:bg-gray-50 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold font-sans transition shadow-sm shrink-0 uppercase tracking-wider cursor-pointer"
                >
                  Show All Partners
                </button>
              </motion.div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             {/* Add New Investor Card */}
            <motion.div 
              whileHover={{ scale: 1.02 }}
              onClick={() => setIsModalOpen(true)}
              className="bg-white border-2 border-dashed border-gray-200 rounded-2xl p-8 flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-corporate-navy hover:bg-gray-50 transition-all border-spacing-4"
            >
              <div className="p-4 bg-gray-100 rounded-full text-gray-400 group-hover:text-corporate-navy">
                <Users size={32} />
              </div>
              <div className="text-center">
                <h4 className="font-bold text-gray-900">Add New Partner</h4>
                <p className="text-sm text-gray-500 mt-1">Scale your capital outreach</p>
              </div>
              <button className="px-6 py-2 bg-corporate-navy text-white rounded-xl text-xs font-bold shadow-lg shadow-corporate-navy/10">
                Register New
              </button>
            </motion.div>

            {filteredInvestors.map((investor) => (
              <motion.div 
                key={investor.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ y: -5 }}
                className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm group"
              >
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-corporate-navy/5 rounded-xl flex items-center justify-center text-corporate-navy font-bold text-lg">
                      {investor.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 group-hover:text-corporate-navy transition-colors">{investor.name}</h4>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{investor.equity} Equity Share</p>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-0.5" style={{ color: '#4f46e5' }}>Joined: {formatFullJoinedDate(investor.createdAt || investor.date)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={investor.status} />
                    {userRole === 'Accountant' && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteInvestor(investor.id, investor.name);
                        }}
                        className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>

                {(() => {
                  const investorInvestments = allInvestments.filter(inv => inv.investorId === investor.id);
                  const totalAllocated = investorInvestments.reduce((sum, inv) => sum + (inv.amount || 0), 0);
                  const unusedCapital = Math.max((investor.totalCapital || 0) - totalAllocated, 0);

                  return (
                    <div className="grid grid-cols-3 gap-2 mb-6">
                      <div className="p-2.5 bg-gray-50 rounded-xl">
                        <p className="text-[9px] text-gray-400 font-bold uppercase truncate">Total Cap</p>
                        <p className="text-xs font-bold text-gray-900 truncate">৳{investor.totalCapital.toLocaleString()}</p>
                      </div>
                      <div className="p-2.5 bg-gray-50 rounded-xl">
                        <p className="text-[9px] text-gray-400 font-bold uppercase truncate">Unused Cash</p>
                        <p className="text-xs font-bold text-indigo-600 truncate">৳{unusedCapital.toLocaleString()}</p>
                      </div>
                      <div className="p-2.5 bg-gray-50 rounded-xl">
                        <p className="text-[9px] text-gray-400 font-bold uppercase truncate">Ventures</p>
                        <p className="text-xs font-bold text-gray-900 truncate">{investor.projects} Proj</p>
                      </div>
                    </div>
                  );
                })()}

                <div className="flex items-center justify-between pt-4 border-t border-gray-50 text-[10px] text-gray-400 font-bold">
                  <span>Last Active: {investor.lastActivity}</span>
                  <button 
                    onClick={() => setSelectedInvestor(investor)}
                    className="flex items-center gap-1 text-corporate-navy hover:underline"
                  >
                    Manage Profile <ChevronRight size={10} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
          </div>
        ) : activeTab === 'Investors' && activeInvestor ? (
          <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden animate-in fade-in duration-300">
            {/* Investor Header */}
            <div className="p-8 bg-gradient-to-r from-corporate-navy to-corporate-blue text-white">
              <button 
                onClick={() => setSelectedInvestor(null)}
                className="flex items-center gap-2 text-xs font-bold text-white/70 hover:text-white mb-6 uppercase tracking-widest"
              >
                <ArrowUpRight size={14} className="rotate-[225deg]" /> Back to Partners
              </button>
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center text-3xl font-bold backdrop-blur-md">
                    {activeInvestor.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-3xl font-bold">{activeInvestor.name}</h3>
                      <StatusBadge status={activeInvestor.status} />
                    </div>
                    <p className="text-white/70 text-sm">
                      Joined: {formatFullJoinedDate(activeInvestor.createdAt || activeInvestor.date)} &bull; Status Action: {activeInvestor.lastActivity}
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  {userRole === 'Accountant' && (
                    <button 
                      onClick={() => handleDeleteInvestor(activeInvestor.id, activeInvestor.name)}
                      className="p-3 bg-red-500/20 text-white hover:bg-red-500 rounded-2xl transition-all"
                      title="Delete Partner"
                    >
                      <Trash2 size={20} />
                    </button>
                  )}
                  <button 
                    onClick={handleDownloadInvestorPDF}
                    className="px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold text-sm shadow-xl shadow-emerald-500/10 hover:bg-emerald-700 transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center gap-2"
                  >
                    <Download size={16} /> Summary Report
                  </button>
                  {userRole === 'Accountant' && (
                    <>
                      <button 
                        onClick={() => setIsTopUpModalOpen(true)}
                        className="px-6 py-3 bg-white/10 border border-white/20 text-white rounded-2xl font-bold text-sm hover:bg-white/15 transition-all hover:scale-[1.01] active:scale-[0.99]"
                      >
                        + Top Up Capital
                      </button>
                      <button 
                        onClick={() => setIsInvestmentModalOpen(true)}
                        className="px-6 py-3 bg-white text-corporate-navy rounded-2xl font-bold text-sm shadow-xl shadow-black/10 hover:bg-gray-100 transition-all hover:scale-[1.01] active:scale-[0.99]"
                      >
                        + New Asset Allocation
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-5 border-b border-gray-100">
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Total Capital Injected</p>
                <p className="text-2xl font-bold text-gray-900">৳{activeInvestor.totalCapital.toLocaleString()}</p>
              </div>
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Est. Net Worth</p>
                <p className="text-2xl font-bold text-emerald-600">৳{selectedInvestorStats?.netWorth.toLocaleString()}</p>
                <p className="text-[10px] text-emerald-500 font-bold mt-1">Share: +৳{selectedInvestorStats?.estimatedProfitShare.toLocaleString()}</p>
              </div>
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Equity stake</p>
                <p className="text-2xl font-bold text-gray-900">{activeInvestor.equity}</p>
              </div>
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Live projects</p>
                <p className="text-2xl font-bold text-gray-900">{activeInvestor.projects}</p>
              </div>
              <div className="p-8">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Uninvested Capital</p>
                <p className="text-2xl font-bold text-indigo-600">৳{activeInvestorUnallocated.toLocaleString()}</p>
              </div>
            </div>

            {/* Investments List */}
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h4 className="font-bold text-gray-900">Capital Deployment History</h4>
                <div className="flex gap-2">
                  <button className="p-2 bg-gray-50 rounded-lg text-gray-400 hover:text-gray-600">
                    <Filter size={16} />
                  </button>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left">
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Asset / Project</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Sector</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capital Injected</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">ROI Status</th>
                      <th className="pb-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {investments.length > 0 ? (
                      investments.map((rec) => (
                        <tr key={rec.id} className="group">
                          <td className="py-4">
                            <div className="flex flex-col">
                              <span className="text-sm font-bold text-gray-900">{rec.projectName}</span>
                              <span className="text-[10px] text-gray-400 font-medium">Ref: #{rec.id.slice(0, 8)}</span>
                            </div>
                          </td>
                          <td className="py-4">
                            <span className="text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-md">{rec.sector}</span>
                          </td>
                          <td className="py-4">
                            <span className="text-sm font-bold text-gray-900">৳{rec.amount.toLocaleString()}</span>
                          </td>
                          <td className="py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                            {formatDateShort(rec.createdAt)}
                          </td>
                          <td className="py-4">
                            <div className="flex items-center gap-1 text-green-500 font-bold text-xs">
                              <TrendingUp size={12} /> +12.4%
                            </div>
                          </td>
                          <td className="py-4 text-right">
                            {userRole === 'Accountant' && (
                              <button 
                                onClick={() => handleDeleteInvestment(rec.id)}
                                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="py-12 text-center text-gray-400 text-sm font-medium">
                          No specific investment records found for this partner.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            
            {/* Project-wise Profit Sharing Section */}
            <div className="p-8 border-t border-gray-100 bg-gray-50/20">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-6 gap-4">
                <div>
                  <h4 className="font-bold text-gray-900 flex items-center gap-2">
                    <TrendingUp className="text-corporate-navy" size={18} />
                    Project-wise Profit Sharing Details
                  </h4>
                  <p className="text-xs text-gray-500 mt-1">Breakdown of this investor's apportioned profits based on their funding share in each active project</p>
                </div>
                <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                  <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm bg-white">
                    <Coins size={14} className="text-emerald-600" />
                    <span>Total Earned: ৳{Math.round(activeInvestorVentureProfitShareSum).toLocaleString()}</span>
                  </div>
                  <button 
                    onClick={() => {
                      setNewProfit(prev => ({
                        ...prev,
                        projectId: '',
                        amount: 0,
                        description: `Profit sharing partition`,
                      }));
                      setIsProfitModalOpen(true);
                    }}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    + Record Profit
                  </button>
                  <button 
                    onClick={() => {
                      setNewExpense(prev => ({
                        ...prev,
                        projectId: '',
                        amount: 0,
                        description: `Loss/Expense partition`,
                        category: 'Operational',
                      }));
                      setIsExpenseModalOpen(true);
                    }}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                  >
                    + Record Loss
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-150 text-left">
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project / Venture</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Direct Investment</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Registered Equity (%)</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project Net Profit</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Apportioned Profit</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-medium">
                    {activeInvestorProfitBreakdown.length > 0 ? (
                      activeInvestorProfitBreakdown.map((item) => {
                        const isProfitable = item.profitShare >= 0;
                        return (
                          <tr key={item.projectId} className="hover:bg-gray-50/30 transition-colors">
                            <td className="py-4">
                              <div className="flex flex-col">
                                <span className="text-sm font-bold text-gray-900">{item.projectName}</span>
                                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{item.projectSector}</span>
                              </div>
                            </td>
                            <td className="py-4 text-sm font-semibold text-gray-800">
                              ৳{item.investorContribution.toLocaleString()}
                            </td>
                            <td className="py-4 text-xs font-semibold">
                              <div className="flex items-center gap-1.5">
                                <span>{item.equityPercent.toFixed(1)}%</span>
                                <div className="w-12 bg-gray-100 h-1.5 rounded-full overflow-hidden">
                                  <div className="bg-corporate-navy h-full rounded-full" style={{ width: `${item.equityPercent}%` }}></div>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 text-sm font-medium text-gray-600">
                              ৳{Math.round(item.projectNetProfit).toLocaleString()}
                            </td>
                            <td className={`py-4 text-sm font-bold text-right ${isProfitable ? 'text-emerald-600' : 'text-red-500'}`}>
                              {isProfitable ? '+' : ''}৳{Math.round(item.profitShare).toLocaleString()}
                            </td>
                            <td className="py-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button 
                                  onClick={() => {
                                    setNewProfit(prev => ({
                                      ...prev,
                                      projectId: item.projectId,
                                      amount: 0,
                                      description: `Profit for ${item.projectName}`,
                                    }));
                                    setIsProfitModalOpen(true);
                                  }}
                                  className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                                  title="Add Profit for this project"
                                >
                                  + Profit
                                </button>
                                <button 
                                  onClick={() => {
                                    setNewExpense(prev => ({
                                      ...prev,
                                      projectId: item.projectId,
                                      amount: 0,
                                      description: `Loss/Expense for ${item.projectName}`,
                                      category: 'Operational',
                                    }));
                                    setIsExpenseModalOpen(true);
                                  }}
                                  className="text-[10px] font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                                  title="Add Loss/Expense for this project"
                                >
                                  + Loss
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-gray-400 text-sm font-medium">
                          No active project allocations found. Allocate capital to projects to calculate profit sharing.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Real-time Profit & Loss Ledger for Investor's Allocated Ventures */}
            <div className="p-8 border-t border-gray-100 bg-emerald-50/5">
              <div className="mb-6">
                <h4 className="font-bold text-gray-900 flex items-center gap-2">
                  <History className="text-corporate-navy" size={18} />
                  Allocated Project Financial Entries
                </h4>
                <p className="text-xs text-gray-500 mt-1 font-semibold">Review and delete recorded financial entries influencing this investor's apportioned yield</p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left font-medium">
                  <thead>
                    <tr className="border-b border-gray-150 text-left">
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Type</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project/Venture</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Description</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Amount</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Delete Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 text-sm font-semibold">
                    {(() => {
                      // Find projects where active investor has allocations
                      const allocatedProjectIds = activeInvestorProfitBreakdown.map(b => b.projectId);

                      const list: {
                        id: string;
                        type: 'Profit' | 'Loss';
                        projectName: string;
                        description: string;
                        amount: number;
                        createdAt: any;
                        date: string;
                      }[] = [];

                      profits.forEach(p => {
                        if (allocatedProjectIds.includes(p.projectId)) {
                          list.push({
                            id: p.id,
                            type: 'Profit',
                            projectName: p.projectName || '—',
                            description: p.description || 'Profit Inflow',
                            amount: p.amount,
                            createdAt: p.createdAt,
                            date: p.date
                          });
                        }
                      });

                      expenses.forEach(e => {
                        if (allocatedProjectIds.includes(e.projectId)) {
                          list.push({
                            id: e.id,
                            type: 'Loss',
                            projectName: e.projectName || '—',
                            description: e.description || 'Loss Event',
                            amount: e.amount,
                            createdAt: e.createdAt,
                            date: e.date
                          });
                        }
                      });

                      // Sort by newest first
                      list.sort((a, b) => {
                        const getMs = (item: any) => {
                          if (!item) return 0;
                          const rawDate = item.createdAt;
                          if (!rawDate) return new Date(item.date).getTime() || 0;
                          const d = rawDate.toDate ? rawDate.toDate() : new Date(rawDate);
                          return isNaN(d.getTime()) ? 0 : d.getTime();
                        };
                        return getMs(b) - getMs(a);
                      });

                      if (list.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-gray-400 text-xs font-semibold">
                              No financial entries found for this investor's active ventures. Add profits/losses to recalculate distributions.
                            </td>
                          </tr>
                        );
                      }

                      return list.map((item) => {
                        const isProfit = item.type === 'Profit';
                        return (
                          <tr key={item.id} className="hover:bg-gray-50/30 transition-colors">
                            <td className="py-4">
                              <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md ${isProfit ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'} uppercase tracking-widest`}>
                                {item.type}
                              </span>
                            </td>
                            <td className="py-4">
                              <span className="font-bold text-gray-950">{item.projectName}</span>
                            </td>
                            <td className="py-4 text-xs text-gray-500 font-medium">
                              {item.description}
                            </td>
                            <td className={`py-4 font-bold ${isProfit ? 'text-emerald-600' : 'text-red-500'}`}>
                              {isProfit ? '+' : '-'}৳{item.amount.toLocaleString()}
                            </td>
                            <td className="py-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                              {formatDateShort(item.createdAt || item.date)}
                            </td>
                            <td className="py-4 text-right">
                              {userRole === 'Accountant' && (
                                <button 
                                  onClick={() => {
                                    if (isProfit) {
                                      handleDeleteProfit(item.id);
                                    } else {
                                      handleDeleteExpense(item.id);
                                    }
                                  }}
                                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all cursor-pointer inline-flex items-center justify-center bg-gray-50"
                                  title={`Delete ${item.type}`}
                                >
                                  <Trash2 size={14} />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Top Up History List */}
            <div className="p-8 border-t border-gray-100 bg-gray-50/20">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h4 className="font-bold text-gray-900">Capital Injection History (Top-up History)</h4>
                  <p className="text-xs text-gray-400 font-medium mt-1">Direct partner capital contributions and onboarding investments</p>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left">
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Description</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Injected Amount</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                      <th className="pb-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {topUps.length > 0 ? (
                      topUps.map((rec) => (
                        <tr key={rec.id} className="group">
                          <td className="py-4">
                            <div className="flex flex-col">
                              <span className="text-sm font-bold text-gray-900">{rec.description || 'Capital Top Up'}</span>
                              <span className="text-[10px] text-gray-400 font-medium">Ref: #{rec.id.slice(0, 8)}</span>
                            </div>
                          </td>
                          <td className="py-4 text-sm font-bold text-emerald-600">
                            ৳{rec.amount.toLocaleString()}
                          </td>
                          <td className="py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                            {formatDateShort(rec.createdAt || rec.date)}
                          </td>
                          <td className="py-4 text-right">
                            {userRole === 'Accountant' && (
                              <button 
                                onClick={() => handleDeleteTopUp(rec.id, rec.amount)}
                                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                title="Delete Top Up Record"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="py-12 text-center text-gray-400 text-sm font-medium">
                          No capital injection records found for this partner.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : activeTab === 'Projects' && !selectedProject ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Create Project Card */}
            {userRole === 'Accountant' && (
              <motion.div 
                whileHover={{ scale: 1.02 }}
                onClick={() => setIsProjectModalOpen(true)}
                className="bg-white border-2 border-dashed border-gray-200 rounded-2xl p-8 flex flex-col items-center justify-center gap-4 cursor-pointer hover:border-corporate-navy hover:bg-gray-50 transition-all border-spacing-4"
              >
                <div className="p-4 bg-gray-100 rounded-full text-gray-400 group-hover:text-corporate-navy">
                  <BarChart3 size={32} />
                </div>
                <div className="text-center">
                  <h4 className="font-bold text-gray-900">Create New Project</h4>
                  <p className="text-sm text-gray-500 mt-1">Launch a new capital venture</p>
                </div>
                <button className="px-6 py-2 bg-corporate-navy text-white rounded-xl text-xs font-bold shadow-lg shadow-corporate-navy/10">
                  Setup Venture
                </button>
              </motion.div>
            )}

            {projectsWithStats.map((project) => {
              return (
                <motion.div 
                  key={project.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm relative group overflow-hidden"
                >
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h4 className="font-bold text-gray-900">{project.name}</h4>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center flex-wrap gap-1 mt-0.5">
                        {project.sector}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <StatusBadge status={project.status} />
                      {userRole === 'Accountant' && (
                        <>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              openEditProject(project);
                            }}
                            className="p-1.5 text-gray-400 hover:text-corporate-navy hover:bg-gray-50 rounded-lg transition-all"
                          >
                            <Pencil size={14} />
                          </button>
                          <button 
                            onClick={(e) => handleDeleteProject(e, project)}
                            className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between items-end">
                      <p className="text-[10px] text-gray-400 font-bold uppercase">Funding Raised</p>
                      <p className="text-lg font-bold text-gray-900">৳{project.totalFunding.toLocaleString()}</p>
                    </div>
                    <div className="w-full h-2 bg-gray-50 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-corporate-navy" 
                        style={{ width: `${Math.min((project.totalFunding / 5000000) * 100, 100)}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400">
                        <Users size={12} /> {project.investorCount} Partners
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                        Launch: {formatDateShort(project.createdAt)}
                      </div>
                    </div>
                    <button 
                      onClick={() => setSelectedProject(project)}
                      className="text-xs font-bold text-corporate-navy hover:underline flex items-center gap-1"
                    >
                      Details <ChevronRight size={12} />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        ) : activeTab === 'Projects' && selectedProjectWithStats ? (
          <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden animate-in fade-in duration-300">
            {/* Project Header */}
            <div className="p-8 bg-gradient-to-r from-corporate-navy to-corporate-blue text-white">
              <button 
                onClick={() => setSelectedProject(null)}
                className="flex items-center gap-2 text-xs font-bold text-white/70 hover:text-white mb-6 uppercase tracking-widest"
              >
                <ArrowUpRight size={14} className="rotate-[225deg]" /> Back to Projects
              </button>
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center text-3xl backdrop-blur-md">
                    <BarChart3 size={40} />
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-3xl font-bold">{selectedProjectWithStats.name}</h3>
                      <StatusBadge status={selectedProjectWithStats.status} />
                    </div>
                    <p className="text-white/70 text-sm flex items-center flex-wrap gap-1.5">
                      {selectedProjectWithStats.sector} Sector • Launched {formatDateShort(selectedProjectWithStats.createdAt)}
                    </p>
                  </div>
                </div>
                {userRole === 'Accountant' && (
                  <div className="flex gap-4 items-center">
                    <button 
                      onClick={(e) => handleDeleteProject(e, selectedProjectWithStats)}
                      className="p-3 bg-red-500/20 text-white hover:bg-red-500 rounded-2xl transition-all font-bold cursor-pointer"
                      title="Delete Project/Venture"
                    >
                      <Trash2 size={20} />
                    </button>
                    <button 
                      onClick={() => openEditProject(selectedProjectWithStats)}
                      className="px-6 py-3 bg-white text-corporate-navy rounded-2xl font-bold text-sm shadow-xl shadow-black/10 hover:bg-gray-100 transition-all cursor-pointer"
                    >
                      Edit Venture Info
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-5 border-b border-gray-100">
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Total Funding</p>
                <p className="text-2xl font-bold text-gray-900">৳{selectedProjectWithStats.totalFunding.toLocaleString()}</p>
              </div>
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Total Cost</p>
                <p className="text-2xl font-bold text-red-600">৳{selectedProjectWithStats.totalCost?.toLocaleString() || 0}</p>
              </div>
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Partner Count</p>
                <p className="text-2xl font-bold text-gray-900">{selectedProjectWithStats.investorCount}</p>
              </div>
              <div className="p-8 border-r border-gray-100">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Status</p>
                <div className="mt-1">
                  <StatusBadge status={selectedProjectWithStats.status} />
                </div>
              </div>
              <div className="p-8">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-2">Funding Health</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-corporate-navy" 
                      style={{ width: `${Math.min((selectedProjectWithStats.totalFunding / 5000000) * 100, 100)}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-bold text-corporate-navy">{Math.round(Math.min((selectedProjectWithStats.totalFunding / 5000000) * 100, 100))}%</span>
                </div>
              </div>
            </div>

            {/* Project Partners List */}
            <div className="p-8 border-b border-gray-100">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h4 className="font-bold text-gray-900">Project Partners</h4>
                  <p className="text-xs text-gray-500">Breakdown of capital contributors for this venture</p>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left">
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Investor Name</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Contribution Count</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Total Capital Provided</th>
                      <th className="pb-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Share of Funding</th>
                      <th className="pb-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {projectInvestors.length > 0 ? (
                      projectInvestors.map((investor) => {
                        const isInvestorOut = !investors.some(i => i.id === investor.investorId);
                        return (
                          <tr key={investor.investorId} className="group">
                            <td className="py-4">
                              <div className="flex flex-col">
                                <span className="text-sm font-bold text-gray-900 flex items-center gap-2">
                                  {investor.investorName}
                                  {isInvestorOut && (
                                    <span className="text-red-500 font-bold text-[9px] uppercase tracking-wider bg-red-50 border border-red-200 px-1.5 py-0.5 rounded animate-pulse">
                                      ( This Investor was out )
                                    </span>
                                  )}
                                </span>
                                <span className="text-[10px] text-gray-400 font-medium">Partner ID: {investor.investorId.slice(0, 8)}</span>
                              </div>
                            </td>
                            <td className="py-4">
                              <span className="text-sm font-medium text-gray-600">{investor.count} deployments</span>
                            </td>
                            <td className="py-4">
                              <span className="text-sm font-bold text-gray-900">৳{investor.amount.toLocaleString()}</span>
                            </td>
                            <td className="py-4">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-gray-900">
                                  {((investor.amount / (selectedProjectWithStats.totalFunding || 1)) * 100).toFixed(1)}%
                                </span>
                                <div className="w-24 h-1.5 bg-gray-50 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-emerald-500" 
                                    style={{ width: `${(investor.amount / (selectedProjectWithStats.totalFunding || 1)) * 100}%` }}
                                  ></div>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 text-right">
                              <div className="flex items-center justify-end gap-3">
                                {!isInvestorOut && (
                                  <button 
                                     onClick={() => {
                                       const fullInvestor = investors.find(i => i.id === investor.investorId);
                                       if (fullInvestor) {
                                         setSelectedInvestor(fullInvestor);
                                         setActiveTab('Investors');
                                         setSelectedProject(null);
                                       }
                                     }}
                                     className="text-xs font-bold text-corporate-navy hover:underline cursor-pointer"
                                  >
                                    View Profile
                                  </button>
                                )}
                                {userRole === 'Accountant' && (
                                  <button 
                                     onClick={() => {
                                       setPartnerToRemove({
                                         investorId: investor.investorId,
                                         investorName: investor.investorName,
                                         projectId: selectedProjectWithStats.id
                                       });
                                     }}
                                     className="px-2.5 py-1.5 bg-red-50 text-red-600 hover:text-white hover:bg-red-600 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer border border-red-100"
                                     title={isInvestorOut ? "Remove this out-investor's allocation" : "Remove partner allocations from project"}
                                  >
                                    <Trash2 size={12} />
                                    <span className="text-[10px] font-bold">Remove</span>
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-gray-400 text-sm font-medium">
                          No partners found for this project.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Project Financial Summary */}
            <div className="p-8 border-t border-gray-100 bg-gray-50/20">
              <div className="mb-6">
                <h4 className="font-bold text-gray-900 leading-none">Financial summary</h4>
                <p className="text-xs text-gray-400 mt-1.5">Overview of operational costs and profit earnings associated with this initiative</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Cost Card */}
                <motion.div
                  whileHover={{ y: -4, scale: 1.01 }}
                  onClick={() => {
                    setProjectFilter(selectedProjectWithStats.id);
                    setActiveTab('Expenses');
                  }}
                  className="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center text-red-600 transition-colors group-hover:bg-red-500 group-hover:text-white">
                      <FileText size={24} />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project Total Cost</span>
                      <h5 className="text-2xl font-bold text-red-600 mt-1">৳{(selectedProjectWithStats.totalCost || 0).toLocaleString()}</h5>
                      <p className="text-xs text-gray-400 mt-1 group-hover:text-corporate-navy transition-colors">Click to view itemized expenses ledger →</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-corporate-navy transition-colors" />
                </motion.div>

                {/* Profit Card */}
                <motion.div
                  whileHover={{ y: -4, scale: 1.01 }}
                  onClick={() => {
                    setProjectFilter(selectedProjectWithStats.id);
                    setActiveTab('Expenses');
                  }}
                  className="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 transition-colors group-hover:bg-emerald-500 group-hover:text-white">
                      <TrendingUp size={24} />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project Total Profit</span>
                      <h5 className="text-2xl font-bold text-emerald-600 mt-1">৳{(selectedProjectWithStats.totalProfit || 0).toLocaleString()}</h5>
                      <p className="text-xs text-gray-400 mt-1 group-hover:text-corporate-navy transition-colors">Click to view itemized profits ledger →</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-corporate-navy transition-colors" />
                </motion.div>
              </div>
            </div>
          </div>
        ) : activeTab === 'BuySales' ? (
          <BuySalesView 
            buySales={buySales}
            projects={projects}
            projectFilter={projectFilter}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            onDeleteBuySale={handleDeleteBuySale}
            onEditBuySale={handleStartEditBuySale}
            isAccountant={userRole === 'Accountant'}
            onQuickEditInitial={(productName) => {
              const initialRecord = buySales.find(r => r.itemName === productName && r.type === 'Initial');
              if (initialRecord) {
                handleStartEditBuySale(initialRecord);
              } else {
                setEditingBuySale(null);
                setNewBuySale({
                  itemName: productName,
                  type: 'Initial',
                  quantity: 1,
                  unitPrice: 0,
                  projectId: '',
                  partnerName: '',
                  date: new Date().toISOString().split('T')[0]
                });
                setIsBuySaleModalOpen(true);
              }
            }}
            formatDate={formatFullJoinedDate}
          />
        ) : activeTab === 'Expenses' ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <MetricCard 
                title="Total Expenses" 
                value={`৳${stats.totalExpenses.toLocaleString()}`} 
                badge={projectFilter === 'all' ? 'LTD' : 'Project'} 
                badgeColor="bg-red-100 text-red-700" 
                icon={FileText} 
              />
              <MetricCard 
                title="Total Profits" 
                value={`৳${stats.totalProfits.toLocaleString()}`} 
                badge={projectFilter === 'all' ? 'LTD' : 'Project'} 
                badgeColor="bg-emerald-100 text-emerald-700" 
                icon={TrendingUp} 
              />
              <MetricCard 
                title="Net Financial Margin" 
                value={`${(stats.totalProfits - stats.totalExpenses) >= 0 ? '+' : ''}৳${(stats.totalProfits - stats.totalExpenses).toLocaleString()}`} 
                badge="Net Return" 
                badgeColor={(stats.totalProfits - stats.totalExpenses) >= 0 ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"} 
                icon={Coins} 
              />
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-2">
                  <FileText className="text-red-500" size={18} />
                  <h4 className="text-sm font-bold text-gray-950">Expense Ledger</h4>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={handleDownloadExpensesCSV}
                    className="px-3 py-1.5 bg-white border border-gray-200 text-gray-600 rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-gray-50 transition-all"
                  >
                    Export CSV <Download size={12} className="inline ml-1" />
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-50">
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Description</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Category</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Amount</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredExpenses.map((expense) => (
                      <tr key={expense.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <span className="text-sm font-bold text-gray-900">{expense.description}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-red-50 text-red-600 uppercase tracking-widest">
                            {expense.category}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs font-semibold text-corporate-navy">{expense.projectName || '—'}</span>
                        </td>
                        <td className="px-6 py-4 text-sm font-bold text-red-600">-৳{expense.amount.toLocaleString()}</td>
                        <td className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                          {formatDateShort(expense.createdAt)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          {userRole === 'Accountant' && (
                            <button 
                              onClick={() => handleDeleteExpense(expense.id)}
                              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                              title="Delete Expense"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredExpenses.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-12 text-center text-gray-400 text-sm font-medium">
                          No expenses found matching the selected project/filter.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Profit Ledger */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-2">
                  <TrendingUp className="text-emerald-600" size={18} />
                  <h4 className="text-sm font-bold text-gray-900">Profit Ledger</h4>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={handleDownloadProfitsCSV}
                    className="px-3 py-1.5 bg-white border border-gray-200 text-gray-600 rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-gray-50 transition-all mr-1"
                  >
                    Export CSV <Download size={12} className="inline ml-1" />
                  </button>
                  {userRole === 'Accountant' && (
                    <button onClick={() => setIsProfitModalOpen(true)} className="px-3 py-1.5 bg-emerald-600 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-emerald-700 transition-all">
                      Record Profit
                    </button>
                  )}
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-50">
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Description</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Amount</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {filteredProfits.map((profit) => (
                      <tr key={profit.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <span className="text-sm font-bold text-gray-900">{profit.projectName}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-gray-500">{profit.description}</span>
                        </td>
                        <td className="px-6 py-4 text-sm font-bold text-emerald-600">+৳{profit.amount.toLocaleString()}</td>
                        <td className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                          {formatDateShort(profit.createdAt)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          {userRole === 'Accountant' && (
                            <button 
                              onClick={() => handleDeleteProfit(profit.id)}
                              className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                              title="Delete Profit"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredProfits.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-6 py-12 text-center text-gray-400 text-sm font-medium">
                          No profit records found matching the selected project/filter.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </div>
        ) : activeTab === 'Profit Analytics' ? (
          <div className="space-y-6">
            {/* Monthly Profitability Report Controls & Metric Overview */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-white rounded-3xl border border-gray-100 shadow-sm">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Report Period:</span>
                <select 
                  value={reportMonthFilter}
                  onChange={(e) => setReportMonthFilter(e.target.value)}
                  className="bg-gray-50 border border-gray-200 text-gray-700 py-2 px-4 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-corporate-navy/20"
                >
                  <option value="all">All Months (Cumulative)</option>
                  <option value="2026-04">April 2026</option>
                  <option value="2026-05">May 2026</option>
                  <option value="2026-06">June 2026</option>
                  <option value="2026-07">July 2026</option>
                  <option value="2026-08">August 2026</option>
                  <option value="2026-09">September 2026</option>
                  <option value="2026-10">October 2026</option>
                  <option value="2026-11">November 2026</option>
                </select>
              </div>
              <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
                <button 
                  onClick={handleDownloadProfitabilityCSV}
                  className="px-4 py-2 bg-white border border-gray-200 text-gray-700 hover:text-corporate-navy rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-gray-50 transition-all shadow-sm flex items-center gap-2 shrink-0 cursor-pointer"
                >
                  Export Report <Download size={14} />
                </button>
                <button 
                  onClick={() => {
                    setNewProfit(prev => ({
                      ...prev,
                      projectId: '',
                      amount: 0,
                      description: 'Direct Profit Inflow',
                    }));
                    setIsProfitModalOpen(true);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all shadow-sm flex items-center gap-2 shrink-0 cursor-pointer"
                >
                  + Add Profit
                </button>
                <button 
                  onClick={() => {
                    setNewExpense(prev => ({
                      ...prev,
                      projectId: '',
                      amount: 0,
                      description: 'Operational Loss/Cost',
                      category: 'Operational',
                    }));
                    setIsExpenseModalOpen(true);
                  }}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all shadow-sm flex items-center gap-2 shrink-0 cursor-pointer"
                >
                  + Add Loss
                </button>
              </div>
            </div>

            {/* Metrics Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Inflow (Funding)</span>
                <h5 className="text-xl font-extrabold text-corporate-navy mt-1">৳{reportTotals.totalInflow.toLocaleString()}</h5>
                <p className="text-[9px] text-gray-400 mt-1 uppercase font-semibold">Active Capital</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Revenues (Earned)</span>
                <h5 className="text-xl font-extrabold text-emerald-600 mt-1">৳{reportTotals.totalRevenue.toLocaleString()}</h5>
                <p className="text-[9px] text-gray-400 mt-1 uppercase font-semibold">Profit Inflow</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Operational Expenses</span>
                <h5 className="text-xl font-extrabold text-red-500 mt-1">৳{reportTotals.totalExpenses.toLocaleString()}</h5>
                <p className="text-[9px] text-gray-400 mt-1 uppercase font-semibold">Cost Outflow</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Net Cash Margin</span>
                <h5 className={`text-xl font-extrabold mt-1 ${reportTotals.netProfit >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                  {reportTotals.netProfit >= 0 ? '+' : ''}৳{reportTotals.netProfit.toLocaleString()}
                </h5>
                <p className="text-[9px] text-gray-400 mt-1 uppercase font-semibold">Revenue - Cost</p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Net Rate of Return</span>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className={`text-xl font-extrabold ${reportTotals.averageROI >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                    {reportTotals.averageROI.toFixed(1)}%
                  </span>
                  {reportTotals.averageROI >= 0 ? (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-green-50 text-green-600 uppercase">ROI</span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-red-50 text-red-600 uppercase">ROI</span>
                  )}
                </div>
                <p className="text-[9px] text-gray-400 mt-1 uppercase font-semibold">Aggregate Yield</p>
              </div>
            </div>

            {/* Net Cash Margin Trend Line Chart */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h4 className="text-sm font-bold text-gray-950 flex items-center gap-2">
                    <TrendingUp className="text-corporate-navy" size={18} />
                    Net Cash Margin Volatility (6-Month Trend)
                  </h4>
                  <p className="text-xs text-gray-500 mt-1">Revenues vs. Expenses net difference to track profit flow volatility</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1.5 text-xs text-emerald-600 font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Positive Margin
                  </span>
                  <span className="flex items-center gap-1.5 text-xs text-red-500 font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span> Negative Margin
                  </span>
                </div>
              </div>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsLineChart data={last6MonthsData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorMargin" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0B2545" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#0B2545" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <RechartsCartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                    <RechartsXAxis 
                      dataKey="month" 
                      stroke="#9ca3af" 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false} 
                      dy={10} 
                    />
                    <RechartsYAxis 
                      stroke="#9ca3af" 
                      fontSize={11} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(val) => `৳${(val / 1000).toFixed(0)}k`} 
                      dx={-10}
                    />
                    <RechartsTooltip 
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          const isProfit = data.Margin >= 0;
                          return (
                            <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-150 text-xs">
                              <p className="font-bold text-gray-900 mb-2">{data.month}</p>
                              <div className="space-y-1 font-semibold">
                                <div className="flex justify-between gap-6 text-gray-500">
                                  <span>Total Revenues:</span>
                                  <span className="text-emerald-600">৳{data.Revenues.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between gap-6 text-gray-500">
                                  <span>Total Expenses:</span>
                                  <span className="text-red-500">৳{data.Expenses.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between gap-6 border-t border-gray-100 pt-1.5 font-bold">
                                  <span>Net Cash Margin:</span>
                                  <span className={isProfit ? 'text-emerald-600' : 'text-red-500'}>
                                    {isProfit ? '+' : ''}৳{data.Margin.toLocaleString()}
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <RechartsLine 
                      type="monotone" 
                      dataKey="Margin" 
                      stroke="#0B2545" 
                      strokeWidth={3} 
                      dot={{ r: 4, strokeWidth: 2, fill: "#fff" }} 
                      activeDot={{ r: 6 }} 
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Monthly Profitability Report Table */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <div className="flex items-center gap-2">
                  <TrendingUp className="text-corporate-navy" size={18} />
                  <h4 className="text-sm font-bold text-gray-950">Monthly Profitability Report</h4>
                </div>
                <span className="text-[10px] font-bold px-2.5 py-1 bg-gray-100 text-gray-600 rounded-lg uppercase tracking-wider">
                  {reportMonthFilter === 'all' ? 'All Time' : `${reportMonthFilter.split('-')[1]}/${reportMonthFilter.split('-')[0]}`}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-50 bg-gray-50/20 font-bold">
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project & Sector</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capital Inbound (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Revenues (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Expenses (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Net Profit (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Return Rate (ROI)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Performance Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-medium">
                    {filteredReportData.map((project) => {
                      const isPositive = project.periodNetProfit >= 0;
                      return (
                        <tr key={project.id} className="hover:bg-gray-50/40 transition-colors">
                          <td className="px-6 py-4">
                            <div>
                              <span className="text-sm font-bold text-gray-900 block">{project.name}</span>
                              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{project.sector}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div>
                              <span className="text-sm font-semibold text-gray-900">৳{project.periodFunding.toLocaleString()}</span>
                              {reportMonthFilter !== 'all' && (
                                <span className="text-[9px] text-gray-400 block font-medium">LTD: ৳{project.overallFunding.toLocaleString()}</span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm font-bold text-emerald-600">
                            +৳{project.periodRevenue.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 text-sm font-bold text-red-500">
                            -৳{project.periodExpenses.toLocaleString()}
                          </td>
                          <td className={`px-6 py-4 text-sm font-extrabold ${isPositive ? 'text-emerald-600' : 'text-red-500'}`}>
                            {isPositive ? '+' : ''}৳{project.periodNetProfit.toLocaleString()}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <span className={`text-sm font-bold ${project.netROI >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                                {project.netROI.toFixed(1)}%
                              </span>
                              <div className="w-16 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                                <div 
                                  className={`h-full rounded-full transition-all ${project.netROI >= 0 ? 'bg-emerald-500' : 'bg-red-500'}`}
                                  style={{ width: `${Math.min(Math.max(project.netROI, 0), 100)}%` }}
                                ></div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            {project.periodRevenue === 0 && project.periodExpenses === 0 ? (
                              <span className="text-[10px] font-bold px-2 py-1 rounded bg-gray-100 text-gray-500 uppercase tracking-widest">
                                Idle Period
                              </span>
                            ) : project.netROI > 15 ? (
                              <span className="text-[10px] font-bold px-2 py-1 rounded bg-emerald-100 text-emerald-700 uppercase tracking-widest">
                                High Return
                              </span>
                            ) : project.netROI > 0 ? (
                              <span className="text-[10px] font-bold px-2 py-1 rounded bg-green-50 text-green-700 uppercase tracking-widest">
                                Profitable
                              </span>
                            ) : project.periodNetProfit === 0 ? (
                              <span className="text-[10px] font-bold px-2 py-1 rounded bg-amber-50 text-amber-600 uppercase tracking-widest">
                                Break Even
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-1 rounded bg-red-100 text-red-700 uppercase tracking-widest">
                                Net Loss
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                    {filteredReportData.length === 0 && (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center text-gray-400 text-sm font-medium">
                          No projects matched the active filters.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Product Performance Trade Profitability Section */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden mt-6"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="text-corporate-navy" size={18} />
                  <h4 className="text-sm font-bold text-gray-950">Merchandise Trade Margin & profitability (Short Form)</h4>
                </div>
                <span className="text-[10px] font-black px-2.5 py-1 bg-corporate-navy/10 text-corporate-navy rounded-lg uppercase tracking-wider">
                  Product Profit Yields
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-50 bg-gray-50/10 font-bold">
                      <th className="px-6 py-3.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Product / Commodity</th>
                      <th className="px-6 py-3.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center">Qty Bought / Cost</th>
                      <th className="px-6 py-3.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center">Qty Sold / Revenue</th>
                      <th className="px-6 py-3.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Cost of Goods Sold (COGS)</th>
                      <th className="px-6 py-3.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Net Yield Profit</th>
                      <th className="px-6 py-3.5 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Margin (%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-sm text-gray-700">
                    {productProfitabilityStats.map((product) => {
                      const isProfitable = product.profit >= 0;
                      return (
                        <tr key={product.name} className="hover:bg-gray-50/30 transition-colors">
                          <td className="px-6 py-4">
                            <span className="font-extrabold text-gray-900 block">{product.name}</span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="inline-block text-xs text-gray-500 bg-gray-50 px-2.5 py-1 rounded-lg">
                              <span className="font-bold text-gray-900 block">{product.totalBought} units</span>
                              <span>৳{product.buyTotalAmount.toLocaleString()}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="inline-block text-xs text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg">
                              <span className="font-bold text-emerald-800 block">{product.totalSold} units</span>
                              <span>৳{product.revenue.toLocaleString()}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 font-bold text-gray-900 whitespace-nowrap">
                            ৳{Math.round(product.cogs).toLocaleString()}
                            <span className="text-[10px] text-gray-400 mt-0.5 block font-medium">Avg buy unit price: ৳{Math.round(product.avgUnitCost).toLocaleString()}</span>
                          </td>
                          <td className={`px-6 py-4 font-extrabold whitespace-nowrap ${isProfitable ? 'text-emerald-600' : 'text-red-500'}`}>
                            {isProfitable ? '+' : ''}৳{Math.round(product.profit).toLocaleString()}
                          </td>
                          <td className="px-6 py-4 text-right whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-black ${
                              product.marginPercentage > 20 ? 'bg-emerald-100 text-emerald-800' :
                              product.marginPercentage > 0 ? 'bg-green-50 text-green-700' :
                              product.marginPercentage === 0 ? 'bg-gray-100 text-gray-600' :
                              'bg-rose-100 text-rose-800'
                            }`}>
                              {product.marginPercentage.toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}

                    {productProfitabilityStats.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-10 text-center text-gray-400 text-xs font-semibold">
                          No product trading records available to calculate product-wise profitability.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Project-by-Project Partner Profit Allocation Analysis */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden mt-6"
            >
              <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gray-50/50">
                <div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="text-corporate-navy" size={18} />
                    <h4 className="text-sm font-bold text-gray-950">Venture-Level Profit Allocation per Partner</h4>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    See how net cash margins are distributed among capital partners relative to their individual funding stakes in each venture
                  </p>
                </div>

                {/* Dropdown Selector */}
                <div className="flex items-center gap-3 self-start md:self-auto">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-widest whitespace-nowrap">Filter Venture:</label>
                  <select 
                    value={analyticsSelectedProjectId}
                    onChange={(e) => setAnalyticsSelectedProjectId(e.target.value)}
                    className="bg-white border border-gray-250 text-gray-700 py-1.5 px-4 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-corporate-navy/20 cursor-pointer"
                  >
                    <option value="all">All Ventures</option>
                    {projects.map(proj => (
                      <option key={proj.id} value={proj.id}>{proj.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-gray-55 bg-gray-50/10 font-bold">
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project Venture</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Partner Info</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Registered Equity</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project Net Profit (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capital Contribution (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Funding Share (%)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Apportioned Profit Share (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-sm text-gray-750">
                    {(() => {
                      const rows: {
                        projectId: string;
                        projectName: string;
                        projectSector: string;
                        netProfit: number;
                        investorId: string;
                        investorName: string;
                        contribution: number;
                        fundingSharePercent: number;
                        profitShare: number;
                      }[] = [];

                      projectPartnerProfitAllocation.forEach(proj => {
                        if (analyticsSelectedProjectId === 'all' || analyticsSelectedProjectId === proj.projectId) {
                          proj.partners.forEach(partner => {
                            rows.push({
                              projectId: proj.projectId,
                              projectName: proj.projectName,
                              projectSector: proj.projectSector,
                              netProfit: proj.netProfit,
                              investorId: partner.investorId,
                              investorName: partner.investorName,
                              contribution: partner.contribution,
                              fundingSharePercent: partner.fundingSharePercent,
                              profitShare: partner.profitShare
                            });
                          });
                        }
                      });

                      if (rows.length === 0) {
                        return (
                          <tr>
                            <td colSpan={8} className="px-6 py-12 text-center text-gray-400 text-xs font-semibold">
                              No partner funding allocations or direct profits recorded for the selected venture filter.
                            </td>
                          </tr>
                        );
                      }

                      return rows.map((row, idx) => {
                        const isProfitable = row.profitShare >= 0;
                        const partnerEquity = investors.find(i => i.id === row.investorId)?.equity || '—';
                        return (
                          <tr key={`${row.projectId}-${row.investorId}-${idx}`} className="hover:bg-gray-50/30 transition-colors">
                            <td className="px-6 py-4">
                              <div>
                                <span className="font-extrabold text-gray-900 block">{row.projectName}</span>
                                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{row.projectSector}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="font-bold text-gray-900">{row.investorName}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="font-semibold text-gray-700 bg-gray-100 px-2.5 py-1 rounded-md text-xs inline-block">
                                {partnerEquity}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`text-sm font-semibold ${row.netProfit >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                                {row.netProfit >= 0 ? '+' : ''}৳{Math.round(row.netProfit).toLocaleString()}
                              </span>
                            </td>
                            <td className="px-6 py-4 font-bold text-gray-900">
                              ৳{row.contribution.toLocaleString()}
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-1.5">
                                <span>{row.fundingSharePercent.toFixed(1)}%</span>
                                <div className="w-12 bg-gray-100 h-1.5 rounded-full overflow-hidden">
                                  <div className="bg-corporate-navy h-full rounded-full" style={{ width: `${row.fundingSharePercent}%` }}></div>
                                </div>
                              </div>
                            </td>
                            <td className={`px-6 py-4 text-right font-extrabold whitespace-nowrap ${isProfitable ? 'text-emerald-600' : 'text-red-500'}`}>
                              {isProfitable ? '+' : ''}৳{Math.round(row.profitShare).toLocaleString()}
                            </td>
                            <td className="px-6 py-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <button 
                                  onClick={() => {
                                    setNewProfit(prev => ({
                                      ...prev,
                                      projectId: row.projectId,
                                      amount: 0,
                                      description: `Profit for ${row.projectName}`,
                                    }));
                                    setIsProfitModalOpen(true);
                                  }}
                                  className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                                  title="Add profit inflow for this project"
                                >
                                  + Profit
                                </button>
                                <button 
                                  onClick={() => {
                                    setNewExpense(prev => ({
                                      ...prev,
                                      projectId: row.projectId,
                                      amount: 0,
                                      description: `Loss/Expense for ${row.projectName}`,
                                      category: 'Operational',
                                    }));
                                    setIsExpenseModalOpen(true);
                                  }}
                                  className="text-[10px] font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                                  title="Add expense/loss for this project"
                                >
                                  + Loss
                                </button>
                                <button 
                                  onClick={() => {
                                    const fullInvestor = investors.find(i => i.id === row.investorId);
                                    if (fullInvestor) {
                                      setSelectedInvestor(fullInvestor);
                                      setActiveTab('Investors');
                                    }
                                  }}
                                  className="text-xs font-black text-corporate-navy hover:underline cursor-pointer bg-corporate-navy/5 hover:bg-corporate-navy/10 px-2.5 py-1.5 rounded-lg transition-colors whitespace-nowrap"
                                >
                                  View Profile
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Venture-Level Recorded Profits & Losses Logs / Ledger */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden mt-6"
            >
              <div className="p-6 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gray-50/50">
                <div>
                  <div className="flex items-center gap-2">
                    <History className="text-corporate-navy" size={18} />
                    <h4 className="text-sm font-bold text-gray-950">Recorded Profits & Losses (Venture Ledger)</h4>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Manage and delete recorded financial entries for the selected active venture
                  </p>
                </div>
                {analyticsSelectedProjectId !== 'all' && (
                  <span className="bg-corporate-navy/5 text-corporate-navy text-xs px-3 py-1 rounded-xl font-bold">
                    Filtered Venture: {projects.find(p => p.id === analyticsSelectedProjectId)?.name || 'Venture'}
                  </span>
                )}
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left font-medium">
                  <thead>
                    <tr className="border-b border-gray-55 bg-gray-50/10 font-bold">
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Type</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Venture</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Description</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Amount (৳)</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Delete Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50 font-semibold text-sm text-gray-750">
                    {(() => {
                      const list: {
                        id: string;
                        type: 'Profit' | 'Loss';
                        projectName: string;
                        description: string;
                        amount: number;
                        createdAt: any;
                        date: string;
                      }[] = [];

                      profits.forEach(p => {
                        if (analyticsSelectedProjectId === 'all' || p.projectId === analyticsSelectedProjectId) {
                          list.push({
                            id: p.id,
                            type: 'Profit',
                            projectName: p.projectName || '—',
                            description: p.description || 'Profit Inflow',
                            amount: p.amount,
                            createdAt: p.createdAt,
                            date: p.date
                          });
                        }
                      });

                      expenses.forEach(e => {
                        if (analyticsSelectedProjectId === 'all' || e.projectId === analyticsSelectedProjectId) {
                          list.push({
                            id: e.id,
                            type: 'Loss',
                            projectName: e.projectName || '—',
                            description: e.description || 'Loss Line',
                            amount: e.amount,
                            createdAt: e.createdAt,
                            date: e.date
                          });
                        }
                      });

                      // Sort by date/createdAt newest first
                      list.sort((a, b) => {
                        const getMs = (item: any) => {
                          if (!item) return 0;
                          const rawDate = item.createdAt;
                          if (!rawDate) return new Date(item.date).getTime() || 0;
                          const d = rawDate.toDate ? rawDate.toDate() : new Date(rawDate);
                          return isNaN(d.getTime()) ? 0 : d.getTime();
                        };
                        return getMs(b) - getMs(a);
                      });

                      if (list.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="px-6 py-12 text-center text-gray-400 text-xs font-semibold">
                              No recent Profit or Loss/Expense records recorded for this venture.
                            </td>
                          </tr>
                        );
                      }

                      return list.map((item) => {
                        const isProfit = item.type === 'Profit';
                        return (
                          <tr key={item.id} className="hover:bg-gray-50/30 transition-colors">
                            <td className="px-6 py-4">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${isProfit ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'} uppercase tracking-widest`}>
                                {item.type}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="font-bold text-gray-950">{item.projectName}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-gray-500 font-medium">{item.description}</span>
                            </td>
                            <td className={`px-6 py-4 font-bold ${isProfit ? 'text-emerald-600' : 'text-red-500'}`}>
                              {isProfit ? '+' : '-'}৳{item.amount.toLocaleString()}
                            </td>
                            <td className="px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                              {formatDateShort(item.createdAt || item.date)}
                            </td>
                            <td className="px-6 py-4 text-right">
                              {userRole === 'Accountant' && (
                                <button 
                                  onClick={() => {
                                    if (isProfit) {
                                      handleDeleteProfit(item.id);
                                    } else {
                                      handleDeleteExpense(item.id);
                                    }
                                  }}
                                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all cursor-pointer inline-flex items-center justify-center bg-gray-50 hover:shadow-xs"
                                  title={`Delete ${item.type}`}
                                >
                                  <Trash2 size={16} />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Partner Profit Share Distribution models */}
            {(() => {
              const totalSystemCapital = investors.reduce((sum, inv) => sum + (inv.totalCapital || 0), 0);
              const baselineProfit = reportTotals.netProfit > 0 ? reportTotals.netProfit : 250000;
              const finalProfitPool = customProfitPool !== '' ? (parseFloat(customProfitPool) || 0) : baselineProfit;

              return (
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden mt-6"
                >
                  <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <Coins className="text-corporate-navy" size={18} />
                        <h4 className="text-sm font-bold text-gray-1000 uppercase tracking-wider">Partner Profit Share Distribution Analysis</h4>
                      </div>
                      <p className="text-xs text-gray-500 mt-1 font-semibold">
                        Compare dividend distributions under: (1) Defined Equity Stake vs. (2) Proportional Capital Contribution
                      </p>
                    </div>
                    
                    {/* Simulator controls */}
                    <div className="flex items-center gap-2 max-w-sm w-full md:w-auto">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-2 text-xs font-bold text-gray-400">৳</span>
                        <input 
                          type="number"
                          placeholder={`Default: ৳${baselineProfit.toLocaleString()}`}
                          value={customProfitPool}
                          onChange={(e) => setCustomProfitPool(e.target.value)}
                          className="w-full pl-7 pr-3 py-1.5 bg-white border border-gray-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-corporate-navy/20 text-gray-950"
                        />
                      </div>
                      {customProfitPool !== '' && (
                        <button 
                          onClick={() => setCustomProfitPool('')}
                          className="px-2.5 py-1.5 bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer"
                        >
                          Reset
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-gray-50 bg-gray-50/20 font-bold">
                          <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Partner Info</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Onboarded Capital</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capital Contribution (Share %)</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-emerald-600">Model 1: By Equity Stake (৳)</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-indigo-600">Model 2: By Capital Share (৳)</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest text-right">Model Variance (৳)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 font-medium text-sm text-gray-800">
                        {investors.map((investor) => {
                          const equityPct = parseFloat(investor.equity) || 0;
                          const model1Share = finalProfitPool * (equityPct / 100);

                          const capitalSharePct = totalSystemCapital > 0 ? (investor.totalCapital / totalSystemCapital) : 0;
                          const model2Share = finalProfitPool * capitalSharePct;

                          const variance = model1Share - model2Share;

                          return (
                            <tr key={investor.id} className="hover:bg-gray-50/40 transition-colors">
                              <td className="px-6 py-4">
                                <div>
                                  <span className="text-sm font-bold text-gray-900 block">{investor.name}</span>
                                  <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider block mt-0.5">
                                    Joined: {formatFullJoinedDate(investor.createdAt || investor.date)}
                                  </span>
                                </div>
                              </td>
                              <td className="px-6 py-4 font-semibold text-gray-900">
                                ৳{investor.totalCapital.toLocaleString()}
                              </td>
                              <td className="px-6 py-4 text-xs font-semibold">
                                <div className="flex items-center gap-1.5">
                                  <span>{(capitalSharePct * 100).toFixed(1)}%</span>
                                  <div className="w-12 bg-gray-100 h-1.5 rounded-full overflow-hidden">
                                    <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${capitalSharePct * 100}%` }}></div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-emerald-600 font-bold">
                                <div className="flex flex-col">
                                  <span>৳{Math.round(model1Share).toLocaleString()}</span>
                                  <span className="text-[9px] text-emerald-500 font-semibold">{equityPct.toFixed(1)}% Stake</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-indigo-600 font-bold">
                                <div className="flex flex-col">
                                  <span>৳{Math.round(model2Share).toLocaleString()}</span>
                                  <span className="text-[9px] text-indigo-400 font-semibold">{(capitalSharePct * 100).toFixed(1)}% Share</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-right">
                                {Math.abs(variance) < 1 ? (
                                  <span className="text-[10px] font-bold px-2 py-1 rounded bg-gray-100 text-gray-500 uppercase tracking-widest whitespace-nowrap">
                                    Equal Yield
                                  </span>
                                ) : variance > 0 ? (
                                  <div className="flex flex-col items-end">
                                    <span className="text-sm font-extrabold text-emerald-600">+৳{Math.round(variance).toLocaleString()}</span>
                                    <span className="text-[9px] font-bold text-emerald-500 uppercase">Favors Equity Stake</span>
                                  </div>
                                ) : (
                                  <div className="flex flex-col items-end">
                                    <span className="text-sm font-extrabold text-indigo-600">-৳{Math.round(Math.abs(variance)).toLocaleString()}</span>
                                    <span className="text-[9px] font-bold text-indigo-400 uppercase">Favors Capital Share</span>
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                        
                        {investors.length === 0 && (
                          <tr>
                            <td colSpan={6} className="px-6 py-12 text-center text-gray-400 text-sm font-medium">
                              No partners available to analyze.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              );
            })()}
          </div>
        ) : activeTab === 'Settings' ? (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-8 rounded-3xl border transition-all duration-300 ${theme === 'dark' ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-100 shadow-[0_4px_25px_rgba(0,0,0,0.02)]'}`}
          >
            <div className="space-y-8">
              {/* Currency selection */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gray-50/50 dark:bg-gray-800/20 border border-gray-100/50 dark:border-gray-800/30">
                <div>
                  <h4 className={`font-bold text-sm ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    {language === 'English' ? 'Base Valuation Currency' : 'ভিত্তি মূল্যায়ন মুদ্রা'}
                  </h4>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-800 p-1 rounded-2xl border border-gray-200/50 dark:border-gray-750 self-start md:self-auto shrink-0 shadow-inner">
                  {(['BDT', 'USD', 'EUR'] as const).map((cur) => {
                    const isActive = currency === cur;
                    return (
                      <button
                        key={cur}
                        onClick={() => setCurrency(cur)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer ${
                          isActive 
                            ? 'bg-corporate-navy text-white shadow-md' 
                            : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white'
                        }`}
                      >
                        {cur === 'BDT' ? '৳ BDT' : cur === 'USD' ? '$ USD' : '€ EUR'}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Language selection */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gray-50/50 dark:bg-gray-800/20 border border-gray-100/50 dark:border-gray-800/30">
                <div>
                  <h4 className={`font-bold text-sm ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    {language === 'English' ? 'Application Language' : 'অ্যাপ্লিকেশনের ভাষা'}
                  </h4>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-800 p-1 rounded-2xl border border-gray-200/50 dark:border-gray-750 self-start md:self-auto shrink-0 shadow-inner">
                  {(['English', 'Bangla'] as const).map((lang) => {
                    const isActive = language === lang;
                    return (
                      <button
                        key={lang}
                        onClick={() => setLanguage(lang)}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer ${
                          isActive 
                            ? 'bg-corporate-navy text-white shadow-md' 
                            : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white'
                        }`}
                      >
                        <span className="flex items-center gap-1.5">
                          <Globe size={13} />
                          {lang === 'English' ? 'English' : 'বাংলা'}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Theme selection */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gray-50/50 dark:bg-gray-800/20 border border-gray-100/50 dark:border-gray-800/30">
                <div>
                  <h4 className={`font-bold text-sm ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    {language === 'English' ? 'Interface Theme (Lighting)' : 'ডিসপ্লে থিম'}
                  </h4>
                </div>
                <div className="flex bg-gray-100 dark:bg-gray-800 p-1 rounded-2xl border border-gray-200/55 self-start md:self-auto shrink-0 shadow-inner">
                  <button
                    onClick={() => setTheme('light')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                      theme === 'light' 
                        ? 'bg-white text-gray-950 shadow-md' 
                        : 'text-gray-500 dark:text-gray-400 hover:text-white'
                    }`}
                  >
                    <Sun size={13} className="text-amber-500" />
                    {language === 'English' ? 'Light' : 'লাইট'}
                  </button>
                  <button
                    onClick={() => setTheme('dark')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                      theme === 'dark' 
                        ? 'bg-corporate-navy text-white shadow-md' 
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-800'
                    }`}
                  >
                    <Moon size={13} className="text-indigo-200" />
                    {language === 'English' ? 'Dark' : 'ডার্ক'}
                  </button>
                </div>
              </div>
            </div>

            {/* Informational banner footer */}
            <div className="mt-8 p-4 bg-gray-50 dark:bg-gray-800/30 border border-gray-200/50 dark:border-gray-800/40 rounded-2xl flex items-center gap-3">
              <Sparkles className="text-corporate-navy shrink-0 animate-bounce" size={16} />
              <p className="text-xs text-gray-500 dark:text-gray-400 font-semibold leading-relaxed">
                {language === 'English' 
                  ? 'Note: All values in USD and EUR are computed using standard real-time conversions (1 USD = ৳117.5 BDT, 1 EUR = ৳126.8 BDT). The original historical numbers in the database remain intact, ensuring complete data consistency and persistence across settings toggles.' 
                  : 'তথ্য: ইউএসডি এবং ইউরো বিনিময় মূল্যসমূহ প্রকৃত বিনিময় হার (১ ডলার = ১১৭.৫ টাকা, ১ ইউরো = ১২৬.৮ টাকা) অনুযায়ী নির্ধারিত। মূল ডাটাবেজের ডেসিমেল মানসমূহ অপরিবর্তিত থাকে যা নিখুঁত ডেটা স্থায়িত্ব নিশ্চিত করে।'}
              </p>
            </div>
          </motion.div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 bg-white rounded-3xl border border-dashed border-gray-200">
            <LayoutDashboard className="text-gray-200 mb-4" size={64} />
            <h3 className="text-xl font-bold text-gray-400">Section Not Active</h3>
            <p className="text-gray-400 text-sm mt-2">Please navigate to other active modules using the sidebar.</p>
            <button 
              onClick={() => setActiveTab('Overview')}
              className="mt-6 px-6 py-2 bg-gray-100 text-gray-600 rounded-xl text-sm font-bold hover:bg-gray-200 transition-colors"
            >
              Back to Overview
            </button>
          </div>
        )}

        {/* --- Remove Partner Confirmation Modal --- */}
        <AnimatePresence>
          {partnerToRemove && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setPartnerToRemove(null)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden z-10"
              >
                <div className="p-8">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-red-50 text-red-600 rounded-2xl">
                      <Trash2 size={24} />
                    </div>
                    <button 
                      onClick={() => setPartnerToRemove(null)} 
                      className="p-2 hover:bg-gray-100 rounded-xl transition-colors cursor-pointer"
                    >
                      <X size={20} className="text-gray-400" />
                    </button>
                  </div>

                  <h3 className="text-lg font-bold text-gray-950">Remove Partner Allocations?</h3>
                  <p className="text-sm text-gray-500 mt-2 leading-relaxed">
                    Are you sure you want to remove all of <span className="font-bold text-gray-905">{partnerToRemove.investorName}</span>'s remaining asset allocations from this project?
                  </p>
                  <p className="text-xs text-red-500 font-semibold mt-3 bg-red-50 p-2.5 rounded-xl border border-red-100">
                    ⚠️ This will permanently delete their investment records and reduce the project's total funding!
                  </p>

                  <div className="flex gap-3 mt-6">
                    <button
                      type="button"
                      onClick={() => setPartnerToRemove(null)}
                      className="flex-1 px-4 py-3 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-xl font-bold text-sm transition-all cursor-pointer border border-gray-100"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmRemovePartner}
                      className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-sm transition-all cursor-pointer shadow-lg shadow-red-600/10"
                    >
                      Yes, Remove Partner
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Add Investment Modal --- */}
        <AnimatePresence>
          {isInvestmentModalOpen && activeInvestor && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsInvestmentModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Add Investment</h3>
                      <p className="text-sm text-gray-500 mt-1">Allocate capital for {activeInvestor.name}</p>
                      <p className="text-xs text-indigo-600 font-bold mt-1">Available Uninvested Balance: ৳{activeInvestorUnallocated.toLocaleString()}</p>
                    </div>
                    <button onClick={() => setIsInvestmentModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleAddInvestment} className="space-y-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Target Project</label>
                      <div className="relative group">
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newInvestment.projectId}
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val === "custom") {
                              setNewInvestment({...newInvestment, projectId: '', projectName: ''});
                            } else {
                              const proj = projects.find(p => p.id === val);
                              setNewInvestment({
                                ...newInvestment, 
                                projectId: val, 
                                projectName: proj?.name || '',
                                sector: proj?.sector || newInvestment.sector
                              });
                            }
                          }}
                        >
                          <option value="">-- Choose Existing Project --</option>
                          {projects.map(p => (
                            <option key={p.id} value={p.id}>{p.name} ({p.sector})</option>
                          ))}
                          <option value="custom">Other / Manual Entry</option>
                        </select>
                        <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 rotate-90 text-gray-400 pointer-events-none" size={16} />
                      </div>
                    </div>

                    {!newInvestment.projectId && (
                      <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Manual Project Name</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="e.g. Solar Farm Phase I"
                          value={newInvestment.projectName}
                          onChange={(e) => setNewInvestment({...newInvestment, projectName: e.target.value})}
                        />
                      </motion.div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Amount (৳)</label>
                        <input 
                          required
                          type="number" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="0.00"
                          value={newInvestment.amount || ''}
                          onChange={(e) => setNewInvestment({...newInvestment, amount: Number(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Sector</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newInvestment.sector}
                          onChange={(e) => setNewInvestment({...newInvestment, sector: e.target.value})}
                        >
                          <option value="Fun House">Fun House</option>
                          <option value="Duck farm">Duck farm</option>
                          <option value="chicken farm">chicken farm</option>
                          <option value="Fishing">Fishing</option>
                          <option value="Farming">Farming</option>
                          <option value="Others">Others</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Allocation Date</label>
                        <input 
                          required
                          type="date" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newInvestment.date}
                          onChange={(e) => setNewInvestment({...newInvestment, date: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Description</label>
                        <input 
                          type="text" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="e.g. 1st Installment"
                          value={newInvestment.description}
                          onChange={(e) => setNewInvestment({...newInvestment, description: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="pt-4">
                      <button 
                        type="submit"
                        className="w-full py-4 bg-corporate-navy text-white rounded-2xl font-bold text-sm shadow-xl shadow-corporate-navy/20 hover:bg-corporate-blue transition-all active:scale-[0.98]"
                      >
                        Confirm Allocation
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Top Up Capital Modal --- */}
        <AnimatePresence>
          {isTopUpModalOpen && activeInvestor && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsTopUpModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Top Up Capital</h3>
                      <p className="text-sm text-gray-500 mt-1">Add raw cash for {activeInvestor.name}</p>
                    </div>
                    <button onClick={() => setIsTopUpModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleTopUpCapital} className="space-y-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Injected Amount (৳)</label>
                      <input 
                        required
                        type="number" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="0.00"
                        value={topUpAmount || ''}
                        onChange={(e) => setTopUpAmount(Number(e.target.value))}
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Injection Date</label>
                      <input 
                        required
                        type="date" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        value={topUpDate}
                        onChange={(e) => setTopUpDate(e.target.value)}
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Top-up Description</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="e.g. Phase 2 Cash Injection"
                        value={topUpDescription}
                        onChange={(e) => setTopUpDescription(e.target.value)}
                      />
                    </div>

                    <div className="pt-4">
                      <button 
                        type="submit"
                        className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold text-sm shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all active:scale-[0.98]"
                      >
                        Add Capital to Partner Balance
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Add Project Modal --- */}
        <AnimatePresence>
          {isProjectModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsProjectModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">
                        {editingProject ? 'Edit Venture' : 'Setup New Venture'}
                      </h3>
                      <p className="text-sm text-gray-500 mt-1">
                        {editingProject ? 'Update your business initiative' : 'Define your next business initiative'}
                      </p>
                    </div>
                    <button 
                      onClick={() => {
                        setIsProjectModalOpen(false);
                        setEditingProject(null);
                        setNewProject({ name: '', sector: 'Fun House', status: 'Active' });
                      }} 
                      className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                    >
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleAddProject} className="space-y-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Project Name</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="e.g. Fun House, Fishing, or Farming"
                        value={newProject.name}
                        onChange={(e) => setNewProject({...newProject, name: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Sector</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newProject.sector}
                          onChange={(e) => setNewProject({...newProject, sector: e.target.value})}
                        >
                          <option value="Fun House">Fun House</option>
                          <option value="Duck farm">Duck farm</option>
                          <option value="chicken farm">chicken farm</option>
                          <option value="Fishing">Fishing</option>
                          <option value="Farming">Farming</option>
                          <option value="Others">Others</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Status</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newProject.status}
                          onChange={(e) => setNewProject({...newProject, status: e.target.value as any})}
                        >
                          <option value="Planning">Planning</option>
                          <option value="Active">Active</option>
                          <option value="Completed">Completed</option>
                          <option value="On Hold">On Hold</option>
                        </select>
                      </div>
                    </div>

                    <div className="pt-4">
                      <button 
                        type="submit"
                        className="w-full py-4 bg-corporate-navy text-white rounded-2xl font-bold text-sm shadow-xl shadow-corporate-navy/20 hover:bg-corporate-blue transition-all flex items-center justify-center gap-2"
                      >
                        <Save size={18} />
                        {editingProject ? 'Save Changes Permanently' : 'Launch Project Permanently'}
                      </button>
                      <p className="text-center text-[10px] text-gray-400 mt-4 uppercase tracking-[0.2em] font-bold">
                        Cloud Sync Enabled • All Changes Are Permanent
                      </p>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Add Dashboard Investment Modal --- */}
        <AnimatePresence>
          {isDashboardInvestmentModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsDashboardInvestmentModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden z-10"
              >
                <div className="p-8">
                  {/* Title & Close */}
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Capital Entry Terminal</h3>
                      <p className="text-sm text-gray-500 mt-1">Manage partners and raw capital deposits</p>
                    </div>
                    <button onClick={() => setIsDashboardInvestmentModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  {/* Tabs */}
                  <div className="flex border-b border-gray-150 mb-6 font-semibold text-sm">
                    <button 
                      onClick={() => setDashboardModalTab('new_investor')}
                      className={`flex-1 pb-3 text-center transition-all border-b-2 ${dashboardModalTab === 'new_investor' ? 'text-corporate-navy border-corporate-navy font-bold' : 'text-gray-400 border-transparent hover:text-gray-600'}`}
                    >
                      Onboard New Partner
                    </button>
                    <button 
                      onClick={() => setDashboardModalTab('top_up')}
                      className={`flex-1 pb-3 text-center transition-all border-b-2 ${dashboardModalTab === 'top_up' ? 'text-corporate-navy border-corporate-navy font-bold' : 'text-gray-400 border-transparent hover:text-gray-600'}`}
                    >
                      Top Up Capital
                    </button>
                  </div>

                  {dashboardModalTab === 'new_investor' ? (
                    /* Form 1: Add New Investor */
                    <form onSubmit={handleAddInvestor} className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Full Name</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="e.g. Johnathan Doe"
                          value={newInvestor.name}
                          onChange={(e) => setNewInvestor({...newInvestor, name: e.target.value})}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Investment Amount (৳)</label>
                          <input 
                            required
                            type="number" 
                            className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                            placeholder="0.00"
                            value={newInvestor.totalCapital || ''}
                            onChange={(e) => setNewInvestor({...newInvestor, totalCapital: Number(e.target.value)})}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Equity Share (%)</label>
                          <input 
                            required
                            type="text" 
                            className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                            placeholder="e.g. 15%"
                            value={newInvestor.equity}
                            onChange={(e) => setNewInvestor({...newInvestor, equity: e.target.value})}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Join Date</label>
                        <input 
                          required
                          type="date" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newInvestor.date}
                          onChange={(e) => setNewInvestor({...newInvestor, date: e.target.value})}
                        />
                      </div>

                      <div className="flex gap-3 pt-4">
                        <button 
                          type="button" 
                          onClick={() => setIsDashboardInvestmentModalOpen(false)} 
                          className="flex-1 py-3 border border-gray-100 rounded-2xl text-sm font-bold text-gray-500 hover:bg-gray-50 transition-colors"
                        >
                          Cancel
                        </button>
                        <button 
                          type="submit" 
                          className="flex-1 py-3 bg-corporate-navy text-white rounded-2xl text-sm font-bold hover:bg-corporate-blue transition-colors shadow-lg shadow-corporate-navy/10"
                        >
                          Onboard Partner
                        </button>
                      </div>
                    </form>
                  ) : (
                    /* Form 2: Top Up Capital */
                    <form onSubmit={handleDashboardTopUpClick} className="space-y-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Select Partner</label>
                        <select 
                          required
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={dashboardTopUpInvId}
                          onChange={(e) => setDashboardTopUpInvId(e.target.value)}
                        >
                          <option value="">-- Choose Partner --</option>
                          {investors.map(inv => (
                            <option key={inv.id} value={inv.id}>{inv.name} (Current Cap: ৳{inv.totalCapital.toLocaleString()})</option>
                          ))}
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Top-up Amount (৳)</label>
                          <input 
                            required
                            type="number" 
                            className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                            placeholder="0.00"
                            value={dashboardTopUpAmount || ''}
                            onChange={(e) => setDashboardTopUpAmount(Number(e.target.value))}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Deposit Date</label>
                          <input 
                            required
                            type="date" 
                            className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                            value={dashboardTopUpDate}
                            onChange={(e) => setDashboardTopUpDate(e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Deposit Description</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="e.g. Phase 2 Top Up"
                          value={dashboardTopUpDesc}
                          onChange={(e) => setDashboardTopUpDesc(e.target.value)}
                        />
                      </div>

                      <div className="flex gap-3 pt-4">
                        <button 
                          type="button" 
                          onClick={() => setIsDashboardInvestmentModalOpen(false)} 
                          className="flex-1 py-3 border border-gray-100 rounded-2xl text-sm font-bold text-gray-500 hover:bg-gray-50 transition-colors"
                        >
                          Cancel
                        </button>
                        <button 
                          type="submit" 
                          className="flex-1 py-3 bg-corporate-navy text-white rounded-2xl text-sm font-bold hover:bg-corporate-blue transition-colors shadow-lg shadow-corporate-navy/10"
                        >
                          Deposit Capital
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Add Investor Modal --- */}
        <AnimatePresence>
          {isModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Partner Registration</h3>
                      <p className="text-sm text-gray-500 mt-1">Onboard a new capital contributor</p>
                    </div>
                    <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleAddInvestor} className="space-y-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Full Name</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="e.g. Johnathan Doe"
                        value={newInvestor.name}
                        onChange={(e) => setNewInvestor({...newInvestor, name: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Investment Amount (৳)</label>
                        <input 
                          required
                          type="number" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="0.00"
                          value={newInvestor.totalCapital || ''}
                          onChange={(e) => setNewInvestor({...newInvestor, totalCapital: Number(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Equity Share (%)</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="e.g. 15%"
                          value={newInvestor.equity}
                          onChange={(e) => setNewInvestor({...newInvestor, equity: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Join Date</label>
                        <input 
                          required
                          type="date" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newInvestor.date}
                          onChange={(e) => setNewInvestor({...newInvestor, date: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Initial Proj</label>
                        <input 
                          required
                          type="number" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newInvestor.projects}
                          onChange={(e) => setNewInvestor({...newInvestor, projects: Number(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">Status</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newInvestor.status}
                          onChange={(e) => setNewInvestor({...newInvestor, status: e.target.value as any})}
                        >
                          <option value="Active">Active</option>
                          <option value="Pending">Pending</option>
                          <option value="Inactive">Inactive</option>
                        </select>
                      </div>
                    </div>

                    <div className="pt-4">
                      <button 
                        type="submit"
                        className="w-full py-4 bg-corporate-navy text-white rounded-2xl font-bold text-sm shadow-xl shadow-corporate-navy/20 hover:bg-corporate-blue transition-all active:scale-[0.98]"
                      >
                        Complete Onboarding
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Record Expense Modal --- */}
        <AnimatePresence>
          {isExpenseModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsExpenseModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Record Expense</h3>
                      <p className="text-sm text-gray-500 mt-1">Track operational costs and outflows</p>
                    </div>
                    <button onClick={() => setIsExpenseModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleAddExpense} className="space-y-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Description</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="e.g. Office Rent, Marketing Campaign"
                        value={newExpense.description}
                        onChange={(e) => setNewExpense({...newExpense, description: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Target Project</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newExpense.projectId}
                          onChange={(e) => setNewExpense({...newExpense, projectId: e.target.value})}
                        >
                          <option value="">General (No Project)</option>
                          {projects.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Category</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newExpense.category}
                          onChange={(e) => setNewExpense({...newExpense, category: e.target.value})}
                        >
                          <option value="Operational">Operational</option>
                          <option value="Marketing">Marketing</option>
                          <option value="Setup">Setup</option>
                          <option value="Personal">Personal</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Amount (৳)</label>
                        <input 
                          required
                          type="number" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="0.00"
                          value={newExpense.amount || ''}
                          onChange={(e) => setNewExpense({...newExpense, amount: Number(e.target.value)})}
                        />
                      </div>
                      <div className="pt-4">
                        <button 
                          type="submit"
                          className="w-full py-4 bg-red-600 text-white rounded-2xl font-bold text-sm shadow-xl shadow-red-600/20 hover:bg-red-700 transition-all active:scale-[0.98]"
                        >
                          Record Outflow Permanently
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Record Profit Modal --- */}
        <AnimatePresence>
          {isProfitModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsProfitModalOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Record Profit Inflow</h3>
                      <p className="text-sm text-gray-500 mt-1">Add revenue generated from specific projects</p>
                    </div>
                    <button onClick={() => setIsProfitModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleAddProfit} className="space-y-5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Target Project</label>
                      <select 
                        required
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        value={newProfit.projectId}
                        onChange={(e) => setNewProfit({...newProfit, projectId: e.target.value})}
                      >
                        <option value="">Select Project</option>
                        {projects.map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Profit Amount (৳)</label>
                      <input 
                        required
                        type="number" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="0.00"
                        value={newProfit.amount || ''}
                        onChange={(e) => setNewProfit({...newProfit, amount: Number(e.target.value)})}
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Description</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="e.g. 1st Batch Sale Profit, Service Fee"
                        value={newProfit.description}
                        onChange={(e) => setNewProfit({...newProfit, description: e.target.value})}
                      />
                    </div>

                    <div className="pt-4">
                      <button 
                        type="submit"
                        className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold text-sm shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all active:scale-[0.98]"
                      >
                        Save Profit Permanently
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- Record Buy & Sales Modal --- */}
        <AnimatePresence>
          {isBuySaleModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={handleCloseBuySaleModal}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
              >
                <div className="p-8">
                  <div className="flex justify-between items-center mb-8">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">
                        {editingBuySale ? 'Edit Record' : 'Record Buy/Sale Deal'}
                      </h3>
                      <p className="text-sm text-gray-500 mt-1">
                        {editingBuySale ? 'Modify active trade details or stock on-hand quantity' : 'Log commercial trade deals, supply acquisition, or merchandise sells'}
                      </p>
                    </div>
                    <button onClick={handleCloseBuySaleModal} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                      <X size={24} className="text-gray-400" />
                    </button>
                  </div>

                  <form onSubmit={handleAddBuySale} className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 font-sans">Item / Merchandise Name</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                        placeholder="e.g. Organic Seeds, Heavy Construction Sand"
                        value={newBuySale.itemName}
                        onChange={(e) => setNewBuySale({...newBuySale, itemName: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Transaction Type</label>
                        <select 
                          required
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newBuySale.type}
                          onChange={(e) => setNewBuySale({...newBuySale, type: e.target.value as any})}
                        >
                          <option value="Buy">Procurement (Buy)</option>
                          <option value="Sale">Commercial (Sale)</option>
                          <option value="Initial">Direct Stock On-Hand (Initial)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Target Project</label>
                        <select 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all appearance-none"
                          value={newBuySale.projectId}
                          onChange={(e) => setNewBuySale({...newBuySale, projectId: e.target.value})}
                        >
                          <option value="">General / None</option>
                          {projects.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Quantity</label>
                        <input 
                          required
                          type="number"
                          min="1"
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="qty"
                          value={newBuySale.quantity}
                          onChange={(e) => setNewBuySale({...newBuySale, quantity: Number(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">
                          {newBuySale.type === 'Initial' ? 'Unit Price (Ignored)' : 'Unit Price (৳)'}
                        </label>
                        <input 
                          required={newBuySale.type !== 'Initial'}
                          disabled={newBuySale.type === 'Initial'}
                          type="number"
                          min="0"
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all disabled:opacity-50"
                          placeholder={newBuySale.type === 'Initial' ? '৳0 (Direct On-Hand)' : 'price per unit'}
                          value={newBuySale.type === 'Initial' ? 0 : (newBuySale.unitPrice || '')}
                          onChange={(e) => setNewBuySale({...newBuySale, unitPrice: Number(e.target.value)})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Partner (Cust/Vend)</label>
                        <input 
                          type="text" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          placeholder="e.g. Acme Supplier Ltd"
                          value={newBuySale.partnerName}
                          onChange={(e) => setNewBuySale({...newBuySale, partnerName: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Transaction Date</label>
                        <input 
                          required
                          type="date" 
                          className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 focus:border-corporate-navy transition-all"
                          value={newBuySale.date}
                          onChange={(e) => setNewBuySale({...newBuySale, date: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="pt-4 flex items-center justify-between gap-3 bg-gray-50 -mx-8 -mb-8 p-6 mt-4">
                      <div className="text-left">
                        <span className="text-[10px] text-gray-400 uppercase font-bold tracking-widest block">Estimated Total</span>
                        <span className="text-lg font-black text-gray-950">৳{(Number(newBuySale.quantity || 0) * Number(newBuySale.unitPrice || 0)).toLocaleString()}</span>
                      </div>
                      <button 
                        type="submit"
                        className="py-3 px-6 bg-corporate-navy text-white rounded-xl font-bold text-xs shadow-xl shadow-corporate-navy/20 hover:bg-corporate-blue transition-all active:scale-[0.98] cursor-pointer"
                      >
                        {editingBuySale ? '✔ Update Record' : '✔ Save Transaction'}
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* --- AI Chatbot Overlay Modal --- */}
        <AnimatePresence>
          {isChatOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsChatOpen(false)}
                className="absolute inset-0 bg-corporate-navy/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className={`relative rounded-3xl border shadow-2xl overflow-hidden flex flex-col h-[700px] w-full max-w-4xl z-10 transition-all duration-300 ${
                  theme === 'dark' ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-100'
                }`}
              >
                {/* Bot Header */}
                <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between bg-corporate-navy/5">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-corporate-navy text-white rounded-xl shadow-lg">
                      <Bot size={22} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-base text-gray-900 dark:text-gray-100 leading-normal">
                          {language === 'English' ? 'CapitalHub AI Advisor' : 'ক্যাপিটালহাব এআই আর্থিক পরামর্শক'}
                        </h3>
                        <span className="bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                          {language === 'English' ? 'Active' : 'সক্রিয়'}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5 font-medium">
                        {language === 'English' ? 'Real-time contextual financial intelligence powered by Gemini 2.5' : 'জেমিলাই ২.৫ দ্বারা চালিত রিয়েল-টাইম প্রাসঙ্গিক আর্থিক বুদ্ধিমত্তা'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      type="button"
                      onClick={() => setChatMessages([
                        { role: 'assistant', content: language === 'English' ? "Hello! Let's start fresh. What can I analyze for you today?" : "হ্যালো! নতুন করে আলোচনা শুরু করা যাক। আজ আমি আপনার জন্য কী বিশ্লেষণ করতে পারি?" }
                      ])}
                      className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                    >
                      <RefreshCw size={12} />
                      {language === 'English' ? 'Clear Thread' : 'মেমরি মুছুন'}
                    </button>
                    <button 
                      type="button"
                      onClick={() => setIsChatOpen(false)}
                      className="p-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-xl transition-all cursor-pointer"
                    >
                      <X size={18} />
                    </button>
                  </div>
                </div>

                {/* Chat Messages */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/30 dark:bg-gray-900/10">
                  {chatMessages.map((msg, index) => {
                    const isUser = msg.role === 'user';
                    return (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed ${
                          isUser 
                            ? 'bg-corporate-navy text-white rounded-br-none shadow-md shadow-corporate-navy/10' 
                            : theme === 'dark'
                              ? 'bg-gray-805 text-gray-100 border border-gray-700 rounded-bl-none'
                              : 'bg-white text-gray-900 border border-gray-100 shadow-sm rounded-bl-none'
                        }`}>
                          {!isUser && (
                            <div className="flex items-center gap-1.5 mb-1.5 text-xs font-bold text-corporate-navy dark:text-corporate-blue">
                              <Bot size={13} />
                              <span>AI Financial Specialist</span>
                            </div>
                          )}
                          <p className="whitespace-pre-wrap font-medium">{msg.content}</p>
                        </div>
                      </motion.div>
                    );
                  })}

                  {isChatLoading && (
                    <div className="flex justify-start">
                      <div className={`p-4 rounded-2xl text-sm border flex items-center gap-3 ${theme === 'dark' ? 'bg-gray-820 text-gray-200 border-gray-700' : 'bg-white text-gray-700 border-gray-100 shadow-sm'}`}>
                        <Bot size={16} className="text-corporate-navy animate-bounce" />
                        <div className="flex gap-1.5 items-center">
                          <span className="w-2 h-2 bg-corporate-navy/40 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-2 h-2 bg-corporate-navy/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-2 h-2 bg-corporate-navy rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          <span className="text-xs font-bold text-gray-400 ml-1">Analyzing financial ledgers...</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* AI Prompts Section and Toggle Header */}
                <div className="border-t border-gray-100 dark:border-gray-800 bg-gray-50/5">
                  <div className="px-6 py-2.5 flex items-center justify-between border-b border-gray-100/40 dark:border-gray-800/40">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-gray-500 uppercase tracking-wider">
                      <Sparkles size={13} className="text-corporate-navy dark:text-corporate-blue" />
                      <span>{language === 'English' ? 'Quick Prompts' : 'দ্রুত প্রশ্ন সাজেশন'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowQuickPrompts(!showQuickPrompts)}
                      className="p-1 px-2 rounded-md bg-gray-100 dark:bg-gray-800 text-gray-500 hover:text-red-500 dark:text-gray-400 hover:bg-gray-200 cursor-pointer font-bold text-xs flex items-center gap-1 transition-all"
                      title={showQuickPrompts ? (language === 'English' ? "Hide Suggestions" : "লুকান") : (language === 'English' ? "Show Suggestions" : "দেখান")}
                    >
                      {showQuickPrompts ? (
                        <>
                          <span className="text-sm font-semibold">✕</span>
                          <span className="text-[10px] font-bold">{language === 'English' ? 'Hide' : 'লুকান'}</span>
                        </>
                      ) : (
                        <>
                          <span className="text-sm font-bold">+</span>
                          <span className="text-[10px] font-bold">{language === 'English' ? 'Show Prompts' : 'সাজেশন দেখান'}</span>
                        </>
                      )}
                    </button>
                  </div>

                  {showQuickPrompts && (
                    <div className="px-6 py-4 grid grid-cols-1 md:grid-cols-2 gap-2 bg-gray-50/10 animate-in fade-in duration-200">
                      {[
                        {
                          en: "Give me an overview of total capital raise and current uninvested cash.",
                          bn: "মোট সংগৃহীত মূলধন এবং বর্তমান বিনিয়োগবিহীন নগদ রিজার্ভের একটি বিবরণ দিন।"
                        },
                        {
                          en: "Which projects have recorded the highest profit margins?",
                          bn: "কোন প্রজেক্টে সবচেয়ে বেশি লাভ অর্জিত হয়েছে?"
                        },
                        {
                          en: "Analyze our overall net profit versus operating expenses.",
                          bn: "মোট অর্জিত লাভ বনাম অপারেটিং লোকসান/খরচের একটি আর্থিক বিশ্লেষণ করুন।"
                        },
                        {
                          en: "Who is the top investor by capital share and what is their equity stake?",
                          bn: "মূলধন বন্টন অনুযায়ী সবচেয়ে বড় বিনিয়োগকারী কে এবং তাঁর নিবন্ধিত ইক্যুইটি কত?"
                        }
                      ].map((rec, i) => {
                        const promptVal = language === 'English' ? rec.en : rec.bn;
                        return (
                          <button
                            key={i}
                            type="button"
                            onClick={() => {
                              setChatInput(promptVal);
                            }}
                            className={`text-left p-3 rounded-xl border text-xs font-semibold transition-all hover:scale-[1.01] cursor-pointer ${
                              theme === 'dark' 
                                ? 'bg-gray-800 hover:bg-gray-750 border-gray-700 text-gray-200' 
                                : 'bg-white hover:bg-gray-50 border-gray-150 text-gray-600'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 text-[10px] font-bold text-corporate-navy dark:text-corporate-blue mb-1">
                              <Sparkles size={11} />
                              <span>{language === 'English' ? 'Quick Prompt' : 'দ্রুত প্রশ্ন'}</span>
                            </div>
                            <span className="line-clamp-1">{promptVal}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Input Form */}
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendChatMessage();
                  }} 
                  className="p-4 border-t border-gray-100 dark:border-gray-800 flex gap-3 items-center bg-white dark:bg-gray-900"
                >
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={language === 'English' ? "Type your analytical query here..." : "আপনার প্রশ্নটি বাংলায় অথবা ইংরেজিতে এখানে লিখুন..."}
                    className={`flex-1 px-4 py-3 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-corporate-navy/20 ${
                      theme === 'dark' 
                        ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:border-corporate-blue' 
                        : 'bg-gray-50 border-gray-150 text-gray-900 focus:border-corporate-navy'
                    }`}
                    disabled={isChatLoading}
                  />
                  <button
                    type="submit"
                    disabled={isChatLoading || !chatInput.trim()}
                    className={`px-5 py-3 rounded-xl font-bold text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer ${
                      isChatLoading || !chatInput.trim()
                        ? 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-600 cursor-not-allowed shadow-none'
                        : 'bg-corporate-navy text-white hover:bg-corporate-blue active:scale-95'
                    }`}
                  >
                    {language === 'English' ? 'Ask Advisor' : 'পরামর্শ নিন'}
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* --- Mobile Bottom Taskbar / Menu Dock --- */}
      <div className={`fixed bottom-0 left-0 right-0 z-40 lg:hidden border-t backdrop-blur-md transition-all duration-300 ${
        theme === 'dark' 
          ? 'bg-gray-900/98 border-gray-800 text-white shadow-[0_-10px_35px_rgba(0,0,0,0.5)]' 
          : 'bg-white/98 border-gray-100 text-gray-900 shadow-[0_-10px_35px_rgba(0,0,0,0.08)]'
      }`}>
        <div className="grid grid-cols-4 gap-y-1.5 gap-x-1 p-2.5 max-w-md mx-auto">
          {[
            { id: 'Overview', labelEn: 'Overview', labelBn: 'ওভারভিউ', icon: LayoutDashboard },
            { id: 'Investors', labelEn: 'Investors', labelBn: 'বিনিয়োগকারী', icon: Users, beforeClick: () => setSelectedInvestor(null) },
            { id: 'Projects', labelEn: 'Projects', labelBn: 'প্রজেক্টস', icon: BarChart3, beforeClick: () => setSelectedProject(null) },
            { id: 'BuySales', labelEn: 'Buy & Sales', labelBn: 'ক্রয়-বিক্রয়', icon: ShoppingBag },
            { id: 'Expenses', labelEn: 'Expenses', labelBn: 'লাভ-ক্ষতি', icon: FileText },
            { id: 'Profit Analytics', labelEn: 'Analytics', labelBn: 'লাভ বিশ্লেষণ', icon: TrendingUp },
            { id: 'Settings', labelEn: 'Settings', labelBn: 'সেটিংস', icon: Settings },
            { id: 'AIChatBot', labelEn: 'AI Chat', labelBn: 'এআই চ্যাট', icon: Bot, isChat: true }
          ].map((tab) => {
            const isTabActive = tab.isChat ? isChatOpen : (activeTab === tab.id && !isChatOpen);
            const Icon = tab.icon;
            const label = language === 'English' ? tab.labelEn : tab.labelBn;
            
            return (
              <button
                key={tab.id}
                onClick={() => {
                  if (tab.isChat) {
                    setIsChatOpen(!isChatOpen);
                  } else {
                    if (tab.beforeClick) tab.beforeClick();
                    setIsChatOpen(false); // Close AI chat overlay if user clicks other normal tabs
                    setActiveTab(tab.id);
                  }
                }}
                className={`flex flex-col items-center justify-center p-1.5 rounded-xl font-bold transition-all duration-200 text-center ${
                  isTabActive
                    ? 'bg-corporate-navy text-white shadow-md'
                    : theme === 'dark'
                      ? 'text-gray-400 hover:bg-gray-800 hover:text-white'
                      : 'text-gray-550 hover:bg-gray-50 hover:text-gray-800'
                }`}
              >
                <Icon size={16} className={isTabActive ? 'animate-pulse' : ''} />
                <span className="text-[10px] mt-0.5 leading-tight font-bold text-center truncate w-full">
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
