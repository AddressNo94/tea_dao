import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { doc, updateDoc } from "firebase/firestore";
import { db, app } from "./firebase";

let messaging: any = null;
try {
  if (typeof window !== "undefined" && "serviceWorker" in navigator) {
    messaging = getMessaging(app);
  }
} catch (e) {
  console.warn("Firebase Cloud Messaging is not supported in this browser or iframe environment:", e);
}

/**
 * Requests push permission from the browser, retrieves the FCM registration token,
 * and saves it to the user's document in the 'users' collection in Firestore.
 */
export const requestNotificationPermission = async (userId: string) => {
  if (typeof window === "undefined" || !("Notification" in window)) {
    console.warn("Web Notification APIs are not supported in this environment.");
    return;
  }

  if (!messaging) {
    console.warn("FCM Messaging could not be initialized due to environment limitations.");
    return;
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      // Use custom key if registered, otherwise fall back to empty or placeholder to avoid throwing on empty key
      const vapidKey = (import.meta as any).env.VITE_FCM_VAPID_KEY || "YOUR_PUBLIC_VAPID_KEY_PLACEHOLDER";
      
      const token = await getToken(messaging, { 
        vapidKey: vapidKey
      });
      
      if (token) {
        // Save the FCM token to the user document
        await updateDoc(doc(db, "users", userId), { 
          fcmToken: token,
          fcmTokenUpdatedAt: new Date()
        });
        console.log("FCM registration token updated successfully in profile:", token);
      } else {
        console.warn("No FCM registration token received from getToken call.");
      }
    } else {
      console.warn("Push notification permission denied by the user. Permission state:", permission);
    }
  } catch (error) {
    console.error("Error during FCM notification permission setup:", error);
  }
};

/**
 * Register a listener to process push notifications in the foreground
 */
export const onForegroundMessage = (callback: (payload: any) => void) => {
  if (!messaging) return () => {};
  try {
    return onMessage(messaging, (payload) => {
      callback(payload);
    });
  } catch (err) {
    console.error("Error subscribing to foreground FCM push messages:", err);
    return () => {};
  }
};
