import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { 
  ShoppingBag, 
  Trash2, 
  TrendingUp, 
  Coins, 
  Briefcase,
  ArrowUpRight,
  ArrowDownLeft,
  Filter,
  Package,
  Search,
  Calendar,
  Edit2
} from 'lucide-react';

interface BuySaleRecord {
  id: string;
  itemName: string;
  type: 'Buy' | 'Sale' | 'Initial';
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  projectId?: string;
  projectName?: string;
  partnerName?: string;
  date: string;
  createdAt: any;
}

interface Project {
  id: string;
  name: string;
  sector: string;
  totalFunding: number;
  investorCount: number;
  status: any;
  createdAt: any;
}

interface BuySalesViewProps {
  buySales: BuySaleRecord[];
  projects: Project[];
  projectFilter: string;
  searchTerm: string;
  setSearchTerm: (val: string) => void;
  onDeleteBuySale: (id: string) => void;
  onEditBuySale: (record: BuySaleRecord) => void;
  onQuickEditInitial: (productName: string) => void;
  formatDate: (ts: any) => string;
  isAccountant?: boolean;
}

export default function BuySalesView({
  buySales,
  projects,
  projectFilter,
  searchTerm,
  setSearchTerm,
  onDeleteBuySale,
  onEditBuySale,
  onQuickEditInitial,
  formatDate,
  isAccountant = true
}: BuySalesViewProps) {
  const [typeFilter, setTypeFilter] = useState<'all' | 'Buy' | 'Sale' | 'Initial'>('all');
  const [sortBy, setSortBy] = useState<'date' | 'amount'>('date');
  const [monthFilter, setMonthFilter] = useState<string>('all');
  const [reportMonth, setReportMonth] = useState<string>('');

  // Render date with Day, Month, Year clearly
  const renderTransactionDate = (dateStr: string, createdAt: any) => {
    let d: Date;
    if (createdAt && typeof createdAt.toDate === 'function') {
      d = createdAt.toDate();
    } else if (createdAt && createdAt.seconds) {
      d = new Date(createdAt.seconds * 1000);
    } else if (dateStr) {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        // Construct local date directly to avoid timezone shift
        d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      } else {
        d = new Date(dateStr);
      }
    } else {
      return '—';
    }

    if (isNaN(d.getTime())) return '—';

    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    }); // e.g., "y4 May 2026"
  };

  // Extract unique Month/Years from buySales
  const availableMonths = useMemo(() => {
    const monthsSet = new Set<string>();
    buySales.forEach(record => {
      const dateStr = record.date || '';
      if (dateStr && dateStr.length >= 7) {
        monthsSet.add(dateStr.substring(0, 7)); // 'YYYY-MM'
      }
    });
    return Array.from(monthsSet).sort().reverse(); // Latest months first
  }, [buySales]);

  const monthLabels: { [key: string]: string } = {
    '01': 'Jan', '02': 'Feb', '03': 'Mar', '04': 'Apr',
    '05': 'May', '06': 'Jun', '07': 'Jul', '08': 'Aug',
    '09': 'Sep', '10': 'Oct', '11': 'Nov', '12': 'Dec'
  };

  const getMonthYearLabel = (ymStr: string) => {
    const [year, month] = ymStr.split('-');
    const mName = monthLabels[month] || month;
    return `${mName} ${year}`;
  };

  // Filter and process records
  const filteredAndSortedRecords = useMemo(() => {
    let result = buySales;

    // Apply project filter
    if (projectFilter !== 'all') {
      result = result.filter(r => r.projectId === projectFilter);
    }

    // Apply type filter
    if (typeFilter !== 'all') {
      result = result.filter(r => r.type === typeFilter);
    }

    // Apply Month/Year filter
    if (monthFilter !== 'all') {
      result = result.filter(r => r.date && r.date.startsWith(monthFilter));
    }

    // Apply search search term
    if (searchTerm) {
      const lowerSearch = searchTerm.toLowerCase();
      result = result.filter(r => 
        r.itemName.toLowerCase().includes(lowerSearch) ||
        (r.projectName && r.projectName.toLowerCase().includes(lowerSearch)) ||
        (r.partnerName && r.partnerName.toLowerCase().includes(lowerSearch))
      );
    }

    // Sort
    return [...result].sort((a, b) => {
      if (sortBy === 'amount') {
        return b.totalAmount - a.totalAmount;
      } else {
        // Default to date sort
        const dateA = a.date ? new Date(a.date).getTime() : 0;
        const dateB = b.date ? new Date(b.date).getTime() : 0;
        return dateB - dateA; // latest first
      }
    });
  }, [buySales, projectFilter, typeFilter, monthFilter, searchTerm, sortBy]);

  // Calculations
  const metrics = useMemo(() => {
    // Calculate based on active filters (project and month)
    let activeList = buySales;
    if (projectFilter !== 'all') {
      activeList = activeList.filter(r => r.projectId === projectFilter);
    }
    if (monthFilter !== 'all') {
      activeList = activeList.filter(r => r.date && r.date.startsWith(monthFilter));
    }

    let totalSales = 0;
    let salesCount = 0;
    let totalPurchases = 0;
    let purchasesCount = 0;

    activeList.forEach(item => {
      const amount = item.totalAmount || (item.quantity * item.unitPrice) || 0;
      if (item.type === 'Sale') {
        totalSales += amount;
        salesCount++;
      } else if (item.type === 'Buy') {
        totalPurchases += amount;
        purchasesCount++;
      }
    });

    const netMargin = totalSales - totalPurchases;

    return {
      totalSales,
      salesCount,
      totalPurchases,
      purchasesCount,
      netMargin
    };
  }, [buySales, projectFilter, monthFilter]);

  // Calculate inventory stock levels grouped by product
  const productInventories = useMemo(() => {
    const inventoryMap: { [key: string]: { totalBought: number; totalSold: number; totalInitial: number; remaining: number } } = {};
    
    // Aggregate data
    buySales.forEach(record => {
      const name = record.itemName.trim();
      if (!name) return;
      
      if (!inventoryMap[name]) {
        inventoryMap[name] = { totalBought: 0, totalSold: 0, totalInitial: 0, remaining: 0 };
      }
      
      const qty = Number(record.quantity) || 0;
      if (record.type === 'Buy') {
        inventoryMap[name].totalBought += qty;
      } else if (record.type === 'Sale') {
        inventoryMap[name].totalSold += qty;
      } else if (record.type === 'Initial') {
        inventoryMap[name].totalInitial += qty;
      }
    });

    // Calculate remaining quantities
    Object.keys(inventoryMap).forEach(key => {
      inventoryMap[key].remaining = (inventoryMap[key].totalBought + inventoryMap[key].totalInitial) - inventoryMap[key].totalSold;
    });

    // Make list of items with transactions
    return Object.entries(inventoryMap).map(([name, data]) => ({
      name,
      ...data
    })).filter(item => item.totalBought > 0 || item.totalSold > 0 || item.totalInitial > 0);
  }, [buySales]);

  // Dynamically calculate the select report month YYYY-MM
  const selectedReportMonth = reportMonth || (availableMonths[0] || new Date().toISOString().substring(0, 7));

  // Compute stats for specified month (opening, inflow/buying, adjustments, sales, closing stock)
  const monthlyReportData = useMemo(() => {
    const productMap: { 
      [key: string]: { 
        openingStock: number; 
        buys: number; 
        sales: number; 
        initials: number; 
        closingStock: number;
        revenue: number;
        cost: number;
      } 
    } = {};

    // Collect all products
    const allProducts = new Set<string>();
    buySales.forEach(r => {
      const name = r.itemName?.trim();
      if (name) allProducts.add(name);
    });

    allProducts.forEach(name => {
      productMap[name] = {
        openingStock: 0,
        buys: 0,
        sales: 0,
        initials: 0,
        closingStock: 0,
        revenue: 0,
        cost: 0
      };
    });

    buySales.forEach(record => {
      const name = record.itemName?.trim();
      if (!name) return;

      const recordDate = record.date || '';
      const qty = Number(record.quantity || 0);
      const val = Number(record.totalAmount || (qty * record.unitPrice) || 0);

      if (recordDate < selectedReportMonth) {
        // Prior timeline
        if (record.type === 'Buy' || record.type === 'Initial') {
          productMap[name].openingStock += qty;
        } else if (record.type === 'Sale') {
          productMap[name].openingStock -= qty;
        }
      } else if (recordDate.startsWith(selectedReportMonth)) {
        // Selected month timeline
        if (record.type === 'Buy') {
          productMap[name].buys += qty;
          productMap[name].cost += val;
        } else if (record.type === 'Sale') {
          productMap[name].sales += qty;
          productMap[name].revenue += val;
        } else if (record.type === 'Initial') {
          productMap[name].initials += qty;
        }
      }
    });

    // Return with final closing
    return Object.entries(productMap).map(([name, data]) => {
      const closingStock = (data.openingStock + data.buys + data.initials) - data.sales;
      return {
        name,
        ...data,
        closingStock
      };
    }).filter(p => p.openingStock !== 0 || p.buys !== 0 || p.sales !== 0 || p.initials !== 0);
  }, [buySales, selectedReportMonth]);

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sales Card */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-2xl border border-gray-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col gap-4 relative overflow-hidden group"
        >
          <div className="flex justify-between items-start">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl group-hover:scale-110 transition-transform">
              <ArrowUpRight size={22} />
            </div>
            <span className="text-[10px] uppercase font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700">
              {metrics.salesCount} Deals
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-400 font-bold uppercase tracking-wider">Total Product Sales</p>
            <h3 className="text-2xl font-black text-gray-900 tracking-tight mt-1">
              ৳{metrics.totalSales.toLocaleString()}
            </h3>
          </div>
        </motion.div>

        {/* Purchases Card */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-white p-6 rounded-2xl border border-gray-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col gap-4 relative overflow-hidden group"
        >
          <div className="flex justify-between items-start">
            <div className="p-3 bg-red-50 text-red-600 rounded-xl group-hover:scale-110 transition-transform">
              <ArrowDownLeft size={22} />
            </div>
            <span className="text-[10px] uppercase font-bold px-2.5 py-1 rounded-full bg-red-100 text-red-700">
              {metrics.purchasesCount} Orders
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-400 font-bold uppercase tracking-wider">Procurement Expenses</p>
            <h3 className="text-2xl font-black text-gray-900 tracking-tight mt-1">
              ৳{metrics.totalPurchases.toLocaleString()}
            </h3>
          </div>
        </motion.div>

        {/* Net Margin Card */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-2xl border border-gray-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col gap-4 relative overflow-hidden group"
        >
          <div className="flex justify-between items-start">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl group-hover:scale-110 transition-transform">
              <Coins size={22} />
            </div>
            <span className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-full ${metrics.netMargin >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
              {metrics.netMargin >= 0 ? 'Surplus' : 'Deficit'}
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-400 font-bold uppercase tracking-wider">Net Trade Margin</p>
            <h3 className={`text-2xl font-black tracking-tight mt-1 ${metrics.netMargin >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              {metrics.netMargin < 0 ? '-' : ''}৳{Math.abs(metrics.netMargin).toLocaleString()}
            </h3>
          </div>
        </motion.div>
      </div>

      {/* Product Stock Levels Section */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm"
      >
        <div className="flex items-center justify-between mb-5">
          <div>
            <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <Package className="text-corporate-navy" size={18} />
              Current Product Inventory Stock
            </h4>
          </div>
        </div>

        {productInventories.length === 0 ? (
          <div className="text-center py-8 border border-dashed border-gray-200 rounded-2xl text-gray-400 text-xs font-semibold bg-gray-50/20">
            No active product stock levels recorded. Add transaction records below to track inventory.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {productInventories.map((product) => {
              const remaining = product.remaining;
              const isLowStock = remaining > 0 && remaining <= 5;
              const isOutOfStock = remaining === 0;
              const isOversold = remaining < 0;

              return (
                <div 
                  key={product.name}
                  className="bg-gray-50/50 hover:bg-gray-50 border border-gray-100 rounded-2xl p-4 transition-all hover:shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-start gap-2 mb-2">
                      <span className="font-extrabold text-sm text-gray-900 leading-snug truncate" title={product.name}>
                        {product.name}
                      </span>
                      <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md shrink-0 whitespace-nowrap ${
                        isOutOfStock ? 'bg-gray-200 text-gray-650' :
                        isOversold ? 'bg-red-50 text-red-601 border border-red-100' :
                        isLowStock ? 'bg-amber-100 text-amber-800' :
                        'bg-blue-50 text-blue-700'
                      }`}>
                        {isOutOfStock ? 'Out of Stock' : 
                         isOversold ? 'Oversold' : 
                         isLowStock ? 'Low Stock' : 
                         'In Stock'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-1 mt-3 text-[10px] bg-white border border-gray-50 rounded-xl p-1.5 font-semibold text-center leading-tight">
                      <div>
                        <span className="text-[7.5px] text-gray-400 font-bold uppercase block tracking-wider truncate mb-0.5">Direct Onh.</span>
                        <span className="text-gray-900 font-black">{product.totalInitial} u</span>
                      </div>
                      <div className="border-l border-gray-100">
                        <span className="text-[7.5px] text-gray-400 font-bold uppercase block tracking-wider truncate mb-0.5">Purchases</span>
                        <span className="text-gray-900 font-black">{product.totalBought} u</span>
                      </div>
                      <div className="border-l border-gray-100">
                        <span className="text-[7.5px] text-gray-400 font-bold uppercase block tracking-wider truncate mb-0.5">Sales</span>
                        <span className="text-gray-950 font-black">{product.totalSold} u</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between items-center bg-gray-50/10">
                    {isAccountant ? (
                      <button
                        onClick={() => onQuickEditInitial(product.name)}
                        className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-corporate-navy hover:text-corporate-blue transition-colors cursor-pointer bg-gray-100/80 hover:bg-gray-100 px-2.5 py-1 rounded-lg border border-gray-200/50"
                        title="Adjust initial/on-hand stockpile"
                      >
                        <Edit2 size={10} />
                        Adjust Stock
                      </button>
                    ) : (
                      <div className="text-[10px] uppercase font-bold text-gray-400 bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-100 italic">
                        View-Only
                      </div>
                    )}
                    <span className={`text-base font-black ${
                      isOutOfStock ? 'text-gray-500' :
                      isOversold ? 'text-red-600 font-black' :
                      remaining <= 5 ? 'text-amber-600' :
                      'text-emerald-600'
                    }`}>
                      {remaining} units
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </motion.div>

      {/* Dynamic Monthly Inventory Report */}
      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <Calendar className="text-corporate-navy" size={18} />
              Monthly Product Stock & Trading Report
            </h4>
            <p className="text-xs text-gray-400 mt-1">
              Select any specific month to view precise stock levels, direct stock additions, purchases, sales, and closing numbers.
            </p>
          </div>

          <div className="flex items-center gap-2.5 bg-gray-50 px-3 py-2 rounded-xl border border-gray-200 shrink-0">
            <span className="text-xs font-bold text-gray-500">Report Month:</span>
            <select 
              value={selectedReportMonth}
              onChange={(e) => setReportMonth(e.target.value)}
              className="bg-transparent border-none text-xs font-extrabold text-corporate-navy focus:outline-none cursor-pointer"
            >
              {availableMonths.length === 0 ? (
                <option value={new Date().toISOString().substring(0, 7)}>
                  {getMonthYearLabel(new Date().toISOString().substring(0, 7))}
                </option>
              ) : (
                availableMonths.map(ym => (
                  <option key={ym} value={ym}>{getMonthYearLabel(ym)}</option>
                ))
              )}
            </select>
          </div>
        </div>

        {monthlyReportData.length === 0 ? (
          <div className="text-center py-10 border border-dashed border-gray-200 rounded-2xl text-gray-400 text-xs font-semibold bg-gray-50/20">
            No stock transactions or hand adjustments found during {getMonthYearLabel(selectedReportMonth)}.
          </div>
        ) : (
          <div className="overflow-x-auto border border-gray-100 rounded-2xl">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/25 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                  <th className="px-6 py-4">Product Name</th>
                  <th className="px-6 py-4 text-center">Opening Stock</th>
                  <th className="px-6 py-4 text-center bg-indigo-50/20 text-indigo-700">Direct Added (+h)</th>
                  <th className="px-6 py-4 text-center bg-red-50/20 text-red-700">Buys (+)</th>
                  <th className="px-6 py-4 text-center bg-emerald-50/20 text-emerald-700">Sales (-)</th>
                  <th className="px-6 py-4 text-right">Closing Stock</th>
                  <th className="px-6 py-4 text-right">Month's Trade Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 font-semibold text-xs text-gray-750">
                {monthlyReportData.map((item) => {
                  const hasSales = item.sales > 0;
                  const hasBuys = item.buys > 0;
                  const hasInitials = item.initials > 0;
                  
                  return (
                    <tr key={item.name} className="hover:bg-gray-50/30 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-extrabold text-sm text-gray-900 block">{item.name}</span>
                      </td>
                      <td className="px-6 py-4 text-center text-gray-505 font-bold">
                        {item.openingStock} units
                      </td>
                      <td className="px-6 py-4 text-center bg-indigo-50/10 font-black text-indigo-700">
                        {hasInitials ? `+${item.initials} units` : '—'}
                      </td>
                      <td className="px-6 py-4 text-center bg-red-50/10 font-bold text-red-655">
                        {hasBuys ? `+${item.buys} units` : '—'}
                        {hasBuys && <span className="text-[10px] text-gray-400 block font-normal">৳{item.cost.toLocaleString()}</span>}
                      </td>
                      <td className="px-6 py-4 text-center bg-emerald-50/10 font-bold text-emerald-650">
                        {hasSales ? `-${item.sales} units` : '—'}
                        {hasSales && <span className="text-[10px] text-gray-400 block font-normal">৳{item.revenue.toLocaleString()}</span>}
                      </td>
                      <td className="px-6 py-4 text-right font-black text-sm">
                        <span className={item.closingStock <= 0 ? 'text-gray-400' : 'text-corporate-navy'}>
                          {item.closingStock} units
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right font-black text-gray-900">
                        {hasSales ? `৳${item.revenue.toLocaleString()}` : <span className="text-gray-300 font-normal">৳0</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Ledger Section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden"
      >
        <div className="p-6 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1">
            <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <ShoppingBag className="text-corporate-navy" size={18} />
              Commercial Buy & Sales Ledger
            </h4>
          </div>

          {/* Filtering and Search tools */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Enabled Prominent Search Box */}
            <div className="relative group">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-corporate-navy" size={14} />
              <input 
                type="text" 
                placeholder="Search ledger..."
                className="bg-gray-50 border border-gray-200 rounded-xl pl-8 pr-4 py-1.5 text-xs font-semibold w-48 focus:outline-none focus:ring-2 focus:ring-corporate-navy/20 focus:bg-white transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Month & Year Dropdown Filter */}
            <div className="flex items-center gap-1.5 bg-gray-50 px-2 py-1.5 rounded-xl border border-gray-200">
              <Calendar size={13} className="text-gray-400" />
              <select 
                value={monthFilter}
                onChange={(e) => setMonthFilter(e.target.value)}
                className="bg-transparent border-none text-xs font-bold text-gray-650 focus:outline-none pr-1.5"
              >
                <option value="all">All Months</option>
                {availableMonths.map(ym => (
                  <option key={ym} value={ym}>{getMonthYearLabel(ym)}</option>
                ))}
              </select>
            </div>

            {/* Buys / Sales Mode Select */}
            <div className="flex items-center gap-1 bg-gray-50 p-1 rounded-xl border border-gray-105">
              <button 
                onClick={() => setTypeFilter('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${typeFilter === 'all' ? 'bg-white shadow-xs text-gray-900' : 'text-gray-450 hover:text-gray-700'}`}
              >
                All
              </button>
              <button 
                onClick={() => setTypeFilter('Buy')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${typeFilter === 'Buy' ? 'bg-white shadow-xs text-red-650' : 'text-gray-450 hover:text-red-500'}`}
              >
                Buys
              </button>
              <button 
                onClick={() => setTypeFilter('Sale')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${typeFilter === 'Sale' ? 'bg-white shadow-xs text-emerald-655' : 'text-gray-450 hover:text-emerald-500'}`}
              >
                Sales
              </button>
              <button 
                onClick={() => setTypeFilter('Initial')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${typeFilter === 'Initial' ? 'bg-white shadow-xs text-indigo-650' : 'text-gray-450 hover:text-indigo-500'}`}
              >
                Stock-OnHand
              </button>
            </div>

            {/* Sort by Metric selector */}
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-gray-50 border border-gray-100 rounded-xl px-2.5 py-1.5 text-xs font-bold text-gray-500 focus:outline-none focus:ring-2 focus:ring-corporate-navy/10 appearance-none cursor-pointer"
            >
              <option value="date">Latest First</option>
              <option value="amount">Highest Amount</option>
            </select>
          </div>
        </div>

        {/* Table representation */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-50 bg-gray-50/25">
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Item / Merchandise</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Type</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Qty & Rate</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Total Amount</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Project Assoc.</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Partner (Cust/Vend)</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                <th className="px-6 py-4 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 font-semibold text-sm text-gray-700">
              {filteredAndSortedRecords.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50/30 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="font-bold text-gray-900 block">{record.itemName}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-md ${
                      record.type === 'Sale' ? 'bg-emerald-100 text-emerald-800' : 
                      record.type === 'Buy' ? 'bg-rose-100 text-rose-800' : 
                      'bg-indigo-100 text-indigo-800'
                    }`}>
                      {record.type === 'Sale' ? '★ Sale' : record.type === 'Buy' ? '● Buy' : '◆ Initial'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-xs font-medium text-gray-500 whitespace-nowrap">
                    {record.quantity} &times; ৳{record.unitPrice.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 font-extrabold text-gray-900 whitespace-nowrap">
                    ৳{record.totalAmount.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 max-w-[160px] truncate">
                    {record.projectName ? (
                      <span className="inline-flex items-center gap-1.5 text-xs text-gray-800 font-bold bg-gray-100 px-2 py-1 rounded-lg">
                        <Briefcase size={12} className="text-corporate-navy" />
                        {record.projectName}
                      </span>
                    ) : (
                      <span className="text-gray-300 font-normal italic text-xs">Unassociated</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-xs font-bold text-gray-500">
                    {record.partnerName || '—'}
                  </td>
                  <td className="px-6 py-4 text-xs font-medium text-gray-400 whitespace-nowrap bg-white/20">
                    {renderTransactionDate(record.date, record.createdAt)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    {isAccountant ? (
                      <>
                        <button 
                          onClick={() => onEditBuySale(record)}
                          className="p-2 text-gray-400 hover:text-corporate-navy hover:bg-gray-100 rounded-xl transition-all opacity-0 group-hover:opacity-100 cursor-pointer mr-1 inline-flex items-center"
                          title="Edit Record"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button 
                          onClick={() => onDeleteBuySale(record.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100 cursor-pointer inline-flex items-center"
                          title="Delete Record"
                        >
                          <Trash2 size={16} />
                        </button>
                      </>
                    ) : (
                      <span className="text-xs text-gray-400 font-bold uppercase tracking-widest italic opacity-60">View Only</span>
                    )}
                  </td>
                </tr>
              ))}

              {filteredAndSortedRecords.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-400 text-sm font-semibold">
                    No transactions found in ledger.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
