const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

/**
 * Helper function to retrieve all registered investor device tokens
 */
async function getInvestorFcmTokens() {
  try {
    const usersSnapshot = await admin.firestore()
      .collection("users")
      .where("role", "==", "Investor")
      .get();
    
    const tokens = [];
    usersSnapshot.forEach(doc => {
      const user = doc.data();
      if (user.fcmToken) {
        tokens.push(user.fcmToken);
      }
    });
    return tokens;
  } catch (error) {
    console.error("Error fetching investor tokens:", error);
    return [];
  }
}

/**
 * Helper function to send notification to device tokens
 */
async function sendNotification(title, body, payloadData = {}) {
  const tokens = await getInvestorFcmTokens();
  if (tokens.length === 0) {
    console.log("No investor device tokens registered.");
    return null;
  }

  const payload = {
    notification: {
      title: title,
      body: body,
      clickAction: "FLUTTER_NOTIFICATION_CLICK"
    },
    data: Object.assign({
      click_action: "FLUTTER_NOTIFICATION_CLICK"
    }, payloadData)
  };

  try {
    console.log(`Sending FCM notification to ${tokens.length} devices...`);
    const response = await admin.messaging().sendToDevice(tokens, payload);
    console.log("Successfully sent notification:", JSON.stringify(response));
    return response;
  } catch (error) {
    console.error("Error sending push notification via FCM:", error);
    return null;
  }
}

// 1. Listen for new transactions in the Buy/Sales Ledger
exports.onBuySaleCreated = functions.firestore
  .document("buy_sales/{id}")
  .onCreate(async (snapshot, context) => {
    const data = snapshot.data();
    const title = `Hub Update: New ${data.type} Recorded!`;
    const body = `${data.itemName} (${data.quantity} units) has been added to the ledger by management.`;
    return sendNotification(title, body, { type: "buy_sale", action: "create", id: context.params.id });
  });

// 2. Listen for transaction updates in the Buy/Sales Ledger
exports.onBuySaleUpdated = functions.firestore
  .document("buy_sales/{id}")
  .onUpdate(async (change, context) => {
    const beforeData = change.before.data();
    const afterData = change.after.data();
    
    // Check if critical fields or type changed
    const title = "Hub Update: Transaction Amended";
    const body = `Trading item "${afterData.itemName}" has been modified in the ledger.`;
    return sendNotification(title, body, { type: "buy_sale", action: "update", id: context.params.id });
  });

// 3. Listen for transaction removals in the Buy/Sales Ledger
exports.onBuySaleDeleted = functions.firestore
  .document("buy_sales/{id}")
  .onDelete(async (snapshot, context) => {
    const data = snapshot.data();
    const title = "Hub Update: Entry Removed";
    const body = `Trading entry "${data.itemName}" has been deleted from the ledger by management.`;
    return sendNotification(title, body, { type: "buy_sale", action: "delete", id: context.params.id });
  });

// 4. Listen for new Projects being initiated
exports.onProjectCreated = functions.firestore
  .document("projects/{id}")
  .onCreate(async (snapshot, context) => {
    const data = snapshot.data();
    const title = "Hub Update: New Project Launched!";
    const body = `Project "${data.name}" in the ${data.sector || "commercial"} sector is now active.`;
    return sendNotification(title, body, { type: "project", action: "create", id: context.params.id });
  });

// 5. Listen for new Expense items logged
exports.onExpenseCreated = functions.firestore
  .document("expenses/{id}")
  .onCreate(async (snapshot, context) => {
    const data = snapshot.data();
    const title = "Hub Update: Expense Registered";
    const body = `An operational cost of ৳${data.amount} for "${data.description}" has been logged.`;
    return sendNotification(title, body, { type: "expense", action: "create", id: context.params.id });
  });

// 6. Listen for new Profit inflow logs
exports.onProfitCreated = functions.firestore
  .document("profits/{id}")
  .onCreate(async (snapshot, context) => {
    const data = snapshot.data();
    const title = "Hub Update: Revenue Distributed";
    const body = `A profit inflow of ৳${data.amount} has been logged for "${data.projectName}".`;
    return sendNotification(title, body, { type: "profit", action: "create", id: context.params.id });
  });
