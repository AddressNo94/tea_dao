import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for AI Chat bot
  app.post("/api/chat", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "GEMINI_API_KEY is not configured in environment variables." });
      }

      const { message, history, contextData } = req.body;
      
      const ai = new GoogleGenAI({ apiKey });
      
      // Build an elegant financial system instruction incorporating live capital hub state
      const systemInstruction = `You are CapitalHub's advanced virtual financial assistant and elite investment portfolio advisor. 
You are highly skilled in analyzing investment metrics, capital structures, ROI analysis, venture performance, and profit shares.

Here is the current real-time state of the CapitalHub database that you represent:
${JSON.stringify(contextData || {}, null, 2)}

Provide highly intelligent, precise, helpful, and concise analysis. You speak directly to the investor or general manager. 
Keep your mathematical calculations rigorous. Answer in English if they ask in English, or Bangla if they ask in Bangla, or blend naturally depending on their language of choice.
Avoid meta-commentary, avoid mentioning process.env, do not discuss code structures, and focus on delivering excellent financial guidance.`;

      // Convert messages to standard content format for SDK
      // The history should be formatted as array of: { role: 'user' | 'model', parts: [{ text: string }] }
      const formattedHistory = (history || []).map((msg: any) => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          ...formattedHistory,
          { role: "user", parts: [{ text: message }] }
        ],
        config: {
          systemInstruction
        }
      });

      const reply = response.text || "I apologize, but I could not compute an analysis at this moment.";
      res.json({ text: reply });
    } catch (err) {
      console.error("Gemini Assistant Error:", err);
      res.status(500).json({ error: err instanceof Error ? err.message : "Internal Server Error in Gemini API proxy" });
    }
  });

  // Serve static UI assets
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CapitalHub server listening on host 0.0.0.0, port ${PORT}`);
  });
}

startServer();
