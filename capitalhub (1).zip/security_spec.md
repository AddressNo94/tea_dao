# Security Specification - Elite Invest

## Data Invariants
1. `investors`:
   - `name`: string, min 1, max 100 characters.
   - `totalCapital`: number, non-negative.
   - `projects`: number, non-negative.
   - `status`: string, enum ["Active", "Inactive", "Pending"].
   - `equity`: string, matches percentage pattern (e.g. "12%").
   - `createdAt`: server timestamp.

## Dirty Dozen Payloads (to be rejected)
1. Missing `name`.
2. `totalCapital` as string.
3. `status` not in enum.
4. `projects` negative.
5. `createdAt` as client-provided string.
6. Extra field `isAdmin: true`.
7. `name` too long (10KB).
8. `equity` as number.
9. Updating `name` to an empty string.
10. Creating without `projects`.
11. Updating `createdAt` (immutable).
12. Malicious HTML in `name`.
